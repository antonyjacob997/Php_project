-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 07, 2020 at 07:33 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id13080501_camra`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic`
--

CREATE TABLE `academic` (
  `academic_id` int(11) NOT NULL,
  `stud_id` int(11) DEFAULT NULL,
  `Aggr_CGPA` varchar(5) DEFAULT NULL,
  `Aggr_Percentage` varchar(4) DEFAULT NULL,
  `CURRENT_ARREARS` int(2) DEFAULT NULL,
  `HISTORY_OF_ARREARS` varchar(100) DEFAULT NULL,
  `10th_p` varchar(5) DEFAULT NULL,
  `10th_CGPA` varchar(6) DEFAULT NULL,
  `10th_YoP` varchar(5) DEFAULT NULL,
  `10th_Board` varchar(30) DEFAULT NULL,
  `10th_School` varchar(100) DEFAULT NULL,
  `10th_State_of_school` int(11) DEFAULT NULL,
  `12th_p` varchar(30) DEFAULT NULL,
  `12th_CGPA` varchar(5) DEFAULT NULL,
  `12th_YoP` varchar(30) DEFAULT NULL,
  `12th_Board` varchar(30) DEFAULT NULL,
  `12th_School` varchar(100) DEFAULT NULL,
  `12th_State_of_School` int(11) DEFAULT NULL,
  `UG_Course` varchar(80) DEFAULT NULL,
  `UG_P` varchar(6) DEFAULT NULL,
  `UG_CGPA` varchar(6) DEFAULT NULL,
  `UG_YoP` varchar(6) DEFAULT NULL,
  `UG_College` varchar(100) DEFAULT NULL,
  `state_of_UG` varchar(30) DEFAULT NULL,
  `UG_University` varchar(100) DEFAULT NULL,
  `PG_University` varchar(100) DEFAULT NULL,
  `Technical_Skills` varchar(100) DEFAULT NULL,
  `Work_Experience` varchar(100) DEFAULT NULL,
  `Certifications` varchar(100) DEFAULT NULL,
  `Internships` varchar(100) DEFAULT NULL,
  `login_id` int(11) NOT NULL,
  `stat1` int(11) NOT NULL,
  `stat2` int(11) NOT NULL,
  `stat3` int(11) NOT NULL,
  `stat4` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic`
--

INSERT INTO `academic` (`academic_id`, `stud_id`, `Aggr_CGPA`, `Aggr_Percentage`, `CURRENT_ARREARS`, `HISTORY_OF_ARREARS`, `10th_p`, `10th_CGPA`, `10th_YoP`, `10th_Board`, `10th_School`, `10th_State_of_school`, `12th_p`, `12th_CGPA`, `12th_YoP`, `12th_Board`, `12th_School`, `12th_State_of_School`, `UG_Course`, `UG_P`, `UG_CGPA`, `UG_YoP`, `UG_College`, `state_of_UG`, `UG_University`, `PG_University`, `Technical_Skills`, `Work_Experience`, `Certifications`, `Internships`, `login_id`, `stat1`, `stat2`, `stat3`, `stat4`) VALUES
(1, 1, '7.09', '67', 0, NULL, '92', '9.2', '2011', 'CBSE', 'Karmal Mount', 23, '85', '8.5', '2013', 'CBSC', 'St Dominics H S S KPLY', 12, '11', '85', '8.5', '2014', 'st Thomas College Pala', '12', 'MG', 'KTU', 'Java,Python', 'Nil', 'AWS', 'Nil', 2, 1, 1, 1, 1),
(2, 3, '7.09', '71', 0, NULL, '95', '9.0', '2013', 'Kerala State Board', 'St Dominic h s s kply', 12, '85', '8.5', '2015', 'Kerala State Board', 'Achamma Memorial H S S Kalaket', 12, '17', '79', '7.9', '2018', 'Marian College Kuttikkanam', '12', 'MG', 'KTU', 'JAVA, C++', 'Nil', 'AWS,Python', 'Nil', 4, 1, 1, 1, 1),
(3, 4, '8.5', '85', 0, NULL, '94', '9.4', '2013', 'ICSE', 'Life Public School kottayam', 12, '89', '8.9', '2015', 'CBSC', 'st Antonys Public School Anakk', 12, '5', '85', '8.5', '2018', 'RIT college Pambadi', '12', 'MG', 'KTU', 'JAVA, C++', 'Nil', 'AWS,Python', 'Robotics', 5, 1, 1, 1, 1),
(4, 5, '7.09', '67', 0, NULL, '95', '9.5', '2013', 'Kerala State Board', 'St Dominics H S S KPLY', 12, '68', '6.8', '2015', 'kerala State Board', 'st Dominics H S S KPLY', 12, '12', '65', '6.5', '2018', 'st Thomas College Pala', '12', 'MG', 'KTU', 'wetewtw', 'wetwt', 'rerewetwe', 'tvcv', 7, 1, 1, 1, 1),
(5, 6, '7.8', '76', 0, NULL, '94', '9.4', '2012', 'CBSE', 'St Antonys Public School', 12, '95', '9.5', '2014', 'ICSC', 'st Antonys Public School Anakkal', 12, '17', '76', '7.6', '2017', 'Marian College Kuttikkanam', '12', 'MG', 'KTU', 'JAVA, C++', 'Nil', 'AWS', 'Nil', 8, 1, 1, 1, 1),
(6, 7, '7.09', '67', 1, NULL, '85', '8.5', '2013', 'CBSE', 'A K J M HSS KPLY', 12, '75', '7.5', '2015', 'kerala State Board', 'A K J M HSS KPLY', 12, '17', '65', '6.5', '2018', 'Marian College Kuttikkanam', '12', 'MG', 'University of Calicut ', 'JAVA, PhP', 'Academic Projects', 'nil', 'nil', 9, 1, 1, 1, 1),
(9, 10, NULL, NULL, NULL, NULL, '90', '9.0', '2013', 'CBSC', 'Global Indian Public School', 12, '85', '8.5', '2015', 'CBSC', 'Global Indian Public School', 12, '17', '70', '7.0', '2018', 'Senate House Campus', '12', 'Kerala University', NULL, NULL, NULL, NULL, NULL, 12, 1, 1, 1, 0),
(10, 11, '7.4', '72', 0, NULL, '93', '9.3', '2015', 'Kerala State Board', 'St Dominics Higher Secondary School Kanjirappally', 12, '83', '8.3', '2017', 'kerala State Board', 'Achamma Memorial H S S Kalaketty', 12, '5', '', '', '2021', '', '', '', NULL, 'Electronics', 'Nil', 'Nil', 'Nil', 16, 1, 1, 1, 0),
(11, 13, '5.3', '56', 1, '', '70', '7.0', '2014', 'Kerala State Board', 'Government Model Higher Secondary School', 12, '60', '6.0', '2016', 'kerala State Board', 'Government Model Higher Secondary School', 12, '4', '', '', '2020', '', '', '', '', '', '', '', '', 19, 1, 1, 1, 0),
(12, 14, '9.6', '96', 0, '', '96', '9.6', '2014', 'Kerala State Board', 'St Dominic public school', 12, '86', '8.6', '2016', 'kerala State Board', 'Pappan memorial public school', 12, '7', '', '', '2020', '', '', '', '', 'Verbal and written communication skills, problem solving skills', '2 yr in Anand industry', 'CREO,PRO-E,ASME-NDT', 'JetAvi Engineering', 20, 1, 1, 1, 0),
(13, 15, '', '', 0, '', '89', '8.9', '2012', 'CBSC', 'St Joseph public school', 12, '88', '8.8', '2014', 'CBSC', 'St Joseph public school', 12, '6', '79', '7.9', '2018', 'Amal Jyothi college of Engineering', '12', 'KTU', '', '', '', '', '', 21, 1, 1, 1, 0),
(14, 16, '', '', 0, '', '', '', '', '', '', 12, '', '', '', '', '', 12, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `aptitude`
--

CREATE TABLE `aptitude` (
  `aptitude_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `question` varchar(2000) NOT NULL,
  `option1` varchar(1000) NOT NULL,
  `option2` varchar(1000) NOT NULL,
  `option3` varchar(1000) NOT NULL,
  `option4` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aptitude`
--

INSERT INTO `aptitude` (`aptitude_id`, `category_id`, `question`, `option1`, `option2`, `option3`, `option4`, `status`) VALUES
(1, 0, 'dfhgdh', 'erergre', 'dfgdfgdf', 'jhvjhvfhj', 'hvjhvjhvj', 1),
(2, 0, 'fdhhdrher', 'fhjgfhgf', 'hgjcvhgchg', 'hggvchgcvgh', 'vhgvhgv', 1),
(3, 0, 'fdhhdrher', 'fhjgfhgf', 'hgjcvhgchg', 'hggvchgcvgh', 'vhgvhgv', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `category` varchar(40) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `category`, `status`) VALUES
(1, 'Number Series', 1),
(2, 'Letter Series', 1),
(3, 'Blood Relation', 1);

-- --------------------------------------------------------

--
-- Table structure for table `caution`
--

CREATE TABLE `caution` (
  `payment_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `pay_id` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caution`
--

INSERT INTO `caution` (`payment_id`, `stud_id`, `payment_date`, `pay_id`) VALUES
(1, 4, '2020-04-08', 'pay_EbtqhGAmNZHwCN'),
(2, 6, '2020-04-08', 'pay_Ebtshi5mlIo1fu'),
(3, 7, '2020-04-08', 'pay_Ec2eZvAFwv2OXw'),
(6, 1, '2020-04-21', 'pay_Eh332wKkjoDJKx'),
(7, 11, '2020-04-22', 'pay_EhSXTkjplxMlwT'),
(8, 13, '2020-04-22', 'pay_EhU4mnw1EyAKvC'),
(9, 3, '2020-05-03', 'pay_ElwbndSn6pbAQe'),
(10, 14, '2020-05-30', 'pay_EwZlKbd1g9ipTA');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_name`) VALUES
(1, 'India');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL,
  `chk` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `course` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `department_name`, `chk`, `status`, `course`) VALUES
(1, 'Chemical Engineering', 1, 1, 'Btech'),
(2, 'Civil Engineering', 1, 1, 'Btech'),
(3, 'Computer science and Engineering', 1, 1, 'Btech'),
(4, 'Electronic and communication Engineering', 1, 1, 'Btech'),
(5, 'Electrical and Electronic Engineering', 1, 1, 'Btech'),
(6, 'Information Technology', 1, 1, 'Btech'),
(7, 'Mechanical Engineering', 1, 1, 'Btech'),
(8, 'Mechanical Engineering(Automobile)', 1, 1, 'Btech'),
(9, 'Metallurgical and Materials Engineering', 1, 1, 'Btech'),
(10, 'Master of Computer Applications', 1, 1, 'MCA'),
(11, 'Basic Sciences', 2, 1, ''),
(12, 'Humanities', 2, 1, ''),
(13, 'Master of computer Application (Lateral)', 1, 1, 'MCA'),
(16, 'Master of computer Application (Integrated)', 1, 1, 'MCA'),
(17, 'Bachlor of Computer Application', 2, 0, ''),
(18, 'Bachlor of Business Administration', 2, 0, ''),
(19, 'Bsc.Chemistry', 2, 0, ''),
(20, 'Bsc.Mathematics', 2, 0, ''),
(21, 'Bsc.Physics', 2, 0, ''),
(22, 'Others', 2, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `Designation_id` int(11) NOT NULL,
  `Designation` varchar(30) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`Designation_id`, `Designation`, `status`) VALUES
(1, 'Software Engineer', 1),
(2, 'Marketing manager', 1),
(3, 'Marketing Advisor', 1);

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `dist_id` int(11) NOT NULL,
  `dist_name` varchar(40) NOT NULL,
  `state_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`dist_id`, `dist_name`, `state_id`) VALUES
(1, 'Thiruvananthapuram', 12),
(2, 'Kollam', 12),
(3, 'Pathanamthitta', 12),
(4, 'Alappuzha', 12),
(5, 'Kottayam', 12),
(6, 'Idukki', 12),
(7, 'Ernakulam ', 12),
(8, 'Thrissur', 12),
(9, 'Palakkad', 12),
(10, 'Malappuram', 12),
(11, 'Kozhikode', 12),
(12, 'Wayanad', 12),
(13, 'Kannur', 12),
(14, 'Kasaragod', 12);

-- --------------------------------------------------------

--
-- Table structure for table `drive_elig`
--

CREATE TABLE `drive_elig` (
  `elig_id` int(11) NOT NULL,
  `notif_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drive_elig`
--

INSERT INTO `drive_elig` (`elig_id`, `notif_id`, `stud_id`, `status`) VALUES
(1, 1, 1, 1),
(9, 6, 5, 1),
(8, 6, 4, 1),
(7, 6, 3, 1),
(6, 6, 1, 1),
(10, 7, 1, 1),
(11, 7, 3, 1),
(12, 7, 4, 1),
(13, 7, 5, 1),
(14, 8, 1, 1),
(15, 8, 3, 1),
(16, 8, 4, 1),
(17, 8, 6, 1),
(18, 9, 1, 1),
(19, 9, 4, 1),
(20, 10, 1, 1),
(21, 10, 3, 1),
(22, 10, 4, 1),
(23, 10, 6, 1),
(24, 11, 1, 1),
(25, 11, 3, 1),
(26, 11, 4, 1),
(27, 11, 5, 1),
(28, 11, 6, 1),
(29, 12, 1, 1),
(30, 12, 3, 1),
(31, 12, 4, 1),
(32, 12, 5, 1),
(33, 12, 6, 1),
(34, 15, 4, 1),
(35, 15, 6, 1),
(36, 15, 1, 1),
(37, 15, 3, 1),
(38, 15, 5, 1),
(39, 17, 4, 1),
(40, 17, 6, 1),
(41, 17, 1, 1),
(42, 17, 3, 1),
(43, 18, 4, 1),
(44, 18, 6, 1),
(45, 18, 1, 1),
(46, 18, 3, 1),
(47, 18, 5, 1),
(48, 20, 4, 1),
(49, 20, 6, 1),
(50, 20, 1, 1),
(51, 20, 3, 1),
(52, 20, 5, 1),
(53, 21, 4, 1),
(54, 21, 6, 1),
(55, 21, 1, 1),
(56, 21, 5, 1),
(57, 22, 4, 1),
(58, 22, 6, 1),
(59, 22, 1, 1),
(60, 22, 3, 1),
(61, 22, 4, 1),
(62, 22, 6, 1),
(63, 22, 1, 1),
(64, 22, 3, 1),
(65, 25, 4, 1),
(66, 25, 6, 1),
(67, 25, 1, 1),
(68, 25, 3, 1),
(69, 25, 5, 1),
(70, 25, 7, 1),
(82, 28, 7, 1),
(81, 28, 5, 1),
(80, 28, 3, 1),
(79, 28, 1, 1),
(78, 28, 6, 1),
(77, 28, 4, 1),
(83, 29, 6, 1),
(84, 29, 1, 1),
(85, 29, 3, 1),
(86, 25, 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `drive_reg`
--

CREATE TABLE `drive_reg` (
  `drive_id` int(11) NOT NULL,
  `notif_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `feed` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drive_reg`
--

INSERT INTO `drive_reg` (`drive_id`, `notif_id`, `stud_id`, `status`, `org_id`, `feed`) VALUES
(1, 1, 1, 1, 2, 0),
(2, 6, 3, 1, 3, 0),
(3, 7, 3, 1, 8, 0),
(4, 6, 4, 1, 3, 0),
(5, 7, 4, 1, 8, 0),
(6, 6, 5, 1, 3, 0),
(7, 7, 5, 1, 8, 0),
(8, 8, 6, 1, 1, 0),
(10, 12, 3, 1, 3, 0),
(11, 20, 3, 1, 1, 0),
(12, 21, 5, 1, 2, 0),
(13, 20, 5, 1, 1, 0),
(14, 20, 4, 1, 1, 0),
(15, 12, 4, 1, 3, 0),
(16, 22, 4, 1, 5, 0),
(17, 22, 6, 1, 5, 0),
(18, 10, 6, 1, 10, 1),
(19, 25, 4, 1, 27, 1),
(20, 29, 3, 1, 8, 0),
(21, 25, 7, 1, 27, 1);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `f_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `designation` varchar(40) NOT NULL,
  `dept` varchar(40) NOT NULL,
  `Mobile` varchar(15) NOT NULL,
  `Alt_Mob` varchar(15) NOT NULL,
  `Alt_Email` varchar(40) NOT NULL,
  `login_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`f_id`, `name`, `designation`, `dept`, `Mobile`, `Alt_Mob`, `Alt_Email`, `login_id`, `status`) VALUES
(1, 'Rony Tom', 'Placement officer', 'Master of Computer Applications', '9857846895', '9658748795', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `org` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `feedback` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `date1` date NOT NULL,
  `forward` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `stud_id`, `org`, `feedback`, `date1`, `forward`, `status`) VALUES
(1, 3, 'Cognizant', 'It was a nice experience. I think that i performed well.They asked the basics only and i am so confident about it.So i think i performed well', '2020-06-02', 1, 1),
(2, 3, 'Cognizant', 'It was a nice experience. I think that i performed well.They asked the basics only and i am so confident about it.So i think i performed well', '2020-06-02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `company_count` int(11) NOT NULL,
  `btech_count` int(11) NOT NULL,
  `mca_count` int(11) NOT NULL,
  `mtech_count` int(11) NOT NULL,
  `year` varchar(7) NOT NULL,
  `total_placed` int(11) NOT NULL,
  `registered_stud` int(11) NOT NULL,
  `oncampus` int(11) NOT NULL,
  `ofcampus` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `company_count`, `btech_count`, `mca_count`, `mtech_count`, `year`, `total_placed`, `registered_stud`, `oncampus`, `ofcampus`) VALUES
(3, 14, 1, 3, 0, '2020', 4, 8, 0, 0),
(2, 15, 75, 32, 20, '2018', 127, 500, 10, 5),
(4, 8, 0, 3, 0, '2019', 3, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `job_notification`
--

CREATE TABLE `job_notification` (
  `job_id` int(11) NOT NULL,
  `org_id` int(30) DEFAULT NULL,
  `Criteria` varchar(100) DEFAULT NULL,
  `branch` varchar(300) NOT NULL,
  `Date1` date DEFAULT NULL,
  `Venue` varchar(100) DEFAULT NULL,
  `Placed` int(11) DEFAULT NULL,
  `Registered` int(11) DEFAULT NULL,
  `Absentees` int(11) DEFAULT NULL,
  `Shortlisted` int(11) DEFAULT NULL,
  `Designation` varchar(100) DEFAULT NULL,
  `CTC` int(11) DEFAULT NULL,
  `Rounds` varchar(200) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_notification`
--

INSERT INTO `job_notification` (`job_id`, `org_id`, `Criteria`, `branch`, `Date1`, `Venue`, `Placed`, `Registered`, `Absentees`, `Shortlisted`, `Designation`, `CTC`, `Rounds`, `status`) VALUES
(1, 3, '70% or above in all sem', '', '2019-11-09', 'Amal Jyothi college of engineering kply', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(2, 1, 'mark above 65% in all academics', 'Chemical Engineering,Civil Engineering,Computer science and Engineering,Electrics and communication Engineering,Electrical and Electronic Engineering,Information Technology,Mechanical Engineering,Master of Computer Applications,Master od computer Application (Lateral),', '2019-11-01', 'Amal Jyothi college of engineering kply', NULL, NULL, NULL, NULL, '1,', NULL, 'Aptitude,Technical Interview,HR Interview,', 0),
(3, 8, 'pass', 'Computer science and Engineering, Electrics and communication Engineering, Information Technology, Master of Computer Applications, ', '2019-10-22', 'Baker College Kottayam', NULL, NULL, NULL, NULL, '1, ', NULL, 'Aptitude, Group Discussion, Technical Interview, HR Interview, ', 0),
(4, 9, '60% aboe', 'Master of Computer Applications, ', '2019-11-21', 'Amal Jyothi college of engineering kply', NULL, NULL, NULL, NULL, '1, 2, 3, ', NULL, 'Aptitude, Group Discussion, Technical Interview, ', 0),
(6, 5, 'just pass in all ', 'Computer science and Engineering, Electrics and communication Engineering, Humanities, Master of computer Application (Integrated), Master of computer Application (Lateral), Master of Computer Applications, ', '2019-12-04', 'Amal Jyothi college of engineering kply', NULL, NULL, NULL, NULL, '2, ', NULL, 'Aptitude, Group Discussion, Technical Interview, HR Interview, ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `psw` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `user_type`, `email`, `password`, `status`, `psw`) VALUES
(1, 'Placement officer', 'ronytom@gmail.com', 'cd038b11a87f4c702525cb233789511b', 1, 0),
(2, 'Student', 'lakshyamaluz2011@gmail.com', '029b648c19810c8bc3f5d7a4c73687ee', 1, 0),
(4, 'Student', 'antonyjacob997@gmail.com', '334d634acec4c25ce72436eab947cac5', 1, 0),
(5, 'Student', 'joseline@gmail.com', '72d2eb11a781225cefbca50add3e0dd5', 1, 0),
(8, 'Student', 'david@gmail.com', '889211b122daa7f9f917d3d3b3475514', 1, 0),
(7, 'Student', '118antonyjacob@gmail.com', 'f640fdc2c16617522f43c94a634d7c3c', 1, 0),
(9, 'Student', 'sarun@gmail.com', 'e469785f808dcddaaa473a790e3defcb', 1, 0),
(10, 'Student', 'jefinproject2020@gmail.com', '334d634acec4c25ce72436eab947cac5', 1, 0),
(11, 'Student', 'antony@ga.oo', '73af1a03f53ce243791334baef142fe5', 1, 0),
(12, 'Student', 'jefinshaji@mca.ajce.in', 'b9598620b6af7766bdcd93bde26b7cff', 1, 0),
(19, 'Student', 'antonyjacob@mca.ajce.in', '94f571ce46d0670b364581c1f55450fb', 1, 0),
(16, 'Student', 'maryjacob1410@gmail.com', 'a636ccc72eaf0f8b489db5c42df5d46f', 1, 0),
(20, 'Student', 'rinumaryj@gmail.com', '97892012b1a141c340d7622410dd3d41', 1, 0),
(21, 'Student', 'john@gmail.com', '6d40e095b7f43848dc76ec017592da29', 1, 0),
(22, 'Student', 'shankar@gmail.com', '15f1298c2edcab4797ee3a9364281473', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notif_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `elig_branch` varchar(500) NOT NULL,
  `tenth` varchar(10) NOT NULL,
  `plus_two` varchar(10) NOT NULL,
  `degree` varchar(10) NOT NULL,
  `backlog` int(11) NOT NULL,
  `other_criteria` varchar(100) NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL,
  `venue` varchar(40) NOT NULL,
  `venue2` varchar(40) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `ctc` varchar(50) NOT NULL,
  `rounds` varchar(100) NOT NULL,
  `other_round` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `YOP` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notif_id`, `org_id`, `elig_branch`, `tenth`, `plus_two`, `degree`, `backlog`, `other_criteria`, `date1`, `date2`, `venue`, `venue2`, `designation`, `ctc`, `rounds`, `other_round`, `status`, `YOP`) VALUES
(1, 2, 'Computer science and Engineering, Electrical and Electronic Engineering, Information Technology, Mas', '70', '70', '7.0', 0, '', '2019-11-28', '0000-00-00', 'Amal Jyothi college of engineering kply', '', 'Software Engineer', '3.1 LPA', 'Online Aptitude,Personal Interview', '', 0, 2020),
(6, 3, 'Electronic and communication Engineering, Information Technology, Master of computer Application (In', '50', '50', '5.0', 0, '', '2019-11-29', '0000-00-00', 'Amal Jyothi college of engineering kply', '', 'Software Engineer', '3.5 LPA', 'Online Aptitude,Technical Interview,HR Interview', '', 0, 2020),
(7, 8, 'Electronic and communication Engineering, Information Technology, Master of computer Application (In', '50', '50', '5.0', 0, '', '2019-11-28', '0000-00-00', 'Amal Jyothi college of engineering kply', '', 'Software Engineer', '3.5 LPA', 'Online Aptitude, Technical Interview, HR Interview, ', '', 0, 2020),
(8, 1, 'Electronic and communication Engineering, Information Technology, Master of computer Application (In', '70', '70', '7.4', 0, '', '2019-11-30', '0000-00-00', 'Amal Jyothi college of engineering kply', '', 'Software Engineer', '4.5 LPA', 'Online Aptitude, Group Discussion, Technical Interview, HR Interview, ', '', 0, 2020),
(9, 2, 'Master of computer Application (Lateral), Master of Computer Applications, ', '80', '75', '8.0', 0, 'ffgfgftttfjfjgf', '2019-10-23', '0000-00-00', 'Amal Jyothi college of engineering kply', '', 'Software Engineer', '3.5 LPA', 'Online Aptitude, Group Discussion, Personal Interview, ', 'psychometric test', 0, 2020),
(11, 10, 'Computer science and Engineering, Electrical and Electronic Engineering, Electronic and communicatio', '60', '60', '6.0', 0, 'nil', '2020-02-15', '2020-02-21', 'Amal Jyothi college of engineering kply', '', 'Software Engineer', '3.5 LPA', 'Online Aptitude, Group Discussion, Technical Interview, HR Interview, ', '', 0, 2020),
(12, 3, 'Computer science and Engineering, Electrical and Electronic Engineering, Information Technology,', '60', '60', '6.0', 0, 'No active Backlogs at recruitment time.', '2020-03-23', '2020-03-26', 'Amal Jyothi college of engineering kply', '', 'Software Engineer', '3.5 LPA', 'Online Aptitude, Technical Interview, HR Interview, ', '', 0, 2020),
(24, 1, 'Chemical Engineering, Master of computer Application (Integrated), ', '70', '50', '5.0', 90, 'hghgvjghvj', '2020-02-25', '2020-03-29', 'bhnjhbnmj ', 'mn m', '', '', 'Online Aptitude, Offline Aptitude, Group Discussion, Personal Interview, ', 'jnkmnjhhljk', 0, 2020),
(20, 1, 'Computer science and Engineering, Electronic and communication Engineering, Information Technology, Master of computer Application (Integrated), Master of computer Application (Lateral), Master of Computer Applications, Mechanical Engineering, ', '50', '50', '5.0', 1, 'Backlog should be cleared before joining', '2020-03-11', '2020-03-20', 'Marian College Kuttikkanam', 'TCS  Kakkanad', 'Software Engineer', '3.5 LPA', 'Online Aptitude, Technical Interview, HR Interview, ', '', 0, 2020),
(21, 2, 'Computer science and Engineering, Electronic and communication Engineering, Information Technology, Master of computer Application (Integrated), Master of computer Application (Lateral), Master of Computer Applications, ', '50', '50', '5.0', 1, '', '2020-03-12', '2020-03-20', 'Amal Jyothi college of engineering kply', 'Nil', 'Software Engineer', '3.5 LPA', 'Online Aptitude, Technical Interview, HR Interview, ', '', 0, 2020),
(22, 5, 'Computer science and Engineering, Electronic and communication Engineering, Information Technology, Master of computer Application (Lateral), ', '50', '50', '5.0', 1, '', '2020-03-20', '2020-04-18', 'Amal Jyothi college of engineering kply', 'Nil', 'Marketing manager', '3.5 LPA', 'Online Aptitude, Technical Interview, HR Interview, ', '', 0, 2019),
(23, 5, 'Computer science and Engineering, Electronic and communication Engineering, Information Technology, Master of computer Application (Lateral), ', '50', '50', '5.0', 1, '', '2020-03-20', '2020-04-18', 'Amal Jyothi college of engineering kply', 'Nil', 'Marketing manager', '3.5 LPA', 'Online Aptitude, Technical Interview, HR Interview, ', '', 0, 2019),
(25, 27, 'Chemical Engineering, Civil Engineering, Computer science and Engineering, Electrical and Electronic Engineering, Electronic and communication Engineering, Information Technology, Master of computer Application (Integrated), Master of computer Application (Lateral), Master of Computer Applications, Mechanical Engineering, Mechanical Engineering(Automobile), Metallurgical and Materials Engineering, ', '65', '65', '6.5', 1, 'Clear all backlogs before joining', '2020-06-01', '2020-06-15', 'Amal Jyothi college of Engineering', '', 'Marketing Manager, Technical Support', '4.5', 'Online Aptitude, Group Discussion, Personal Interview, HR Interview, ', '', 0, 2020),
(28, 5, 'Chemical Engineering, Civil Engineering, Computer science and Engineering, Electrical and Electronic Engineering, Electronic and communication Engineering, Information Technology, Master of computer Application (Integrated), Master of computer Application (Lateral), Master of Computer Applications, Mechanical Engineering, Mechanical Engineering(Automobile), Metallurgical and Materials Engineering, ', '50', '50', '5.0', 1, 'Need to pass all semester before join', '2020-05-18', '2020-05-23', 'Amal Jyothi College of engineering', '', 'Marketing Manager', '3.5', 'Offline Aptitude, Group Discussion, Personal Interview, HR Interview, ', '', 0, 2020),
(29, 8, 'Information Technology, Master of computer Application (Integrated), Master of computer Application (Lateral), Master of Computer Applications, Mechanical Engineering, ', '50', '50', '7.0', 1, 'wwwwww', '2020-05-06', '2020-05-15', 'Amal Jyothi', '', 'Software Engineer', '2.5 L/a', 'Online Aptitude, Technical Interview, HR Interview, ', '', 0, 2021);

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `org_id` int(11) NOT NULL,
  `Org` varchar(30) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `img_name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `captions` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`org_id`, `Org`, `status`, `img_name`, `description`, `captions`, `name`, `email`, `phone`) VALUES
(1, 'TCS', 1, 'tcs1.jpg', 'Global Leader in IT Services, Consulting, Technology and Digital Solutions with a Large Network of Innovation & Delivery Centers.', 'Experience Energy', '', '', ''),
(2, 'wipro', 1, 'wipro.jpg', 'Global company delivering innovation-led strategy, technology, and business consulting services. ', 'Be Global And Responsible', '', '', ''),
(3, 'Infosys', 1, 'infosis.jpg', 'To be a globally respected corporation that provides best-of-breed business solutions, leveraging technology, delivered by best-in-class people.', 'Powered by Intellect, Driven by Values', '', '', ''),
(4, 'Federal Bank', 1, 'federal1.jpg', 'Federal Bank is a pioneer in the banking sector in India by being the first bank to digitalize all its branches in the country. ', 'Your Perfect Banking Partner', '', '', ''),
(5, 'South Indian Bank', 1, 'southindian.jpg', 'Welcome to South Indian Bank, The best choice for your Personal Banking, NRI Banking, Business Banking, Online Banking. ', 'Experience Next Gen Banking', '', '', ''),
(8, 'Cognizant', 1, 'cognizant.jpg', 'Cognizant is an American multinational corporation that provides IT services, including digital, technology, consulting, and operations services.', 'Embrace Cultural Values', '', '', ''),
(10, 'UST Global', 1, 'UST.jpg', 'UST Global is a leading provider of end-to-end IT services and solutions for Global 1000 companies. We use a client-centric Global Engagement Model that combines local, senior, on-site resources with the cost, scale, and quality advantages of off-shore operations.', 'Transforming Lives', '', '', ''),
(27, 'Byjus The learning App', 1, '57fb2e8deaa00d3e331a50d33702f102.jpg', 'BYJUâ€™S-The Learning App is the worldâ€™s largest learning app for school students with 16 million registered students on its platform.', 'Fall in Love with learning', '', '', ''),
(36, 'IBM', 1, 'd634b391f2480e53d480b4e395bcd3c5.jpg', 'International Business Machines (IBM), is a global technology company that provides hardware, software, cloud-based services and cognitive computing. Founded in 1911 following the merger of four companies in New York State by Charles Ranlett Flint, it was originally called Computing-Tabulating-Recording Company.', 'THINK', 'Mohandas', 'mohandas@gmail.com', '9854126389'),
(37, 'dfgdsgg', 0, '52a819cf748591a4b0a0679003bb72fd.jpg', 'sdgsdgdsgsd', 'sgdsdgsd', 'weew', 'weew@ge.yherher', '9696968585');

-- --------------------------------------------------------

--
-- Table structure for table `placed`
--

CREATE TABLE `placed` (
  `placed_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Course` varchar(40) NOT NULL,
  `Department` varchar(40) NOT NULL,
  `Company` varchar(40) NOT NULL,
  `Designation` varchar(40) NOT NULL,
  `YOP` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placed`
--

INSERT INTO `placed` (`placed_id`, `stud_id`, `Name`, `Course`, `Department`, `Company`, `Designation`, `YOP`, `status`) VALUES
(1, 3, 'Antony  Jacob', 'MCA', 'Master of computer Application (Lateral)', '1', 'Software Engineer', 2020, 1),
(2, 6, 'David p John', 'Btech', 'Information Technology', '5', 'Marketing manager', 2020, 1),
(3, 6, 'David p John', 'Btech', 'Information Technology', '3', 'Software Engineer', 2020, 1),
(4, 5, 'Thomas p Johnson', 'MCA', 'Master of Computer Applications', '2', 'Software Engineer', 2020, 1);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `result_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `result_doc` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rules`
--

CREATE TABLE `rules` (
  `rule_id` int(11) NOT NULL,
  `doc` varchar(100) NOT NULL,
  `date1` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rules`
--

INSERT INTO `rules` (`rule_id`, `doc`, `date1`, `status`) VALUES
(1, 'Placement Rules.pdf', '2020-03-04', 0),
(18, 'bb0f164abf47c91e1c48f868283ec133.pdf', '2020-04-22', 0),
(19, '2a81b5bff39c9acbab4ef5a53ed4fc93.pdf', '2020-04-22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `state_id` int(11) NOT NULL DEFAULT 0,
  `state_name` varchar(40) NOT NULL,
  `country_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`, `country_id`) VALUES
(0, 'Andhra Pradesh', 1),
(1, 'Arunachal Pradesh', 1),
(2, 'Assam', 1),
(3, 'Bihar', 1),
(4, 'Chhattisgarh', 1),
(5, 'Goa', 1),
(6, 'Gujarat', 1),
(7, 'Haryana', 1),
(8, 'Himachal Pradesh', 1),
(9, 'Jammu and Kashmir', 1),
(10, 'Jharkhand', 1),
(11, 'Karnataka', 1),
(12, 'Kerala', 1),
(13, 'Madhya Pradesh', 1),
(14, 'Maharashtra', 1),
(15, 'Manipur', 1),
(16, 'Meghalaya', 1),
(17, 'Mizoram', 1),
(18, 'Nagaland', 1),
(19, 'Odisha', 1),
(20, 'Punjab', 1),
(21, 'Rajasthan', 1),
(22, 'Sikkim', 1),
(23, 'Tamil Nadu', 1),
(24, 'Telangana', 1),
(25, 'Tripura', 1),
(26, 'Uttar Pradesh', 1),
(27, 'Uttarakhand', 1),
(28, 'West Bengal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `stud`
--

CREATE TABLE `stud` (
  `stud_id` int(11) NOT NULL,
  `University_Reg_No` varchar(15) DEFAULT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `First_Name` varchar(15) DEFAULT NULL,
  `Middle_Name` varchar(15) DEFAULT NULL,
  `Last_Name` varchar(15) DEFAULT NULL,
  `Full_Name` varchar(50) DEFAULT NULL,
  `Placed` varchar(10) DEFAULT NULL,
  `dept_id` int(30) DEFAULT NULL,
  `Mobile` varchar(15) DEFAULT NULL,
  `Alt_Mobile` varchar(15) DEFAULT NULL,
  `Alt_Email` varchar(30) DEFAULT NULL,
  `DoB` varchar(15) DEFAULT NULL,
  `Gender` varchar(15) DEFAULT NULL,
  `Father_Name` varchar(20) DEFAULT NULL,
  `Mother_Name` varchar(20) DEFAULT NULL,
  `House_Name` varchar(30) DEFAULT NULL,
  `Street` varchar(30) DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `dist_id` int(30) DEFAULT NULL,
  `state_id` int(30) DEFAULT NULL,
  `Pincode` varchar(30) DEFAULT NULL,
  `country_id` int(30) DEFAULT NULL,
  `login_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `year_of_pass` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud`
--

INSERT INTO `stud` (`stud_id`, `University_Reg_No`, `Title`, `First_Name`, `Middle_Name`, `Last_Name`, `Full_Name`, `Placed`, `dept_id`, `Mobile`, `Alt_Mobile`, `Alt_Email`, `DoB`, `Gender`, `Father_Name`, `Mother_Name`, `House_Name`, `Street`, `City`, `dist_id`, `state_id`, `Pincode`, `country_id`, `login_id`, `status`, `course`, `year_of_pass`) VALUES
(1, 'ajg18kiu-d019', 'Mr', 'Lakshya', '', 'Rajasekharan', 'Lakshya  Rajasekharan', '0', 13, '9856478535', '9567491021', 'thridev1995@gmail.com', '17/8/1995', 'Female', 'Rajasekharan', 'akhila p', 'Newhouse', 'trivandram', 'trivandram', 1, 12, '685512', 1, 2, 1, 2, 2020),
(3, 'ajc18mca-D010', 'Mr', 'Antony', '', 'Jacob', 'Antony  Jacob', '1', 13, '9685785426', '9544156658', 'antony123@gmail.com', '11/6/1997', 'Male', 'Jacob Mathew', 'Daisy Jacob', 'Karukappally', 'Anakkal', 'Kanjirappally', 5, 12, '686508', 1, 4, 0, 2, 2020),
(4, 'ajc16ece-D023', 'Ms', 'Joseline', '', 'joies', 'Joseline  joies', '0', 4, '9685784251', '8090879678', 'joies@gmail.com', '22/2/1997', 'Female', 'Joies Jose', 'Jinu joies', 'Karapally', 'puthupally', 'kottayam', 5, 12, '686533', 1, 5, 0, 1, 2020),
(5, 'ajc18mca-D043', 'Mr', 'Thomas', 'p', 'Johnson', 'Thomas p Johnson', '1', 10, '9093958216', '9405365120', 'Thom@gmail.com', '27/6/1997', 'Male', 'Johnson', 'Liya', 'Puthuparambil', 'parathodu', 'kanjirappally', 5, 12, '686512', 1, 7, 0, 2, 2020),
(6, 'ajc16ece-D044', 'Mr', 'David', 'p', 'John', 'David p John', '1', 6, '9857486895', '9987485764', 'david@mca.ajce.in', '16/7/1996', 'Male', 'John Joseph', 'Dayana John', 'Kuttarappally', 'Pampady', 'kottayam', 5, 12, '686521', 1, 8, 1, 1, 2020),
(7, 'ajc19mca-D022', 'Mr', 'Sarun', '', 'Chacko', 'Sarun  Chacko', '1', 10, '9858968766', '9544156658', 'sarunchacko@gmail.com', '10/7/1998', 'Male', 'Chacko', 'Dora', 'Kollakulavil', 'Thodupuzha', 'Thodupuzha', 6, 12, '686537', 1, 9, 1, 2, 2020),
(10, 'AJC18MCA-D027', 'Mr', 'Jefin', '', 'Shaji', 'Jefin  Shaji', '0', 13, '8547635671', '8113090878', '', '1997-01-13', 'Male', 'Shaji Mathew', 'Ancy Shaji', 'Chackalayil', 'Karimkunnam', 'Thodupuzha', 6, 12, '686651', 1, 12, 1, 2, 2020),
(11, 'AJC17EEE-D011', 'Ms', 'Reenu', 'Mary', 'Jacob', 'Reenu Mary Jacob', '0', 5, '8075464156', '9544156658', ' ', '1999-10-14', 'Female', 'Jacob Mathew', 'Daisy Jacob', 'Karukappally', 'Anakkal', 'Kanjirappally', 5, 12, '686508', 1, 16, 1, 1, 2021),
(13, 'AJC16ECE-D033', 'Ms', 'Dona', 'Rose', 'Thomas', 'Dona Rose Thomas', '0', 4, '8113090878', '8596878475', 'antony12@gmail.com', '1998-08-14', 'Female', 'Thomas Mathew', 'Molly Thomas', 'Kuzhithottu', 'Pambadi', 'Pambadi', 5, 12, '686502', 1, 19, 1, 1, 2020),
(14, '126b143601624', 'Ms', 'Rinu', 'Mary', 'Jacob', 'Rinu Mary Jacob', '0', 7, '8075464156', '', ' ', '2000-10-14', 'Female', 'Jacob Mathew', 'Daisy Antony', 'Karukappally', 'Anakkal', 'Kanjirappallyallay', 5, 12, '686508', 1, 20, 1, 1, 2022),
(15, 'Ajc18MtEc-D19', 'Mr', 'John', 'C', 'Joseph', 'John C Joseph', '0', 2, '9544156658', '', ' ', '1996-04-10', 'Male', 'Joseph', 'Sherin', 'Chemkeriyil', 'Anakkal', 'Kanjirappally', 5, 12, '686508', 1, 21, 1, 3, 2020),
(16, 'AJC17ECE-D022', 'Mr', 'Shankar', 'v', 'Shaji', 'Shankar v Shaji', '0', 4, '8113090878', '', ' ', '1997-02-21', 'Male', 'Shaji', 'Rani', 'kalayazhayil', 'kunnel', 'kanjirappally', 5, 12, '686507', 1, 22, 1, 3, 2020);

-- --------------------------------------------------------

--
-- Stand-in structure for view `stud_info`
-- (See below for the actual view)
--
CREATE TABLE `stud_info` (
`stud_id` int(11)
,`University_Reg_No` varchar(15)
,`Full_Name` varchar(50)
,`Placed` varchar(10)
,`dept_id` int(30)
,`Mobile` varchar(15)
,`Alt_Mobile` varchar(15)
,`Alt_Email` varchar(30)
,`DoB` varchar(15)
,`Gender` varchar(15)
,`Father_Name` varchar(20)
,`Mother_Name` varchar(20)
,`House_Name` varchar(30)
,`Street` varchar(30)
,`City` varchar(30)
,`dist_id` int(30)
,`state_id` int(30)
,`Pincode` varchar(30)
,`country_id` int(30)
,`login_id` int(11)
,`course` int(11)
,`year_of_pass` int(11)
,`email` varchar(30)
,`academic_id` int(11)
,`Aggr_CGPA` varchar(5)
,`Aggr_Percentage` varchar(4)
,`CURRENT_ARREARS` int(2)
,`HISTORY_OF_ARREARS` varchar(100)
,`10th_p` varchar(5)
,`10th_CGPA` varchar(6)
,`10th_YoP` varchar(5)
,`10th_Board` varchar(30)
,`10th_School` varchar(100)
,`10th_State_of_school` int(11)
,`12th_p` varchar(30)
,`12th_CGPA` varchar(5)
,`12th_YoP` varchar(30)
,`12th_Board` varchar(30)
,`12th_School` varchar(100)
,`12th_State_of_School` int(11)
,`UG_Course` varchar(80)
,`UG_P` varchar(6)
,`UG_CGPA` varchar(6)
,`UG_YoP` varchar(6)
,`UG_College` varchar(100)
,`state_of_UG` varchar(30)
,`UG_University` varchar(100)
,`PG_University` varchar(100)
,`Technical_Skills` varchar(100)
,`Work_Experience` varchar(100)
,`Certifications` varchar(100)
,`Internships` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `stud_list`
-- (See below for the actual view)
--
CREATE TABLE `stud_list` (
`stud_id` int(11)
,`University_Reg_No` varchar(15)
,`Full_Name` varchar(50)
,`Placed` varchar(10)
,`department_name` varchar(50)
,`Mobile` varchar(15)
,`Alt_Mobile` varchar(15)
,`Alt_Email` varchar(30)
,`DoB` varchar(15)
,`Gender` varchar(15)
,`Father_Name` varchar(20)
,`Mother_Name` varchar(20)
,`House_Name` varchar(30)
,`Street` varchar(30)
,`City` varchar(30)
,`dist_name` varchar(40)
,`state_name` varchar(40)
,`Pincode` varchar(30)
,`country_name` varchar(40)
,`login_id` int(11)
,`course` int(11)
,`year_of_pass` int(11)
,`email` varchar(30)
,`academic_id` int(11)
,`Aggrigate_CGPA` varchar(5)
,`Aggrigate_Percentage` varchar(4)
,`Current_Arrears` int(2)
,`History_of_Arrears` varchar(100)
,`Tenth_Percentage` varchar(5)
,`Tenth_CGPA` varchar(6)
,`Tenth_Year_of_pass` varchar(5)
,`Tenth_Board` varchar(30)
,`Tenth_School_Name` varchar(100)
,`Tenth_state_of_School` int(11)
,`Twelfth_Percentage` varchar(30)
,`Twelfth_CGPA` varchar(5)
,`Twelfth_Year_of_pass` varchar(30)
,`Twelfth_Board` varchar(30)
,`Twelfth_School_Name` varchar(100)
,`Twelfth_state_of_School` int(11)
,`UG_Course` varchar(80)
,`UG_Percentage` varchar(6)
,`UG_CGPA` varchar(6)
,`UG_Year_of_pass` varchar(6)
,`UG_College` varchar(100)
,`state_of_UG` varchar(30)
,`UG_University` varchar(100)
,`PG_University` varchar(100)
,`Technical_Skills` varchar(100)
,`Work_Experience` varchar(100)
,`Certifications` varchar(100)
,`Internships` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `upload_id` int(11) NOT NULL,
  `title_id` int(30) NOT NULL,
  `upload_name` varchar(50) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`upload_id`, `title_id`, `upload_name`, `stud_id`, `status`) VALUES
(1, 1, 'd76d1822a589dd227f52bb47a47b1683.pdf', 5, 1),
(2, 2, '72d78ae71fd32209740dfdbe9a69dfeb.pdf', 5, 1),
(3, 3, '112ccf2842df2aea476b6aad4cde1014.pdf', 5, 0),
(4, 3, '112ccf2842df2aea476b6aad4cde1014.pdf', 5, 0),
(5, 3, '112ccf2842df2aea476b6aad4cde1014.pdf', 5, 1),
(6, 1, 'ef686e86717a717e5e2ce6a3be5c5707.pdf', 11, 0),
(7, 1, 'ef686e86717a717e5e2ce6a3be5c5707.pdf', 11, 0),
(8, 1, 'ef686e86717a717e5e2ce6a3be5c5707.pdf', 11, 0),
(9, 1, 'ef686e86717a717e5e2ce6a3be5c5707.pdf', 11, 0),
(10, 1, '04f1b2b932c8572d75eda3d6157b9ca4.pdf', 3, 1),
(11, 1, 'c6845f043627ab8b7c42bc1334d8eca1.pdf', 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `upload_title`
--

CREATE TABLE `upload_title` (
  `title_id` int(11) NOT NULL,
  `title` varchar(40) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_title`
--

INSERT INTO `upload_title` (`title_id`, `title`, `status`) VALUES
(1, 'Tenth Certificate', 1),
(2, 'Plus Two Certificate', 1),
(3, 'Degree Certificate', 1),
(4, 'PG certificate', 1),
(5, 'Experience Certificate', 1),
(6, 'jfgjgfg', 0),
(7, 'Resume', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `stud_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `profile_image`, `stud_id`, `status`) VALUES
(1, '1592571296-6_marknelson_lighthouse_b.jpg', 3, 1),
(2, '1594096448-car4.jpg', 16, 1);

-- --------------------------------------------------------

--
-- Structure for view `stud_info`
--
DROP TABLE IF EXISTS `stud_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`id13080501_camra`@`%` SQL SECURITY DEFINER VIEW `stud_info`  AS  select `t1`.`stud_id` AS `stud_id`,`t1`.`University_Reg_No` AS `University_Reg_No`,`t1`.`Full_Name` AS `Full_Name`,`t1`.`Placed` AS `Placed`,`t1`.`dept_id` AS `dept_id`,`t1`.`Mobile` AS `Mobile`,`t1`.`Alt_Mobile` AS `Alt_Mobile`,`t1`.`Alt_Email` AS `Alt_Email`,`t1`.`DoB` AS `DoB`,`t1`.`Gender` AS `Gender`,`t1`.`Father_Name` AS `Father_Name`,`t1`.`Mother_Name` AS `Mother_Name`,`t1`.`House_Name` AS `House_Name`,`t1`.`Street` AS `Street`,`t1`.`City` AS `City`,`t1`.`dist_id` AS `dist_id`,`t1`.`state_id` AS `state_id`,`t1`.`Pincode` AS `Pincode`,`t1`.`country_id` AS `country_id`,`t1`.`login_id` AS `login_id`,`t1`.`course` AS `course`,`t1`.`year_of_pass` AS `year_of_pass`,`t2`.`email` AS `email`,`t3`.`academic_id` AS `academic_id`,`t3`.`Aggr_CGPA` AS `Aggr_CGPA`,`t3`.`Aggr_Percentage` AS `Aggr_Percentage`,`t3`.`CURRENT_ARREARS` AS `CURRENT_ARREARS`,`t3`.`HISTORY_OF_ARREARS` AS `HISTORY_OF_ARREARS`,`t3`.`10th_p` AS `10th_p`,`t3`.`10th_CGPA` AS `10th_CGPA`,`t3`.`10th_YoP` AS `10th_YoP`,`t3`.`10th_Board` AS `10th_Board`,`t3`.`10th_School` AS `10th_School`,`t3`.`10th_State_of_school` AS `10th_State_of_school`,`t3`.`12th_p` AS `12th_p`,`t3`.`12th_CGPA` AS `12th_CGPA`,`t3`.`12th_YoP` AS `12th_YoP`,`t3`.`12th_Board` AS `12th_Board`,`t3`.`12th_School` AS `12th_School`,`t3`.`12th_State_of_School` AS `12th_State_of_School`,`t3`.`UG_Course` AS `UG_Course`,`t3`.`UG_P` AS `UG_P`,`t3`.`UG_CGPA` AS `UG_CGPA`,`t3`.`UG_YoP` AS `UG_YoP`,`t3`.`UG_College` AS `UG_College`,`t3`.`state_of_UG` AS `state_of_UG`,`t3`.`UG_University` AS `UG_University`,`t3`.`PG_University` AS `PG_University`,`t3`.`Technical_Skills` AS `Technical_Skills`,`t3`.`Work_Experience` AS `Work_Experience`,`t3`.`Certifications` AS `Certifications`,`t3`.`Internships` AS `Internships` from ((`stud` `t1` join `login` `t2`) join `academic` `t3`) where `t1`.`login_id` = `t2`.`login_id` and `t1`.`stud_id` = `t3`.`stud_id` ;

-- --------------------------------------------------------

--
-- Structure for view `stud_list`
--
DROP TABLE IF EXISTS `stud_list`;

CREATE ALGORITHM=UNDEFINED DEFINER=`id13080501_camra`@`%` SQL SECURITY DEFINER VIEW `stud_list`  AS  (select distinct `t1`.`stud_id` AS `stud_id`,`t1`.`University_Reg_No` AS `University_Reg_No`,`t1`.`Full_Name` AS `Full_Name`,`t1`.`Placed` AS `Placed`,`t4`.`department_name` AS `department_name`,`t1`.`Mobile` AS `Mobile`,`t1`.`Alt_Mobile` AS `Alt_Mobile`,`t1`.`Alt_Email` AS `Alt_Email`,`t1`.`DoB` AS `DoB`,`t1`.`Gender` AS `Gender`,`t1`.`Father_Name` AS `Father_Name`,`t1`.`Mother_Name` AS `Mother_Name`,`t1`.`House_Name` AS `House_Name`,`t1`.`Street` AS `Street`,`t1`.`City` AS `City`,`t6`.`dist_name` AS `dist_name`,`t7`.`state_name` AS `state_name`,`t1`.`Pincode` AS `Pincode`,`t5`.`country_name` AS `country_name`,`t1`.`login_id` AS `login_id`,`t1`.`course` AS `course`,`t1`.`year_of_pass` AS `year_of_pass`,`t3`.`email` AS `email`,`t2`.`academic_id` AS `academic_id`,`t2`.`Aggr_CGPA` AS `Aggrigate_CGPA`,`t2`.`Aggr_Percentage` AS `Aggrigate_Percentage`,`t2`.`CURRENT_ARREARS` AS `Current_Arrears`,`t2`.`HISTORY_OF_ARREARS` AS `History_of_Arrears`,`t2`.`10th_p` AS `Tenth_Percentage`,`t2`.`10th_CGPA` AS `Tenth_CGPA`,`t2`.`10th_YoP` AS `Tenth_Year_of_pass`,`t2`.`10th_Board` AS `Tenth_Board`,`t2`.`10th_School` AS `Tenth_School_Name`,`t2`.`10th_State_of_school` AS `Tenth_state_of_School`,`t2`.`12th_p` AS `Twelfth_Percentage`,`t2`.`12th_CGPA` AS `Twelfth_CGPA`,`t2`.`12th_YoP` AS `Twelfth_Year_of_pass`,`t2`.`12th_Board` AS `Twelfth_Board`,`t2`.`12th_School` AS `Twelfth_School_Name`,`t2`.`12th_State_of_School` AS `Twelfth_state_of_School`,`t2`.`UG_Course` AS `UG_Course`,`t2`.`UG_P` AS `UG_Percentage`,`t2`.`UG_CGPA` AS `UG_CGPA`,`t2`.`UG_YoP` AS `UG_Year_of_pass`,`t2`.`UG_College` AS `UG_College`,`t2`.`state_of_UG` AS `state_of_UG`,`t2`.`UG_University` AS `UG_University`,`t2`.`PG_University` AS `PG_University`,`t2`.`Technical_Skills` AS `Technical_Skills`,`t2`.`Work_Experience` AS `Work_Experience`,`t2`.`Certifications` AS `Certifications`,`t2`.`Internships` AS `Internships` from ((((((`stud` `t1` join `academic` `t2`) join `login` `t3`) join `department` `t4`) join `country` `t5`) join `district` `t6`) join `state` `t7`) where `t1`.`login_id` = `t3`.`login_id` and `t1`.`stud_id` = `t2`.`stud_id` and `t1`.`state_id` = `t7`.`state_id` and `t1`.`dept_id` = `t4`.`dept_id` and `t1`.`country_id` = `t5`.`country_id` and `t1`.`dist_id` = `t6`.`dist_id`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic`
--
ALTER TABLE `academic`
  ADD PRIMARY KEY (`academic_id`);

--
-- Indexes for table `aptitude`
--
ALTER TABLE `aptitude`
  ADD PRIMARY KEY (`aptitude_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `caution`
--
ALTER TABLE `caution`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`Designation_id`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`dist_id`);

--
-- Indexes for table `drive_elig`
--
ALTER TABLE `drive_elig`
  ADD PRIMARY KEY (`elig_id`);

--
-- Indexes for table `drive_reg`
--
ALTER TABLE `drive_reg`
  ADD PRIMARY KEY (`drive_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `login_id` (`login_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `job_notification`
--
ALTER TABLE `job_notification`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`);
ALTER TABLE `login` ADD FULLTEXT KEY `user_type` (`user_type`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notif_id`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `placed`
--
ALTER TABLE `placed`
  ADD PRIMARY KEY (`placed_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `rules`
--
ALTER TABLE `rules`
  ADD PRIMARY KEY (`rule_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `stud`
--
ALTER TABLE `stud`
  ADD PRIMARY KEY (`stud_id`),
  ADD KEY `login_id` (`login_id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `upload_title`
--
ALTER TABLE `upload_title`
  ADD PRIMARY KEY (`title_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic`
--
ALTER TABLE `academic`
  MODIFY `academic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `aptitude`
--
ALTER TABLE `aptitude`
  MODIFY `aptitude_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `caution`
--
ALTER TABLE `caution`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `Designation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `dist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `drive_elig`
--
ALTER TABLE `drive_elig`
  MODIFY `elig_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `drive_reg`
--
ALTER TABLE `drive_reg`
  MODIFY `drive_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `job_notification`
--
ALTER TABLE `job_notification`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notif_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `placed`
--
ALTER TABLE `placed`
  MODIFY `placed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rules`
--
ALTER TABLE `rules`
  MODIFY `rule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `stud`
--
ALTER TABLE `stud`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `upload_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `upload_title`
--
ALTER TABLE `upload_title`
  MODIFY `title_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
