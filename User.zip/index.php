<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script>window.location("Home/index.php");</script>
</head>
<?php header("Location:Home/index.php"); ?>
</html>