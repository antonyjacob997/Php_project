
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Cam-RA</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
    <?php
// Initialize the session
session_start();
 
// Unset all of the session variables
$_SESSION = array();
 
// Destroy the session.
session_destroy();
 include 'connection.php';
?>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
      
      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo mr-auto w-25"><a href="index.php">Cam-RA</a></div>

          <div class="mx-auto text-center">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mx-auto d-none d-lg-block  m-0 p-0">
                <li><a href="#home-section" class="nav-link">Home</a></li>
                <li><a href="#courses-section" class="nav-link">Companies</a></li>
                <li><a href="#teachers-section" class="nav-link">Placement Cell</a></li>
              </ul>
            </nav>
          </div>

          <div class="ml-auto w-25">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block m-0 p-0">
                
                <li><a href="../Admin/registration.php">Register</a></li>
                                
              </ul>
              
                            
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black float-right"><span class="icon-menu h3"></span></a>
          </div>

              </div>
      </div>
      
    </header>

    <div class="intro-section" id="home-section">
      
      <div class="slide-1" style="background-image: url('images/hero_1.jpg');" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-12">
              <div class="row align-items-center">
                <div class="col-lg-6 mb-4">
                  <h1  data-aos="fade-up" data-aos-delay="100">Learn From The Expert</h1>
                  <p class="mb-4"  data-aos="fade-up" data-aos-delay="200">Department of Placement and Training caters for enhancing not only the employability skills of the passing out Amalites but also the overall development of their personality. The dept. organizes on campus and off campus recruitments and pre-placement training programmes through Aptitude tests, Group Discussions, Interviews and presentation skills in collaboration with the Dept. of Humanities and core departments.</p>
                  

                </div>

                <div class="col-lg-5 ml-auto" data-aos="fade-up" data-aos-delay="500">
                  <body>
  <div id="form_container" style="width: 400px">
    <h2 id="title">Login</h2>
    <form id="form" accept-charset="UTF-8"  method="POST" class="form-box" >
      
      <ul class="errorMessages"></ul>
                                                  
      <div class="form-group">
                      <input  id="fname" type="email" class="form-control" name="email" placeholder="Email Address" required="required" autocomplete="off" onblur="requiredField(this)">
                    </div>
      <div class="form-group">
                      <input  id="fname" type="password" class="form-control" name="password" required="required" placeholder="Password" onblur="passwordCheck(this)">
                    </div>
      <div class="form-group mb-4">
                         <p><a href="../Admin/forget_psw.php">forgot password..?</p>
                    </div>
      
      <div class="form-group">
                      <input type="submit" name="submit" class="btn btn-primary btn-pill" value="Login">
                    </div>
    </form>
  </div>
</body>

                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>

    
    <div class="site-section courses-title" id="courses-section">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-lg-7 text-center" data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">Companies</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section courses-entry-wrap"  data-aos="fade-up" data-aos-delay="50">
      <div class="container">
        <div class="row">

          <div class="owl-carousel col-12 nonloop-block-14">
<?php 
  $sql="SELECT * from organization where status=1";
  $resu=mysqli_query($conn,$sql);
  $p=1;
  if(mysqli_num_rows($resu) > 0){
    while ($row1=mysqli_fetch_array($resu)) {
 ?>
            <div class="course bg-white" style="height:670px">
              <figure class="m-0">
                <a href="course-single.html"><img src="<?php echo'../Admin/images/'.$row1['img_name']; ?>" alt="Image" class="img-fluid" width="300px" height="300px"></a>
              </figure>
              <div class="course-inner-text py-4 px-4">
                <h3><a href="#"><?php echo $row1['captions']; ?></a></h3>
                <p><?php echo $row1['description']; ?> </p>
              </div>
              <!--<div class="d-flex border-top stats" style="position:absolute;margin-top:660px">-->
              <!--  <div class="py-3 px-4 w-25 ml-auto border-left"><span class="icon-chat"></span> <?php //echo $p; ?></div>-->
              <!--</div>-->
            </div>
<?php  
$p=$p+1;   
    }
  }
 ?>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-7 text-center">
            <button class="customPrevBtn btn btn-primary m-1">Prev</button>
            <button class="customNextBtn btn btn-primary m-1">Next</button>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section bg-image overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-8 text-center testimony">
            <img src="images/ajce.jpg" alt="Image" class="img-fluid w-25 mb-4 rounded-circle">
            <h3 class="mb-4">Amal Jyothi</h3>
            <blockquote>
              <p>&ldquo; Amal Jyothi College of Engineering, Kanjirapally, is the first new generation engineering college in Kerala to secure the prestigious NBA accreditation for prime departments and the first engineering college having NAAC accreditation with ‘A’ grade. Amal Jyothi is approved by the All India Council for Technical Education (AICTE), New Delhi. &rdquo;</p>
            </blockquote>
          </div>
        </div>
      </div>
    </div>  

   <?php 
      include 'sweetalerttest.php';
   ?>

    <div class="site-section" id="teachers-section">
      <div class="container">

        <div class="row mb-5 justify-content-center">
          <div class="col-lg-7 mb-5 text-center"  data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">Placement Cell</h2>
            <p class="mb-5">Department of Placement and Training caters for enhancing not only the employability skills of the passing out Amalites but also the overall development of their personality.  Close on the heels of placement drives, the Placement Assistance Cell makes an evaluation of the performance of our students. This objective appraisal enables us to identify strengths and weaknesses of the candidates and select the strategies for improvement. </p>
          </div>
        </div>

        <div class="row">

          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="teacher text-center">
              <img src="../Admin/images/tho.jpeg" alt="Image" class="img-fluid w-50 rounded-circle mx-auto mb-4">
              <div class="py-2">
                <h3 class="text-black">Mr. THOMAS PAUL MBA</h3>
                <p class="position">Placement Officer</p>
                <p>    + 91 9447121215
                       thomaspaul@amaljyothi.ac.in
                      </p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="teacher text-center">
              <img src="../Admin/images/rony.jpg" alt="Image" class="img-fluid w-50 rounded-circle mx-auto mb-4">
              <div class="py-2"><br>
                <h3 class="text-black">Mr. RONY TOM MCA</h3>
                <p class="position">Assistant Placement Officer</p>
                <p>+ 91 9656077005
                   ronytom@amaljyothi.ac.in</p>
              </div>
            </div>
          </div> 
          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="teacher text-center">
              <img src="../Admin/images/antony.jpg" alt="Image" class="img-fluid w-50 rounded-circle mx-auto mb-4">
              <div class="py-2"><br><br>
                <h3 class="text-black">Mr. ANTONY JACOB MCA</h3>
                <p class="position">Developed By</p>
                <p>    + 91 9544756658
                       antonyjacob997@gmail.com
                      </p>
              </div>
            </div>
          </div>
          

        </div>
      </div>
    </div>
  </div>
<div class="wrapper" style="background-color: grey">    
  <div class="footer">
    <div class="container" >  <br><br>
      <p style="color: white">
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by Cam-RA
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      </p>
    </div>
    </div><br>
  </div>
  
    
<?php
  if(isset($_POST['submit'])){
session_start();


  $user=trim($_POST['email']);
  $pass=md5(trim($_POST['password']));



  $sql="select login_id,user_type,status from login where email='$user' and password='$pass'";

  $result=mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)>0)
    {
      $row = mysqli_fetch_array($result);
        $type=$row['user_type'];
        $status=$row['status'];
        $id=$row['login_id'];
            if($type==="Student" && $status==="1"){
              $_SESSION["loggedin"] = "$id";
                  if($psw==1){
                    ?><script >window.location='../User/resetpsw.php'</script>
                    <?php
                    
                  }
                  $qry="SELECT org_id,date2 from notification where notif_id in(SELECT notif_id FROM drive_reg WHERE feed=1 and stud_id in (select stud_id from stud where login_id=$id))";
                        $result2=mysqli_query($conn,$qry);
                        if(mysqli_num_rows($result2)>0)
                        {
                          $row2 = mysqli_fetch_array($result2);
                            $date1=date("Y-m-d");
                            $date2=$row2['date2'];
                            $org_id=$row2['org_id'];
                            if($date1 > $date2){
                               $_SESSION["org_id"]="$org_id";
                              ?><script >window.location='../User/feedback.php'</script>
                              <?php
                             
                            }else{
                              ?><script >window.location='../User/personal.php'</script>
                              <?php
                            }
                        }
                        else{
                          ?><script >window.location='../User/personal.php'</script>
                              <?php
                        }
            }
            
            elseif ($type==="Placement officer") {
              $_SESSION["loggedin"] = "$id";
              
              ?><script >window.location='../Admin/admin_home.php'</script>
              <?php
            }
            elseif($status==="2")
            {
              $_SESSION["loggedin"] = "$id";
              
              ?><script >window.location='../Admin/admin_home.php'</script>
              <?php
            }
            else{
                $message = "Your account is blocked please contact placement officer...";
                    echo "<script>alert('$message');
                window.location='index.php'</script>";
            }
    } 
  else
  {
        echo "<script>
     
        swal('Oops...','Incorrect username or password..!','error');
        
      </script>";
  }
}
 ?>



 <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>