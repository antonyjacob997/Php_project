<!DOCTYPE HTML>
<html>
<head>
<title>Cam-RA</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='http://fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<script src="js/amcharts.js"></script>	
<script src="js/serial.js"></script>	
<script src="js/light.js"></script>	
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   <!--pie-chart--->
<script src="js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#3bb2d0',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#fbb03b',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ed6498',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
</head> 
<body>
<script src='../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script></div>
<script src="../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src='https://www.googletagmanager.com/gtag/js?id=UA-149859901-1'></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149859901-1');
</script>

<script>
     window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
     ga('create', 'UA-149859901-1', 'demo.w3layouts.com');
     ga('require', 'eventTracker');
     ga('require', 'outboundLinkTracker');
     ga('require', 'urlChangeTracker');
     ga('send', 'pageview');
   </script>
<script async src='../../../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: ../index.php");
    exit;
}
else{
    $id=$_SESSION["loggedin"];
    $qry="SELECT Full_Name from stud where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $Name=$row['Full_Name'];
    }
    $_SESSION["loggedin"] = "$id";
}
?>

	<link rel="stylesheet" href="../../../../../images/demobar_w3_16oct2019.css">
	<!-- Demo bar start -->


   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<div class="header-section">
			<!-- top_bg --><br><br><br>
						<div class="top_bg">
							
								<div class="header_top">
									<div class="top_right">
										
									</div>
									<div class="top_left">
										<h2> <?php echo $Name ?></h2>
										<p></p>
									</div>
										<div class="clearfix"> </div>
								</div>
							
						</div>
					<div class="clearfix"></div>
				<!-- /top_bg -->
				</div>
				<div class="header_bg">
						
							<div class="header">
								<div class="head-t">
									<div class="logo">
										<h1 style="font-family:Old English Text MT;">Cam-RA</h1>
										<p style="font-family:Old English Text MT;">Campus Recruiter Assistant</p>
									</div>
										<!-- start header_right -->
									<div class="header_right">
										<div class="rgt-bottom">
											<div class="log">
												<div class="login" hidden="">
													<div id="loginContainer"><a id="loginButton" class=""><span>Login</span></a>
														<div id="loginBox" style="display: none;">                
															<form id="loginForm">
																	<fieldset id="body">
																		<fieldset>
																			  <label for="email">Email Address</label>
																			  <input type="text" name="email" id="email">
																		</fieldset>
																		<fieldset>
																				<label for="password">Password</label>
																				<input type="password" name="password" id="password">
																		 </fieldset>
																		<input type="submit" id="login" value="Sign in">
																		<label for="checkbox"><input type="checkbox" id="checkbox"> <i>Remember me</i></label>
																	</fieldset>
																<span><a href="#">Forgot your password?</a></span>
															</form>
														</div>
													</div>
												</div>
											</div>
											<div class="reg">
												<a href="register.html" hidden="">REGISTER</a>
											</div>
										<div class="cart box_1">
											<a href="checkout.html">
												<h3 hidden> <span class="simpleCart_total" hidden="">$0.00</span> (<span id="simpleCart_quantity" hidden="" class="simpleCart_quantity">0</span> items)<img src="images/bag.png" alt="" hidden=""></h3>
											</a>	
											<p><a href="javascript:;" class="simpleCart_empty"></a></p>
											<div class="clearfix"> </div>
										</div>
										<div class="create_btn">
											<a href="logout.php">LOGOUT</a>
										</div>
										<div class="clearfix"> </div>
									</div>
									
									<div class="clearfix"> </div>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					
				</div>

					<!-- //header-ends -->
				<!---728x90--->

				<!--content-->
			<div class="content">
					
			<!---728x90--->

						<!--//area-->
							<!--  -->
							<div class="col-md-9 mid-content-top">
								<div class="middle-content">
									<h3>Tips for Job Interview..!
									</h3>
									<!-- start content_slider -->
								<div>
									<p data-toggle="tooltip" title="An interviewer may ask how you perceive his company's position in its industry, who the firm's competitors are, what its competitive advantages are, and how it should best go forward. For this reason, avoid trying to thoroughly research a dozen different industries. Focus your job search on just a few industries instead.">1. Start by researching the company and your interviewers</p>

									<p data-toggle="tooltip" title="Prepare to go into every interview with three to five key selling points in mind, such as what makes you the best candidate for the position. Have an example of each selling point prepared ('I have good communication skills. For example, I persuaded an entire group to ...'). And be prepared to tell the interviewer why you want that job – including what interests you about it, what rewards it offers that you find valuable, and what abilities it requires that you possess. If an interviewer doesn't think you're really, really interested in the job, he or she won't give you an offer – no matter how good you are!">2. Clarify your 'selling points' and the reasons you want the job.</p>

									<p data-toggle="tooltip" title="Every 'how to interview' book has a list of a hundred or more 'common interview questions.' (You might wonder just how long those interviews are if there are that many common questions!) So how do you prepare? Pick any list and think about which questions you're most likely to encounter, given your age and status (about to graduate, looking for a summer internship). Then prepare your answers so you won't have to fumble for them during the actual interview.">3. Prepare for common interview questions.</p>

									<p data-toggle="tooltip" title="Come to the interview with some intelligent questions for the interviewer that demonstrate your knowledge of the company as well as your serious intent. Interviewers always ask if you have any questions, and no matter what, you should have one or two ready. If you say, 'No, not really,' he or she may conclude that you're not all that interested in the job or the company. A good all-purpose question is, 'If you could design the ideal candidate for this position from the ground up, what would he or she be like?'

									If you're having a series of interviews with the same company, you can use some of your prepared questions with each person you meet (for example, 'What do you think is the best thing about working here?' and 'What kind of person would you most like to see fill this position?') Then, try to think of one or two others during each interview itself.">4. Line up your questions for the interviewer.</p>

									<p data-toggle="tooltip" title="It's one thing to come prepared with a mental answer to a question like, 'Why should we hire you?' It's another challenge entirely to say it out loud in a confident and convincing way. The first time you try it, you'll sound garbled and confused, no matter how clear your thoughts are in your own mind! Do it another 10 times, and you'll sound a lot smoother and more articulate.

									But you shouldn't do your practicing when you're 'on stage' with a recruiter; rehearse before you go to the interview. The best way to rehearse? Get two friends and practice interviewing each other in a 'round robin': one person acts as the observer and the 'interviewee' gets feedback from both the observer and the 'interviewer.' Go for four or five rounds, switching roles as you go. Another idea (but definitely second-best) is to tape record your answer and then play it back to see where you need to improve. Whatever you do, make sure your practice consists of speaking aloud. Rehearsing your answer in your mind won't cut it.">5. Practice, practice, practice.</p>

									<p data-toggle="tooltip" title="Some studies indicate that interviewers make up their minds about candidates in the first five minutes of the interview – and then spend the rest of the interview looking for things to confirm that decision! So what can you do in those five minutes to get through the gate? Come in with energy and enthusiasm, and express your appreciation for the interviewer's time. (Remember: She may be seeing a lot of other candidates that day and may be tired from the flight in. So bring in that energy!)

									Also, start off with a positive comment about the company – something like, 'I've really been looking forward to this meeting [not 'interview']. I think [the company] is doing great work in [a particular field or project], and I'm really excited by the prospect of being able to contribute.'">6. Score a success in the first five minutes.</p>

									<p data-toggle="tooltip" title="Perhaps out of the effort to be polite, some usually assertive candidates become overly passive during job interviews. But politeness doesn't equal passivity. An interview is like any other conversation – it’s a dance in which you and a partner move together, both responding to the other. Don't make the mistake of just sitting there waiting for the interviewer to ask you about that Nobel Prize you won. It's your responsibility to make sure he walks away knowing your key selling points.">7. Be assertive and take responsibility for the interview.</p>

									<p data-toggle="tooltip" title="Interview questions about your race, age, gender, religion, marital status, and sexual orientation are inappropriate and in many areas illegal. Nevertheless, you may get one or more of them. If you do, you have a couple of options. You can simply answer with a question ('I'm not sure how that's relevant to my application'), or you can try to answer 'the question behind the question': 'I don't know whether I'll decide to have children in the near future, but if you're wondering if I'll be leaving my job for an extended period of time, I can say that I'm very committed to my career and frankly can't imagine giving it up.">8. Be ready to handle illegal and inappropriate questions.</p>

									<p data-toggle="tooltip" title="If a tree falls in the forest and no one is there to hear it, did it make a sound? More important, if you communicate your selling points during a job interview and the interviewer doesn't get it, did you score? On this question, the answer is clear: No! So don't bury your selling points in long-winded stories. Instead, tell the interviewer what your selling point is first, then give the example.">9. Make your selling points clear.</p>

									<p data-toggle="tooltip" title="Have a copy of your resume with you when you go to every interview. If the interviewer has misplaced his or her copy, you'll save a lot of time (and embarrassment on the interviewer's part) if you can just pull your extra copy out and hand it over.">10.Bring a copy of your resume to every interview.</p>

									<p data-toggle="tooltip" title="Many interviewers begin interviews with this question. So how should you respond? You can go into a story about where you were born, what your parents do, how many brothers and sisters and dogs and cats you have, and that's okay. But would you rather have the interviewer writing down what kind of dog you have – or why the company should hire you?

									Consider responding to this question with something like: 'Well, obviously I could tell you about lots of things, and if I'm missing what you want, please let me know. But the three things I think are most important for you to know about me are [your selling points]. I can expand on those a little if you'd like.' Interviewers will always say, 'Sure, go ahead.' Then you say, 'Well, regarding the first point, [give your example]. And when I was working for [company], I [example of another selling point].' Etc. This strategy enables you to focus the first 10-15 minutes of the interview on all of your key selling points. The 'Tell me about yourself' question is a golden opportunity. Don't miss it!">11.Make the most of the "Tell me about yourself" question.</p>

									<p data-toggle="tooltip" title="Dress appropriately, make eye contact, give a firm handshake, have good posture, speak clearly, and don't wear perfume or cologne! Sometimes interview locations are small rooms that may lack good air circulation. You want the interviewer paying attention to your job qualifications -- not passing out because you've come in wearing Chanel No. 5 and the candidate before you was doused with Brut, and the two have mixed to form a poisonous gas that results in you not getting an offer!">12.Speak the right body language.</p>

									<p data-toggle="tooltip" title="Write a thank-you note after every interview. Type each note on paper or send them by email, depending on the interviewers' preferences. Customize your notes by referring specifically to what you and the interviewer discussed; for example, 'I was particularly excited about [or interested by, or glad to hear] what you said about ...' Handwritten notes might be better if you're thanking a personal contact for helping you in your job search, or if the company you're interviewing with is based in Europe. Whatever method you choose, notes should be sent within 48 hours of the interview.

									To write a good thank-you note, you'll need to take time after each interview to jot down a few things about what the interviewer said. Also, write down what you could have done better in the interview, and make adjustments before you head off for your next interview.">13.Send thank-you notes.</p>

									<p data-toggle="tooltip" title="If you've had a bad interview for a job that you truly think would be a great fit for you (not just something you want badly), don't give up! Write a note, send an email, or call the interviewer to let him or her know that you think you did a poor job of communicating why you think this job would be a good match. Reiterate what you have to offer the company, and say that you'd like an opportunity to contribute. Whether this strategy will get you a job offer depends on the company and on you. But one thing's for sure: If you don't try, your chances are exactly zero. We've seen this approach work on numerous occasions, and we encourage you to give it that last shot.

									If you follow the above 20 strategies, you'll be as prepared as any candidate an interviewer has ever seen. Check out our Open Jobs to start your new career today. Good luck!">14.Don't give up!</p>
									
									<p><a href="https://www.youtube.com/watch?v=qSylCmes5dw" target="_blank">Watch this...</a></p>
										</div>
								</div>
								<!--//sreen-gallery-cursual---->
								<!-- requried-jsfiles-for owl -->
								<link href="css/owl.carousel.css" rel="stylesheet">
								<script src="js/owl.carousel.js"></script>
									<script>
										$(document).ready(function() {
											$("#owl-demo").owlCarousel({
												items : 3,
												lazyLoad : true,
												autoPlay : true,
												pagination : true,
												nav:true,
											});
										});
									</script>
								<!-- //requried-jsfiles-for owl -->
						</div>
						<div class="clearfix"></div>
						<!---728x90--->

			
		<div class="clearfix"> </div>
		</div>
		<!--area-->					
		<div class="fo-top-di">
			<div class="foot-top">
				
					<div class="col-md-6 s-c">
						<li>
							<div class="fooll">
								<h1>follow us on</h1>
							</div>
						</li>
						<li>
							<div class="social-ic">
								<ul>
									<li><a href="#"><i class="facebok"> </i></a></li>
									<li><a href="#"><i class="twiter"> </i></a></li>
									<li><a href="#"><i class="goog"> </i></a></li>
									<li><a href="#"><i class="be"> </i></a></li>
										<div class="clearfix"></div>	
								</ul>
							</div>
						</li>
							<div class="clearfix"> </div>
					</div>
					<div class="col-md-6 s-c">
						<div class="stay">
									
										<div class="clearfix"> </div>
						</div>
					</div>
					<div class="clearfix"> </div>
				
			</div>
				<div class="clearfix"> </div>
						<p style="margin-left: 40%">© 2019 Cam-RA. All Rights Reserved </p>
			</div>
		</div>
			</div>
			<!--content-->
		</div>
</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<header class="logo1">
						 <span style="color: white;font-size: 30px;margin-left: 40px">Cam-RA</span><br><span style="color: white;font-size: 16px">Campus Recruiter Assistant</span> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
                           		<?php include 'user_nav.php'; ?>
							</div>
						</div>
						<div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>


</body>

</html>