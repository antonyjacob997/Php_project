<!DOCTYPE HTML>
<html>
<head>
<title>Cam-RA</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 

<!-- jQuery -->
<link href='http://fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<script src="js/simpleCart.min.js"> </script>
<script src="js/amcharts.js"></script>	
<script src="js/serial.js"></script>	
<script src="js/light.js"></script>	
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   <!--pie-chart--->
<script src="js/pie-chart.js" type="text/javascript"></script>
 
    <style type="text/css">
    	a{
    		text-decoration: none;
    	}

    </style>
    <?php  
    	include 'connection.php';
    	include 'sweetalerttest.php';
    ?>
</head> 
<body>
<script src='../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>

<script src="../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src='https://www.googletagmanager.com/gtag/js?id=UA-149859901-1'></script>



<script async src='../../../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">
<body><link rel="stylesheet" href="../../../../../images/demobar_w3_16oct2019.css">
	<!-- Demo bar start -->
	<div id="w3lDemoBar" class="w3l-demo-bar">
		
			
		</a>
		
			<div class="w3l-template-options">
					<a href="#"
							class="w3l-download" ga-on="click" ga-event-category="Gretong Admin Panel Template" ga-event-action="download-options" ga-event-label="Gretong Admin Panel - Download options">
							<span class="w3l-icon -downdload">
									<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path d="M19.35 10.044 6.6 5.66"/></svg>
							</span>
							
					</a>
			</div>
	</div>
<?php   
include 'connection.php';
session_start();
if((!isset($_SESSION["loggedin"]))and(!isset($_SESSION["org_id"]))){
    header("location: ../Home/index.php");
    exit;
}
else{
    $id=$_SESSION["loggedin"];
    $org_id=$_SESSION["org_id"];
    $qry="SELECT stud_id,Full_Name from stud where login_id='$id'";
    $qry2="SELECT Org from organization where org_id='$org_id'";
    //  echo"<script>alert('".$org_id."')</script>";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $Name=$row['Full_Name'];
        $stud_id=$row['stud_id'];
    }
    $result2=mysqli_query($conn,$qry2);
    if(mysqli_num_rows($result2)>0)
        {
        $row2 = mysqli_fetch_array($result2);
        $org=$row2['Org'];
    }
    
    $qry3="SELECT * from feedback where stud_id='$stud_id' and org='$org'";
    $result3=mysqli_query($conn,$qry3);
    if(mysqli_num_rows($result3)>0)
        {
            // echo"<script>alert('".$org_id."')</script>";
        echo"<script>window.location('../Home/index.php')</script>";
        header("location: ../Home/index.php");
    }
    $_SESSION["loggedin"] = "$id";
}
?>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<div class="header-section">
			<!-- top_bg -->
						<div class="top_bg">
							
								<div class="header_top">
									<div class="top_right">
										
									</div>
									<div class="top_left">
										<h2><?php echo $Name ?></h2>

									</div>
										<div class="clearfix"> </div>
								</div>
							
						</div>
					<div class="clearfix"></div>
				<!-- /top_bg -->
				</div>
				<div class="header_bg">
						
							<div class="header">
								<div class="head-t">
									<div class="logo">
										<h1 style="font-family:Old English Text MT;">Cam-RA</h1>
										<p style="font-family:Old English Text MT;">Campus Recruiter Assistant</p>
									</div>
										<!-- start header_right -->

				<div class="header_right">
										<div class="rgt-bottom">
											<div class="log">
												<div class="login" hidden="">
													<div id="loginContainer"><a id="loginButton" class=""><span>Login</span></a>
														<div id="loginBox" style="display: none;">                
															<form id="loginForm">
																	<fieldset id="body">
																		<fieldset>
																			  <label for="email">Email Address</label>
																			  <input type="text" name="email" id="email">
																		</fieldset>
																		<fieldset>
																				<label for="password">Password</label>
																				<input type="password" name="password" id="password">
																		 </fieldset>
																		<input type="submit" id="login" value="Sign in">
																		<label for="checkbox"><input type="checkbox" id="checkbox"> <i>Remember me</i></label>
																	</fieldset>
																<span><a href="#">Forgot your password?</a></span>
															</form>
														</div>
													</div>
												</div>
											</div>
											<div class="reg">
												<a href="register.html" hidden="">REGISTER</a>
											</div>
										<div class="cart box_1">
											<a href="checkout.html">
												<h3 hidden> <span class="simpleCart_total" hidden="">$0.00</span> (<span id="simpleCart_quantity" hidden="" class="simpleCart_quantity">0</span> items)<img src="images/bag.png" alt="" hidden=""></h3>
											</a>	
											<p><a href="javascript:;" class="simpleCart_empty"></a></p>
											<div class="clearfix"> </div>
										</div>
										<div class="create_btn">
											<a href="logout.php">LOGOUT</a>
										</div>
										<div class="clearfix"> </div>
									</div>
									
									<div class="clearfix"> </div>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					
				</div>

					<!-- //header-ends -->
				<!---728x90--->

				<!--content-->
			<div class="content">
<div class="women_main">
	<!-- start content -->
	<div class="catalog">				
			<div id="tabs" class="tabs">
					
					 
						<div class="graph">
							<nav>
								
							</nav>
								<div class="content tab">
									<section id="section-1" class="content-current">
										<div class="panel panel-widget forms-panel">
						<div class="forms">
							<div class="form-two widget-shadow">					

								<div class="form-title">
									<h4>FeedBack </h4>
								</div>
								<div class="form-body">
									<form class="form-horizontal" method="POST">
										
										<div class="form-group"> <label for="inputPassword3" class="col-sm-3 control-label">Organization</label> 
											<div class="col-sm-9"> <input type="Text" value="<?php echo $org; ?>" class="form-control" name="org"></div> </div>
										<div class="form-group"> <label for="inputPassword3" class="col-sm-3 control-label">feedback</label> 
											<div class="col-sm-9"> <textarea class="form-control" name="feedback" placeholder="Feedback"></textarea> </div> </div> 
										<div class="col-sm-offset-3"> <button type="submit" class="btn btn-primary" name="submit1">Submit</button> </div> </form> 
									</div>
							</div>
	<?php   
		if(isset($_POST['submit1'])){
			$org=$_POST['org'];
			$feedback=$_POST['feedback'];
		    $date1=date("Y-m-d");
			$sql="INSERT into feedback (stud_id,org,feedback,date1,forward,status)values ('$stud_id','$org','$feedback','$date1',0,1)";
			if ($conn->query($sql) === TRUE) 
		            {
		            	$sql2="UPDATE drive_reg set feed=0 where stud_id='$stud_id' and org_id='$org_id'";
		            	if ($conn->query($sql2) === TRUE) 
		            	{
		                	echo '<script>
							    setTimeout(function() {
							        swal({
							            title: "Feedback submitted !",
							            text: "Successfully...!",
							            type: "success"
							        }, function() {
							            window.location = "personal.php";
							        });
							    }, 1000);
							</script>';
						}
		            } 
		}
	?>
						</div>
					</div>

									</section>
																	
																	
																	
								</div><!-- /content -->
						</div>
												<!-- /tabs -->
											</div>	
								<script src="js/cbpFWTabs.js"></script>
									<script>
										new CBPFWTabs( document.getElementById( 'tabs' ) );
									</script>
											
	</div>
<!---728x90--->

	<!-- end content -->
	<div class="fo-top-di">
			<div class="foot-top">
				
					<div class="col-md-6 s-c">
						<li>
							<div class="fooll">
								<h1>follow us on</h1>
							</div>
						</li>
						<li>
							<div class="social-ic">
								<ul>
									<li><a href="#"><i class="facebok"> </i></a></li>
									<li><a href="#"><i class="twiter"> </i></a></li>
									<li><a href="#"><i class="goog"> </i></a></li>
									<li><a href="#"><i class="be"> </i></a></li>
										<div class="clearfix"></div>	
								</ul>
							</div>
						</li>
							<div class="clearfix"> </div>
					</div>
					<div class="col-md-6 s-c">
						<div class="stay">
									
										<div class="clearfix"> </div>
						</div>
					</div>
					<div class="clearfix"> </div>
				
			</div>
				<div class="clearfix"> </div>
						<p style="margin-left: 40%">© 2019 Cam-RA. All Rights Reserved </p>
			</div>
</div>

</div>
			<!--content-->
		</div>
</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<header class="logo1">
						 <span style="color: white;font-size: 30px;margin-left: 40px">Cam-RA</span><br><span style="color: white;font-size: 16px">Campus Recruiter Assistant</span> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<?php include 'user_nav.php'; ?>
								</div>
							  </div>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>

</body>

</html>