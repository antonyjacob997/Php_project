<?php
include 'config.php';
include 'connection.php';
include 'sweetalerttest.php';

session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: ../index.php");
    exit;
}
else{
    $id=$_SESSION["loggedin"];
    $qry="SELECT stud_id,University_Reg_No,Full_Name,email,Mobile from stud_info where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $Name=$row['Full_Name'];
        $University_Reg_No=$row['University_Reg_No'];
        $stud_id=$row['stud_id'];
        $email=$row['email'];
        $Mobile=$row['Mobile'];
    }
    $_SESSION["loggedin"] = "$id";
    $sql="SELECT * from caution where stud_id='$stud_id'";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0){
        echo"<script>
        $(document).ready(function(){
            $('#payment').hide();
            $('#message').show();
        });
        // swal('Payment!', 'Already Done..!', 'success');
        </script>";
    }
    else{
        echo"<script>
        $(document).ready(function(){
            $('#payment').show();
            $('#message').hide();
        });
        // swal('Payment!', 'Already Done..!', 'success');
        </script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 

<!-- jQuery -->
<link href='http://fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<script src="js/simpleCart.min.js"> </script>
<script src="js/amcharts.js"></script>  
<script src="js/serial.js"></script>    
<script src="js/light.js"></script> 


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
    <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>



<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   <!--pie-chart--->
<script src="js/pie-chart.js" type="text/javascript"></script>
 
<style>
        .razorpay-payment-button{
            color: white !important;
            background-color: #e36f17;
            border-color: #e36f17;
            font-size: 14px;
            padding: 10px;
            width: 30%;
            float: right;
        }
    </style>
<script async src='../../../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">
<body><link rel="stylesheet" href="../../../../../images/demobar_w3_16oct2019.css">
    <!-- Demo bar start -->
    <div id="w3lDemoBar" class="w3l-demo-bar">
            <div class="w3l-template-options">
                                        <a href="#"
                            class="w3l-download" ga-on="click" ga-event-category="Gretong Admin Panel Template" ga-event-action="download-options" ga-event-label="Gretong Admin Panel - Download options">
                            <span class="w3l-icon -download">
                                    <svg xmlns="https://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/></svg>
                            </span>
                            <!-- <span class="w3l-text">Download</span> -->
                    </a>
            </div>
    </div>

<div class="page-container">
   <!--/content-inner-->
    <div class="left-content">
       <div class="inner-content">
        <!-- header-starts -->
            <div class="header-section">
            <!-- top_bg -->
                        <div class="top_bg">
                            
                                <div class="header_top">
                                    <div class="top_right">
                                        
                                    </div>
                                    <div class="top_left">
                                        <h2><?php echo $Name ?></h2>

                                    </div>
                                        <div class="clearfix"> </div>
                                </div>
                            
                        </div>
                    <div class="clearfix"></div>
                <!-- /top_bg -->
                </div>
                <div class="header_bg">
                        
                            <div class="header">
                                <div class="head-t">
                                    <div class="logo">
                                        <h1 style="font-family:Old English Text MT;">Cam-RA</h1>
                                        <p style="font-family:Old English Text MT;">Campus Recruiter Assistant</p>
                                    </div>
                                        <!-- start header_right -->

                <div class="header_right">
                                        <div class="rgt-bottom">
                                            <div class="log">
                                                <div class="login" hidden="">
                                                    <div id="loginContainer"><a id="loginButton" class=""><span>Login</span></a>
                                                        <div id="loginBox" style="display: none;">                
                                                            <form id="loginForm">
                                                                    <fieldset id="body">
                                                                        <fieldset>
                                                                              <label for="email">Email Address</label>
                                                                              <input type="text" name="email" id="email">
                                                                        </fieldset>
                                                                        <fieldset>
                                                                                <label for="password">Password</label>
                                                                                <input type="password" name="password" id="password">
                                                                         </fieldset>
                                                                        <input type="submit" id="login" value="Sign in">
                                                                        <label for="checkbox"><input type="checkbox" id="checkbox"> <i>Remember me</i></label>
                                                                    </fieldset>
                                                                <span><a href="#">Forgot your password?</a></span>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="reg">
                                                <a href="register.html" hidden="">REGISTER</a>
                                            </div>
                                        <div class="cart box_1">
                                            <a href="checkout.html">
                                                <h3 hidden> <span class="simpleCart_total" hidden="">$0.00</span> (<span id="simpleCart_quantity" hidden="" class="simpleCart_quantity">0</span> items)<img src="images/bag.png" alt="" hidden=""></h3>
                                            </a>    
                                            <p><a href="javascript:;" class="simpleCart_empty"></a></p>
                                            <div class="clearfix"> </div>
                                        </div>
                                        <div class="create_btn">
                                            <a href="logout.php">LOGOUT</a>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    
                                    <div class="clearfix"> </div>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    
                </div>
<div class="content">
<div class="women_main" style="width: 50%; float: right;margin-top: 4%">
    <!-- start content -->
    <div class="catalog">               
      <section id="section-1" class="content-current">
        <div class="panel panel-widget forms-panel">
          <div class="forms">
            <div class="form-two widget-shadow">                    
              <div class="form-title">
                <h4>Caution Deposit Payment</h4>
              </div>
              <div class="form-body">
                <form class="form-horizontal" method="POST">
                        <div class="alert alert-success" id="message" role="alert"> You Already Payed..!</div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-4 control-label">Full Name</label> 
                        <div class="col-sm-2"> 
                            <input type="text" name="Name" id="name" required value="<?php echo $Name ?>">
                        </div> 
                    </div><br>
                    <input type="text" id="stud_id" name="stud_id" value="<?php echo $stud_id ?>" hidden>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-4 control-label">Email</label> 
                        <div class="col-sm-4"> 
                            <input type="text" id="Email" name="Email" value="<?php echo $email ?>">
                        </div> 
                    </div><br>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-4 control-label">Mobile</label> 
                        <div class="col-sm-4"> 
                            <input type="text" id="Mobile" name="Mobile" value="<?php echo $Mobile ?>">
                        </div> 
                    </div><br>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-4 control-label">Amount</label> 
                        <div class="col-sm-4"> 
                            <input type="text" name="Amount" readonly value="3000">
                        </div> 
                    </div><br>
                    <div class="form-group">
                       <div id="payment"> <button id="rzp-button1" class="razorpay-payment-button">Pay</button></div>
                    </div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>

var options = {
    "key": "<?php echo $razor_api_key; ?>", // Enter the Key ID generated from the Dashboard
    "amount": "300000", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Cam-RA",
    "description": "Caution Deposit",
    "image": "https://example.com/your_logo",
   
    "handler": function (response){
        // alert(response.razorpay_payment_id);
        // alert(response.razorpay_order_id);
        var pay_id=response.razorpay_payment_id;
        var stud_id=document.getElementById('stud_id').value;

        $.ajax({
                type:'POST',
                url:'insert_payment.php',
                data:{ pay_id: pay_id,stud_id: stud_id },
                success:function (html) {
                    setTimeout(function() {
                                    swal({
                                        title: "Payment Done!",
                                        text: "successfully...!",
                                        type: "success"
                                    }, function() {
                                        window.location = "personal.php";
                                    });
                                }, 1000);
                    
                }
            }); 
        // alert(response.razorpay_signature)
        
    },
    "prefill": {
        "name": document.getElementById('name').value,
        "email": document.getElementById('Email').value,
        "contact": document.getElementById('Mobile').value
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#e36f17"
    }
};
var rzp1 = new Razorpay(options);
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>
	</form>

                                    
               </div>
            </div>
    </div>
           </div> 
        </div>
      </section>
    </div><!-- /content -->
</div><!---728x90--->
</div>
<div class="content">
<div class="women_main" style="width: 45%;">
    <!-- start content -->
    <div class="catalog">               
      <section id="section-12" class="content-current" style="height: 650px">
        <div class="panel panel-widget forms-panel">
          <div class="forms">
            <div class="form-two widget-shadow">                    
              <div class="form-title">
                <h4>Cam-RA</h4>
              </div>
              <div class="form-body">
                <h2>
                    Caution Deposit

                </h2>
                <p>
                    The caution money and security deposit are refundable after deduction of dues, 
                    if any, only after the student finally leaves the College on completion of the course.
                </p>
                <h3>
                    Placement Cell
                </h3>   
                <p>
                    
Amal Jyothi College of Engineering
</p><h3>
Contact Us:</h3><p>
<span>  <i class='fas fa-envelope'></i></span> antonyjacob997@gmail.com<br>
 <span> <i class='fas fa-phone'></i></span>8113090878
                </p>   <br><br>     
               </div>
            </div>
            </div>
           </div>
        </div>
      </section>
    </div>

    <!-- end content -->
    <div class="fo-top-di">
            <div class="foot-top">
                
                    <div class="col-md-6 s-c">
                        <li>
                            <div class="fooll">
                                <h1>follow us on</h1>
                            </div>
                        </li>
                        <li>
                            <div class="social-ic">
                                <ul>
                                    <li><a href="#"><i class="facebok"> </i></a></li>
                                    <li><a href="#"><i class="twiter"> </i></a></li>
                                    <li><a href="#"><i class="goog"> </i></a></li>
                                    <li><a href="#"><i class="be"> </i></a></li>
                                        <div class="clearfix"></div>    
                                </ul>
                            </div>
                        </li>
                            <div class="clearfix"> </div>
                    </div>
                    <div class="col-md-6 s-c">
                        <div class="stay">
                                    
                                        <div class="clearfix"> </div>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                
            </div>
                <div class="clearfix"> </div>
                        <p style="margin-left: 40%">© 2019 Cam-RA. All Rights Reserved </p>
            </div>

</div>
</div>
            <!--content-->
</div>
</div>
                <!--//content-inner-->
            <!--/sidebar-menu-->
                <div class="sidebar-menu">
                    <header class="logo1">
                         <span style="color: white;font-size: 30px;margin-left: 40px">Cam-RA</span><br><span style="color: white;font-size: 16px">Campus Recruiter Assistant</span> 
                    </header>
                        <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
                                    <?php include 'user_nav.php'; ?>
                                </div>
                              </div>
                              <div class="clearfix"></div>      
                            </div>
                            <script>
                            var toggle = true;
                                        
                            $(".sidebar-icon").click(function() {                
                              if (toggle)
                              {
                                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                                $("#menu span").css({"position":"absolute"});
                              }
                              else
                              {
                                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                                setTimeout(function() {
                                  $("#menu span").css({"position":"relative"});
                                }, 400);
                              }
                                            
                                            toggle = !toggle;
                                        });
                            </script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>
    
           <script src="js/menu_jquery.js"></script>
</body>

</html>