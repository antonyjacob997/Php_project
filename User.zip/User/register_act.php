<?php
$notif_id=$_GET["notif_id"];
$stud_id=$_GET["stud_id"];
$org_id=$_GET["org_id"];
include 'connection.php';
$status=1;
$qry="SELECT * from drive_reg where stud_id=$stud_id and notif_id=$notif_id";
$result=mysqli_query($conn,$qry);
if(mysqli_num_rows($result) < 1){

	$sql="INSERT into drive_reg(notif_id,stud_id,status,org_id,feed) values($notif_id,$stud_id,$status,$org_id,1)";
	if ($conn->query($sql) === TRUE) {
		?>
                <script type="text/javascript">
                location.href="notification.php?f=1";
                // alert("Registered successfully...");
                    </script>
                <?php

	}else {
    		echo "Error: " . $qry . "<br>" . $conn->error;
		}
}
else{
	?>
                <script type="text/javascript">
                location.href="notification.php?f=2";
                // alert("Already registered...");
                    </script>
                <?php
}
echo $stud_id." ".$job_id;
?>
