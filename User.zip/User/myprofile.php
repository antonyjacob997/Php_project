<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <!--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" />
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
  <link rel="stylesheet" href="main1.css">
  <?php include 'sweetalerttest.php'; ?>
  <script type="text/javascript">
    
      function triggerClick(e) {
        document.querySelector('#profileImage').click();
      }
      function displayImage(e) {
        var fileExtension = ['jpg','png','jpeg'];
              if ($.inArray($(e).val().split('.').pop().toLowerCase(), fileExtension) == -1)
              {
                   swal('Sorry !', 'Only JPG,JPEG,PNG formats are allowed..', 'error');
              }
              else
              {

                  if (e.files[0]) {
                      var reader = new FileReader();
                      reader.onload = function(e){
                          document.querySelector('#profileDisplay').setAttribute('src', e.target.result);
                      }
                      reader.readAsDataURL(e.files[0]);
                  }
                  setTimeout(function() {
                  swal({
                      title: "Are you sure?",
                          text: "You want to upload this image!",
                          type: "warning",
                        showCancelButton: true,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Yes, Upload it!",
                        closeOnConfirm: false
                  }, function(res) {
                      if(res){
                        // window.location = "processForm.php?stud_id=<?php echo $stud; ?>&locat=e.target.result";
                        document.getElementById("myForm").submit();
                      }else{
                        window.location="personal.php";
                      }
                  });

              }, 1000);
            }
      }
  </script>
</head>
<body>
  <?php 
    include 'connection.php';
    $sql="SELECT * from users where stud_id=$stud and status=1";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0)
        {
        $row = mysqli_fetch_array($res);
            $profile="profile/".$row['profile_image'];
        }
        else{
          $profile="images/profile.png";
        }
   ?>
  <form action="processForm.php?stud_id=<?php echo $stud; ?>" method="post" id="myForm" enctype="multipart/form-data">
          <?php if (!empty($msg)): ?>
            <div class="alert <?php echo $msg_class ?>" role="alert">
              <?php echo $msg; ?>
            </div>
          <?php endif; ?>
          <div class="form-group text-center" style="width: 200px;" >
            <span class="img-div">
              <div class="text-center img-placeholder" style="width: 190px;"  onClick="triggerClick()">
                <h2><span style="margin-top: 70px" class="glyphicon glyphicon-camera camera"></span></h2>
              </div>
              <img src="<?php echo $profile; ?>" onClick="triggerClick()" id="profileDisplay">
            </span>
            <input type="file" name="profileImage" onChange="displayImage(this)" id="profileImage" class="form-control" style="display: none;">
          <input type="text" name="stud_id" value="<?php $stud; ?>" hidden>
          </div>
        </form>
</body>
</html>