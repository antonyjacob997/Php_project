<!DOCTYPE html>
<html>
<head>


    <link rel="stylesheet" type="text/css" href="sweetalert.css">
    <script type="text/javascript" src="sweetalert.js"></script>

	
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	
</head>
<body>
<!--
<div class="container">
		  <button id="btnclk" style="margin:40px;" class="btn btn-primary">click me</button>
      <script type="text/javascript">
        $(document).ready(function(){
          $("#btnclk").on("click",function(){
            swal("welcome");
          });
        });
      </script>
	</div>

  <div class="container">
      <button id="btnclk2" style="margin:40px;" class="btn btn-primary">click me</button>
      <script type="text/javascript">
        $(document).ready(function(){
          $("#btnclk2").on("click",function(){
            swal('Good job!', 'You clicked the button!', 'success')
            swal('Oops!', 'Something went wrong!', 'error')
          });
        });
      </script>
  </div>

Swal.fire({  icon: 'error',  title: 'Oops...',  text: 'Something went wrong!',  footer: '<a href>Why do I have this issue?</a>'   })


  <div class="container">
      <button id="btnclk3" style="margin:40px;" class="btn btn-primary">click me</button>
      <script type="text/javascript">
        $(document).ready(function(){
          $("#btnclk3").on("click",function(){
            swal({
                title: "Are you sure?",
                text: "Your will not be able to recover this imaginary file!",
                type: "warning",
              showCancelButton: true,
              confirmButtonClass: "btn-danger",
              confirmButtonText: "Yes, delete it!",
              closeOnConfirm: false
            },
            function(){
              swal('Deleted!', 'Your imaginary file has been deleted.', 'success');
            });
          });
        });
      </script>

echo '<script>
    setTimeout(function() {
        swal({
            title: "Package Updated Successfully!",
            text: "Thank you for the purchase!",
            type: "success"
        }, function() {
            window.location = "dashboard.php";
        });
    }, 1000);
</script>';

<script type="text/javascript">swal({
title: "Are you sure?",
text: "Your current package will be deactivated!",
type: "warning",
showCancelButton: true,
confirmButtonClass: "btn-danger",
confirmButtonText: "Yes, confirm purchase!",
closeOnConfirm: false
},
function(){
setTimeout(function() {
       swal({
           title: "Package Updated Successfully!",
           text: "Thank you for the purchase!",
           type: "success"
       }, function() {
           window.location = "dashboard.php";
       });
   }, 1000);

});</script>

</script>';




  </div>  -->
</body>
</html>