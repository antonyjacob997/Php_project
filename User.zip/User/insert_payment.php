<?php
include 'connection.php';

if(!empty($_POST['pay_id'])and(!empty($_POST['stud_id']))){
	$c=$_POST['pay_id'];
	$stud_id=$_POST['stud_id'];
	$pay_date=date("Y/m/d");
	$qry="INSERT into caution (stud_id,payment_date,pay_id) value('$stud_id','$pay_date','$c')";
	 echo"<script>alert('".$c."')</script>";
	$result=mysqli_query($conn,$qry);
	if(mysqli_num_rows($result) > 0){
		echo"dsgdfgdg"; 
    }                                
                                    
}

?>
