<?php
	include 'connection.php';
	$stud_id=$_GET['stud_id'];
	$upload_id=$_GET['upload_id'];
	$sql="UPDATE uploads set status=0 where stud_id='$stud_id'and upload_id='$upload_id'";
	$res=mysqli_query($conn,$sql);
    header("location:support_doc.php");
?>
<script>
	window.location('support_doc.php');
</script>