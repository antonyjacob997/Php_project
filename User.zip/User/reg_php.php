<?php
    include 'connection.php';
    $type="student";
    $email=$_POST['Email'];
    $pass=$_POST['password'];
    $name=$_POST['name'];
    $status=1;

    $sql = "INSERT INTO login (user_type, email, password, status)
VALUES ('$type', '$email', '$pass', '$status')";

if ($conn->query($sql) === TRUE) {
    ?><script><window location="home.php"</script><?php
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>