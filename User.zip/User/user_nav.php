								<ul id="menu" >
									
									<li id="menu-academico" ><a href="personal.php"><span>Details</span></a></li>
									<li id="menu-academico" ><a href="support_doc.php"> <span>Supporting Document</span></a></li>
									<li id="menu-academico" ><a href="notification.php"> <span>Notifications</span></a></li>
									<li id="menu-academico" ><a href="view_result.php"> <span>Results</span></a></li>
									<li id="menu-academico" ><a href="rules.php"> <span>Rules</span></a></li>
									<li><a href="index.php"> <span>Tips</span></a></li>
									<li id="menu-academico" ><a href="user_exp.php"> <span>Experiences</span></a></li>
									<li id="menu-academico" ><!--live mode-- https://rzp.io/l/hyDxBk2 --><a href="payment.php"> <span>Caution Deposit</span></a></li>
									 <li id="menu-academico" ><a href="changepsw.php"> <span>Change Password</span></a></li>
								 </ul>