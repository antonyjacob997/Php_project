
<!DOCTYPE HTML>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Cam-RA</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 

<!-- jQuery -->
<link href='http://fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<script src="js/simpleCart.min.js"> </script>
<script src="js/amcharts.js"></script>	
<script src="js/serial.js"></script>	
<script src="js/light.js"></script>	
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   <!--pie-chart--->
		
</head> 

<?php   
include 'connection.php';
include 'sweetalerttest.php';
$name="";
session_start();

error_reporting(0);
if(!isset($_SESSION["loggedin"])){
    header("location: ../index.php");
    exit;
}
else{
    $id=$_SESSION["loggedin"];
    $qry="SELECT stud_id,University_Reg_No, Full_Name,dept_id,Mobile,Alt_Mobile,DoB,Gender,Father_Name,Mother_Name, House_Name,Street,City,dist_id,state_id,country_id,course from stud where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $stud=$row['stud_id'];
            $name=$row['Full_Name'];
            $University_Reg_No=$row['University_Reg_No'];
            $dept_id=$row['dept_id'];
            $Mobile=$row['Mobile'];
            $Alt_Mobile=$row['Alt_Mobile'];
            $DoB=$row['DoB'];
            $Gender=$row['Gender'];
            $Father_Name=$row['Father_Name'];
            $Mother_Name=$row['Mother_Name'];
            $House_Name=$row['House_Name'];
            $Street=$row['Street'];
            $City=$row['City'];
            $dist_id=$row['dist_id'];
            $state_id=$row['state_id'];
            $country_id=$row['country_id'];
            $course=$row['course'];
    
    $_SESSION["loggedin"] = "$id";
    $qry2="SELECT department_name FROM department WHERE dept_id='$dept_id'";
    $result=mysqli_query($conn,$qry2);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $Department=$row['department_name'];
          }
    $qry3="SELECT dist_name FROM district WHERE dist_id='$dist_id'";
    $result=mysqli_query($conn,$qry3);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $District=$row['dist_name'];
          }
          
    $qry4="SELECT state_name FROM state WHERE state_id='$state_id'";
    $result=mysqli_query($conn,$qry4);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $State=$row['state_name'];
          }
          
    $qry5="SELECT country_name FROM country WHERE country_id='$country_id'";
    $result=mysqli_query($conn,$qry5);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $Country=$row['country_name'];
          }
          
    $qry7="SELECT count(upload_id) as ct FROM uploads WHERE stud_id='$stud' and status=1";
    $result=mysqli_query($conn,$qry7);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $Count=$row['ct'];
          }
    $qry8="SELECT count(payment_id) as cst FROM caution WHERE stud_id='$stud'";
    $result=mysqli_query($conn,$qry8);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $Co=$row['cst'];
          }
          
    $qry6="SELECT * FROM academic where login_id='$id'";
    $result=mysqli_query($conn,$qry6);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
            $statt1=$row['stat1'];
            $statt2=$row['stat2'];
            $statt3=$row['stat3'];
            if($course==1){
                $statt4=1;
                
            }
            else{
                $statt4=$row['stat4'];
            }
          }
 }
}
?>



<body>
<script src='../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>


<script async src='../../../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">

<body><link rel="stylesheet" href="../../../../../images/demobar_w3_16oct2019.css">
	<!-- Demo bar start -->
	<div id="w3lDemoBar" class="w3l-demo-bar">
			</span>
		</a>

		</a>
			<div class="w3l-template-options">
										
							<!-- <span class="w3l-icon -download"> -->
									<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/></svg>
							</span>
							<!-- <span class="w3l-text">Download</span> -->
					</a>
			</div>
	</div>

   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<div class="header-section">
			<!-- top_bg -->
						<div class="top_bg">
							
								<div class="header_top">
									<div class="top_right">
										
									</div>
									<div class="top_left">
										<h2> <?php echo $name ?></h2>
										<p></p>
									</div>
										<div class="clearfix"> </div>
								</div>
							
						</div>
					<div class="clearfix"></div>
				<!-- /top_bg -->
				</div>
				<div class="header_bg">
						
							<div class="header">
								<div class="head-t">
									<!--<div class="logo">-->
									<!--	<h1 style="font-family:Old English Text MT;">Cam-RA</h1>-->
									<!--	<p style="font-family:Old English Text MT;">Campus Recruiter Assistant</p>-->
									<!--</div>-->
										<!-- start header_right -->
									
								<div class="header_right">
										<div class="rgt-bottom">
											
											<div class="reg">
												<a href="" hidden="">REGISTER</a>
											</div>
											
                    <div class="form-group">
										<div class="cart box_1">
											<a href="">
												<h3 hidden> <span class="simpleCart_total" hidden="">$0.00</span> (<span id="simpleCart_quantity" hidden="" class="simpleCart_quantity">0</span> items)<img src="images/bag.png" alt="" hidden=""></h3>
											</a>	
											<p><a href="javascript:;" class="simpleCart_empty"></a></p>
											<div class="clearfix"> </div>
										</div>
										<div class="create_btn">
											<a href="logout.php">LOGOUT</a>
										</div>
										<div class="clearfix"> </div>
									</div>
								<?php 
								if( ($statt1==0) || ($statt2==0) || ($statt3==0) || ($statt4==0) ){
								    
									echo'<div class="alert alert-danger" id="message" role="alert">Complete your Profile Details..!</div> '; 
								}
								// echo'<script>alert("'.$Count.'")</script>';
								if($Count<2){
								    
								    echo'<div class="alert alert-danger" id="message" role="alert"> Upload the Supporting Documents..!</div> ';
								}
								if($Co<1){
								    
								    echo'<div class="alert alert-danger" id="message" role="alert"> Caution Deposit is not Payed..!</div> ';
								}
								?>
									<div class="clearfix"> </div>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					
				</div>

					<!-- //header-ends -->
					<!-- Profile Photo -->
									<div>
										<?php include 'myprofile.php'; ?>
									</div>
				<!---728x90--->

				<!--content-->
			<div class="content">
<div class="women_main">
	<!-- start content -->
	<div class="catalog">				
			<div id="tabs" class="tabs">
					
						<div class="graph">
							<?php 
							// echo"<script>alert('".$course."')</script>";
								if($course==1){     ?>
									<nav>
								<ul>
									<li class="tab-current"><a href="#section-1" class="icon-shop"><span>Personal</span></a></li>
									<li><a href="#section-2" class="icon-cup"><span>Tenth</span></a></li>
									<li><a href="#section-3" class="icon-food"><span>Plus Two</span></a></li>
									<li ></li>
									<li ></li>
									<li><a href="#section-7" class="icon-lab"><span>B-Tech</span></a></li>
									
								</ul>
							</nav>
									<?php }elseif($course==2){     ?>
									<nav>
								<ul>
									<li class="tab-current"><a href="#section-1" class="icon-shop"><span>Personal</span></a></li>
									<li><a href="#section-2" class="icon-cup"><span>Tenth</span></a></li>
									<li><a href="#section-3" class="icon-food"><span>Plus Two</span></a></li>
									<li><a href="#section-4" class="icon-lab"><span>Degree</span></a></li>
									<li><a href="#section-5" class="icon-truck"><span>Post Graduation</span></a></li>
									
								</ul>
							</nav>
							<?php	}else{       ?>
									<nav>
								<ul>
									<li class="tab-current"><a href="#section-1" class="icon-shop"><span>Personal</span></a></li>
									<li><a href="#section-2" class="icon-cup"><span>Tenth</span></a></li>
									<li><a href="#section-3" class="icon-food"><span>Plus Two</span></a></li>
									<li><a href="#section-4" class="icon-lab"><span>B-Tech</span></a></li>
									<li><a href="#section-5" class="icon-truck"><span>M-Tech</span></a></li>
									
								</ul>
							</nav>
							<?php  }
							 ?>

<!-- personal details -->								
							
								<div class="content tab">
									<section id="section-1" class="content-current">
										<form method="post">
										<span style="margin-left: 30%; color: red">To edit values you need to enter values and press update.</span><br><span style="margin-left: 30%; color: red">You can edit only Address and Contact fields.</span>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Register No</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1"name="uni_no" value="<?php echo $University_Reg_No; ?>" disabled>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Full Name</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1"name="fname" id="fullname" value="<?php echo $name; ?>" disabled>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Father's Name</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1"name="father" value="<?php echo $Father_Name; ?>" disabled>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Mother's Name</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1"name="mother" value="<?php echo $Mother_Name; ?>"  disabled><br>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Date of Birth</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1"name="dob" value="<?php echo $DoB; ?>" disabled>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Gender</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1"name="gender" value="<?php echo $Gender; ?>"  disabled>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<hr>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Address</label>
												<div class="col-sm-8 ctl">
													<input type="text" autocomplete="of" class="form-control1" id="addr" onchange="Validatename2(this)" name="address" value="<?php echo $House_Name; ?>"  >
													<label class="errortext" style="display:none; color:red" id="name_l"></label>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<script>
											function Validatename2(input)
                                            {
                                                  
                                                  var val2= document.getElementById('addr').value;
                                                  if (!val2.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_l").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('addr').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('addr').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        </script> 
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Place/village</label>
												<div class="col-sm-8 ctl">
													<input type="text" autocomplete="of" class="form-control1" name="place" id="place" onchange="Validatename3(this)" value="<?php echo $Street; ?>"  >
													<label class="errortext" style="display:none; color:red" id="name_2"></label>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
											<script>
											function Validatename3(input)
                                            {
                                                  
                                                  var val2= document.getElementById('place').value;
                                                  if (!val2.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_2").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('place').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('place').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        </script> 
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">City</label>
												<div class="col-sm-8 ctl">
													<input type="text" autocomplete="of" class="form-control1" id="city" onchange="Validatename4(this)" name="city" value="<?php echo $City; ?>"  >
													<label class="errortext" style="display:none; color:red" id="name_3"></label>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
											<script>
											function Validatename4(input)
                                            {
                                                  
                                                  var val2= document.getElementById('city').value;
                                                  if (!val2.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_3").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('city').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('city').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        </script>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">District</label>
												<div class="col-sm-8 ctl">
													<select name="district" id="field-2" required="true" class="form-control">
														<option value="<?php echo $dist_id ?>"><?php echo $District ?></option>

                                            <?php 
                                                $sql="SELECT * FROM district";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['dist_id'] ?>"><?php echo $row['dist_name']; ?></option>
                                            <?php }
                                     }  ?>  
													</select>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">State</label>
												<div class="col-sm-8 ctl">
													<select name="state" id="field-2" required="true" class="form-control">
														<option value="<?php echo $state_id ?>"><?php echo $State ?></option>

                                            <?php 
                                                $sql="SELECT * FROM state";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['state_id'] ?>"><?php echo $row['state_name']; ?></option>
                                            <?php }
                                     }  ?>  
													</select>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Country</label>
												<div class="col-sm-8 ctl">
													<input type="text" autocomplete="of" disabled class="form-control1"name="Country" value="<?php echo $Country; ?>" >
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Department</label>
												<div class="col-sm-8 ctl">
													<input type="text" autocomplete="of" disabled="disabled" class="form-control1"name="department" value="<?php echo $Department; ?>"  >
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Mobile Number</label>
												<div class="col-sm-8 ctl">
													<input type="text" autocomplete="of" class="form-control1" name="mobile" id="mobile" onchange="Validatephone(this)" value="<?php echo $Mobile; ?>"  >
													<label class="errortext" style="display:none; color:red" id="mobile_1">
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<script>
                                              function Validatephone(input)
                                              {
                                                  var val = document.getElementById('mobile').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                  $("#mobile_1").html('Must. 10 and Only Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  input.style.borderColor = "#e74c3c";
                                                      document.getElementById('mobile').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                          </script>
										<div class="fo-top">
											<div class="form-group">
												
												<label for="focusedinput" class="col-sm-2 control-label">Alternative Mobile</label>
												<div class="col-sm-8 ctl">
													<input type="text" autocomplete="of" class="form-control1"name="mobile2" onchange="Validatemob(this)" id="mobile2" value="<?php echo $Alt_Mobile; ?>"  >
													<label class="errortext" style="display:none; color:red" id="mobile_21">
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
											<script >
												function Validatemob(input)
                                              {
                                                  var val = document.getElementById('mobile2').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                  $("#mobile_21").html('Must. 10 and Only Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  input.style.borderColor = "#e74c3c";
                                                      document.getElementById('mobile2').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
											</script>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												
												<div class="col ctl">
													<input type="submit" name="submit0" value="Update"class="btn btn-primary" style="margin-left: 75%">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
									</form>
	<?php  
		if(isset($_POST['submit0'])){
			$Mobile=$_POST['mobile'];
            $Alt_Mobile=$_POST['mobile2'];
            $House_Name=$_POST['address'];
            $Street=$_POST['place'];
            $City=$_POST['city'];
            $dist_id=$_POST['district'];
            $state_id=$_POST['state'];
            
            $qry="UPDATE stud 
            set Mobile='$Mobile',
                 Alt_Mobile='$Alt_Mobile',
                 House_Name='$House_Name',
                 Street='$Street',
                 City='$City',
                 dist_id='$dist_id',
                 state_id='$state_id'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
                
                swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
		}
	?>
									</section>

									
	<!-- Tenth Details -->
	  <?php 

      $sql="SELECT 10th_p,10th_CGPA,10th_YoP,10th_Board,10th_School,10th_State_of_school,stat1 from academic where stud_id=$stud";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0)
        {
		
		$row1 = mysqli_fetch_array($res);
		$stat=$row1['stat1'];
        $th_p=$row1['10th_p'];
        $th_CGPA=$row1['10th_CGPA'];
        $th_YoP=$row1['10th_YoP'];
        $th_Board=$row1['10th_Board'];
        $th_School=$row1['10th_School'];
        $State_id=$row1['10th_State_of_school'];
        $sql3="SELECT state_name FROM state where state_id=$State_id";
        $resul=mysqli_query($conn,$sql3);
        if(mysqli_num_rows($resul) > 0){
        	$row = mysqli_fetch_array($resul);
			$th_State_of_School=$row['state_name'];
			
        }
      }
    else
    {
        $th_p="";
        $th_CGPA="";
        $th_YoP="Choose year";
        $th_Board="choose Board";
        $th_School="";
        $th_State_of_School="Choose State";
    } 

  ?>

									<section id="section-2">
										<form method="POST">
											
										<div class="fo-top">
											
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Board</label>
												<div class="col-sm-8 ctl">
													<select name="tboard" id="field-2" required="true" class="form-control">
													<option value="<?php echo $th_Board ?>"><?php echo $th_Board ?></option>
                                                    <option value="ICSE">ICSE</option>
                                                    <option value="CBSC">CBSE</option>
                                                    <option value="Kerala State Board"> Kerala State Board</option>
                                                    <!-- <option value="Other">Other</option> -->
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Name of School</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1" name="tsname" value="<?php echo $th_School ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">State of school</label>
												<div class="col-sm-8 ctl">
													<select name="tstate" id="field-2" required="true" class="form-control">
														<option value="<?php echo $State_id ?>"><?php echo $th_State_of_School ?></option>

                                            <?php 
                                                $sql="SELECT * FROM state";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['state_id'] ?>"><?php echo $row['state_name']; ?></option>
                                            <?php }
                                     }  ?>  
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Year of Pass</label>
												<div class="col-sm-8 ctl">
													<select name="tyear" id="field-2" required="true" class="form-control">
														<option value="<?php echo $th_YoP ?>"><?php echo $th_YoP ?></option>
                                    <?php 
                                        $year = date("Y");
                                        for($j = $year-5; $j > $year-10; $j--) { 
                                            $_SESSION['y']=$year;
                                    ?>
                                    <option value="<?php echo $j; ?>"><?php echo $j; ?></option>
                                    <?php } ?>
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->

												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Percentage</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1" value="<?php echo $th_p ?>" name="Percent">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">CGPA</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1" value="<?php echo $th_CGPA ?>" name="cgpa">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>

										<div class="fo-top" id="sub">
											<div class="form-group">
												
												
												<div class="col ctl">
													<input type="submit" id="submit1" name="submit1" value="Update"class="btn btn-primary" style="margin-left: 75%">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
	
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										</form>
	<?php 
		
      if(isset($_POST['submit1']))
      {
        $Board=$_POST['tboard'];
        $Name_of_School=$_POST['tsname'];
        $State_of_School=$_POST['tstate'];
        $Year_of_Pass=$_POST['tyear'];
        $Percentage=$_POST['Percent'];
		$CGPA=$_POST['cgpa'];
		$stat=1;

        $qry="UPDATE academic 
            set 10th_p='$Percentage',
                 10th_CGPA='$CGPA',
                 10th_YoP='$Year_of_Pass',
                 10th_Board='$Board',
                 10th_School='$Name_of_School',
                 10th_State_of_School='$State_of_School',
                 stat1='$stat'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
                
                swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
      } else
      {
          
      }
  ?>


 <?php 
				if($stat==1){
		
					echo"
					<script type='text/javascript'> 
						
						document.getElementById('submit1').style.display='none'; 
					</script>
					";
				}
				// 
			?>
									</section>
		<!-- plus two details -->
									<section id="section-3">
	<?php 
	$sql="SELECT 12th_p,12th_CGPA,12th_YoP,12th_Board,12th_School,12th_State_of_School,stat2 from academic where stud_id=$stud";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0)
        {
        $row1 = mysqli_fetch_array($res);
        $stat2=$row1['stat2'];
        $th_p=$row1['12th_p'];
        $th_CGPA=$row1['12th_CGPA'];
        $th_YoP=$row1['12th_YoP'];
        $th_Board=$row1['12th_Board'];
        $th_School=$row1['12th_School'];
        $tstate_id=$row1['12th_State_of_School'];
        $sql3="SELECT state_name FROM state where state_id=$State_id";
        $resul=mysqli_query($conn,$sql3);
        if(mysqli_num_rows($resul) > 0){
        	$row = mysqli_fetch_array($resul);
			$twth_State_of_School=$row['state_name'];
      }
  }
    else
    {
        $th_p="";
        $th_CGPA="";
        $th_YoP="Choose year";
        $th_Board="choose Board";
        $th_School="";
        $twth_State_of_School="Choose State";
    } 
	?>								<form method="POST">
										<div class="fo-top">
											<!-- <span style="margin-left: 30%; color: red">To edit values you need to enter values and press update</span> -->
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Board</label>
												<div class="col-sm-8 ctl">
													<select name="twboard" id="field-2" required="true" class="form-control">
													<option value="<?php echo $th_Board ?>"><?php echo $th_Board ?></option>
                                                    <option value="ICSE">ICSE</option>
                                                    <option value="CBSC">CBSE</option>
                                                    <option value="kerala State Board">Kerala State Board</option>
                                                    <!-- <option value="Other">Other</option> -->
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Name of School</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1" value="<?php echo $th_School ?>" name="twsname">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">State of School</label>
												<div class="col-sm-8 ctl">
													<select name="twstate" id="field-2" required="true" class="form-control">
														<option value="$tstate_id"><?php echo $twth_State_of_School ?></option>

                                            <?php 
                                                $sql="SELECT * FROM state";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['state_id'] ?>"><?php echo $row['state_name']; ?></option>
                                            <?php }
                                     }  ?>  
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Year of pass</label>
												<div class="col-sm-8 ctl">
													<select name="twyear" id="field-2" required="true" class="form-control">
														<option value="<?php echo $th_YoP ?>"><?php echo $th_YoP ?></option>
                                    <?php 
                                        $year = date("Y");
                                        for($j = $year-3; $j > $year-8; $j--) { 
                                            $_SESSION['y']=$year;
                                    ?>
                                    <option value="<?php echo $j; ?>"><?php echo $j; ?></option>
                                    <?php } ?>
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Percentage</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1" name="twper" value="<?php echo $th_p ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">CGPA</label>
												<div class="col-sm-8 ctl">
													<input type="text" class="form-control1" name="twcgpa" value="<?php echo $th_CGPA ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												
												<div class="col ctl">
													<input type="submit" id="submit2" name="submit2" value="Update"class="btn btn-primary" style="margin-left: 75%">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
									</form>
	<?php 
				if($stat2==1){
		
					echo"
					<script type='text/javascript'> 
						
						document.getElementById('submit2').style.display='none'; 
					</script>
					";
				}
				// 
			?>
									</section>
	<?php 

      if(isset($_POST['submit2']))
      {
        $Board=$_POST['twboard'];
        $Name_of_School=$_POST['twsname'];
        $State_of_School=$_POST['twstate'];
        $Year_of_Pass=$_POST['twyear'];
        $Percentage=$_POST['twper'];
        $CGPA=$_POST['twcgpa'];
        $stat2=1;
        $qry="UPDATE academic 
            set 12th_p='$Percentage',
                 12th_CGPA='$CGPA',
                 12th_YoP='$Year_of_Pass',
                 12th_Board='$Board',
                 12th_School='$Name_of_School',
                 12th_State_of_School='$State_of_School',
                 stat2='$stat2',
                 login_id='$id'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
				swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
      } 
      
         ?>
         <!-- degree details -->
									<section id="section-4">
		<?php 
	$sql="SELECT UG_Course,UG_P,UG_CGPA,UG_YoP,UG_College,state_of_UG,UG_University,stat3 from academic where stud_id=$stud";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0)
        {
        	// UG_Course	UG_P	UG_CGPA	UG_YoP	UG_College	state_of_UG	UG_University
        $row1 = mysqli_fetch_array($res);
        $stat3=$row1['stat3'];
        $UG_P=$row1['UG_P'];
        $UG_CGPA=$row1['UG_CGPA'];
        $UG_YoP=$row1['UG_YoP'];
        $UG_University=$row1['UG_University'];
        $UG_College=$row1['UG_College'];
        $ugstate_id=$row1['state_of_UG'];
        $Course_id=$row1['UG_Course'];
        $sql3="SELECT state_name FROM state where state_id=$ugstate_id";
        $resul=mysqli_query($conn,$sql3);
        if (!$ugstate_id=="") {
        	if(mysqli_num_rows($resul) > 0){
        	$row = mysqli_fetch_array($resul);
			$state_of_UG=$row['state_name'];
        	}
        	else{$state_of_UG="Choose State";}
        }
        
        if(!$Course_id==""){
	        $sql4="SELECT department_name FROM department where dept_id=$Course_id";
	        $resu=mysqli_query($conn,$sql4);
	        if(mysqli_num_rows($resu) > 0){
	        	$row = mysqli_fetch_array($resu);
				$UG_Course=$row['department_name'];
	        }
    	}
    	else{
    		$UG_Course="Choose Course";
    	}
  }
    else
    {
        $UG_P="";
        $UG_CGPA="";
        $UG_YoP="Choose year";
        $UG_Course="choose Course";
        $UG_College="";
        $state_of_UG="Choose State";
        $UG_University="Choose university";
    } 
	?>								
									<form method="POST">
										<!-- <span style="margin-left: 30%; color: red">To edit values you need to enter values and press update</span> -->
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">College Name</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="clgname" class="form-control1" id="focusedinput" value="<?php echo $UG_College ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">University</label>
												<div class="col-sm-8 ctl">
													<select name="clguni" id="field-22" required="true" class="form-control" onchange="otherwise(this)">
														<option value="<?php echo $UG_University ?>"><?php echo $UG_University ?></option>
														<option value="MG">MG</option>
														<option value="KTU">KTU</option>
														<option value="Calicut">Calicut</option>
														<option value="Others">Others</option>
													</select>
													<input type="text" class="form-control1" name="oth" class="errortext" style="display:none;" id="oth">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
											<script>
												function otherwise(input){
													var val=input.value;
													if(val=="Others"){
														$("#oth").html('Min. 3 and Only Alphabets Allowed..!').fadeIn();
                                                      
                                                      return false;

													}
													else{
														$("#oth").html('Min. 3 and Only Alphabets Allowed..!').delay(10).fadeOut();
                                                      
													}
												}
											</script>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">State of College</label>
												<div class="col-sm-8 ctl">
													<select name="clgstate" id="field-2" required="true" class="form-control">
														<option value="<?php echo $ugstate_id ?>"><?php echo $state_of_UG ?></option>

                                            <?php 
                                                $sql="SELECT * FROM state";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['state_id'] ?>"><?php echo $row['state_name']; ?></option>
                                            <?php }
                                     }  ?>  
													</select>
												</div>
												<div class="col-sm-2 hp">
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Year of Pass</label>
												<div class="col-sm-8 ctl">
													<select name="clgyear" id="field-2" required="true" class="form-control">
														<option value="<?php echo $UG_YoP ?>"><?php echo $UG_YoP ?></option>
                                    <?php 
                                        $year = date("Y");
                                        for($j = $year-1; $j > $year-6; $j--) { 
                                            $_SESSION['y']=$year;
                                    ?>
                                    <option value="<?php echo $j; ?>"><?php echo $j; ?></option>
                                    <?php } ?>
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label"> UG Course</label>
												<div class="col-sm-8 ctl">
													<select name="clgcourse" id="field-2" required="true" class="form-control">
														<option value="<?php echo $Course_id ?>"><?php echo $UG_Course ?></option>

                                            <?php 
                                                if($course==3){
										$sql="SELECT * FROM department where course='Btech' order by department_name ASC";
                                            	}else{
										$sql="SELECT * FROM department where status=0 order by department_name ASC";
                                            	}
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['dept_id'] ?>"><?php echo $row['department_name']; ?></option>

                                            <?php }
                                     }  ?>  
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Percentage</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="clgper" class="form-control1" id="focusedinput" value="<?php echo $UG_P ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">CGPA</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="clgcgpa" class="form-control1" id="focusedinput" value="<?php echo $UG_CGPA ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												
												<div class="col ctl">
													<input type="submit" id="submit3" name="submit3" value="Update"class="btn btn-primary" style="margin-left: 75%">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
									</form>
<?php 
				if($stat3==1){
		
					echo"
					<script type='text/javascript'> 
						
						document.getElementById('submit3').style.display='none'; 
					</script>
					";
				}
				// 
			?>

	<?php 

      if(isset($_POST['submit3']))
      {
        $Board=$_POST['clguni'];
        $Name_of_School=$_POST['clgname'];
        $State_of_School=$_POST['clgstate'];
        $Year_of_Pass=$_POST['clgyear'];
        $Percentage=$_POST['clgper'];
        $CGPA=$_POST['clgcgpa'];
        $course=$_POST['clgcourse'];
        $stat3=1;
        if($Board=="Others"){
        	$Board=$_POST['oth'];
        }
        // UG_Course	UG_P	UG_CGPA	UG_YoP	UG_College	state_of_UG	UG_University
        $qry="UPDATE academic 
            set UG_Course='$course',
                 UG_P='$Percentage',
                 UG_CGPA='$CGPA',
                 UG_YoP='$Year_of_Pass',
                 UG_College='$Name_of_School',
                 state_of_UG='$State_of_School',
                 UG_University='$Board',
                 stat3='$stat3'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
                
				swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
      } 
      
         ?>
									</section>
			
		
									<section id="section-5">
	<?php 
	$sql="SELECT Aggr_CGPA,Aggr_Percentage,CURRENT_ARREARS,HISTORY_OF_ARREARS,PG_University,Technical_Skills,Work_Experience,Certifications,Internships,stat4 from academic where stud_id=$stud";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0)
        {
        $row1 = mysqli_fetch_array($res);
        $stat4=$row1['stat4'];
        $Aggr_CGPA=$row1['Aggr_CGPA'];
        $Aggr_Percentage=$row1['Aggr_Percentage'];
        $CURRENT_ARREARS=$row1['CURRENT_ARREARS'];
        $PG_University=$row1['PG_University'];
        $Technical_Skills=$row1['Technical_Skills'];
        $Work_Experience=$row1['Work_Experience'];
        $Certifications=$row1['Certifications'];
        $Internships=$row1['Internships'];
        $sql3="SELECT state_name FROM state where state_id=$State_id";
        $resul=mysqli_query($conn,$sql3);
        if(mysqli_num_rows($resul) > 0){
        	$row = mysqli_fetch_array($resul);
			$th_State_of_School=$row['state_name'];
      }
  }
    else
    {
        $Aggr_CGPA="";
        $Aggr_Percentage="";
        $CURRENT_ARREARS="Choose ";
        $PG_University="choose University";
        $Technical_Skills="";
        $Work_Experience="";
        $Certifications="";
        $Internships="";
    } 
	?>
									<form method="POST">
										<!-- <span style="margin-left: 30%; color: red">To edit values you need to enter values and press update</span> -->
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">PG University</label>
												<div class="col-sm-8 ctl">
													<select name="PG_University" id="univ" required="true" onchange="otherwise2(this)" class="form-control" style="color: black">
														<option value="<?php echo $PG_University ?>"><?php echo $PG_University ?></option>
														<option value="MG">MG</option>
														<option value="KTU">KTU</option>
														<option value="Calicut">Calicut</option>
														<option value="Others">Others</option>
													</select>
													<input type="text" class="form-control1" name="oth2" class="errortext" style="display:none;" id="oth2">
												</div>
												<div class="col-sm-2 hp">
													<script>
												function otherwise2(input){
													var val=input.value;
													if(val=="Others"){
														$("#oth2").html('Min. 3 and Only Alphabets Allowed..!').fadeIn();
                                                      
                                                      return false;

													}
													else{
														$("#oth2").html('Min. 3 and Only Alphabets Allowed..!').delay(10).fadeOut();
                                                      
													}
												}
											</script>
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Aggrigate CGPA</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Aggr_CGPA" class="form-control1" id="aggr1" value="<?php echo $Aggr_CGPA ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Aggrigate Percentage</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Aggr_Percentage" class="form-control1" id="aggrp1" value="<?php echo $Aggr_Percentage ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Current Arrears</label>
												<div class="col-sm-8 ctl">
													<select name="CURRENT_ARREARS" id="arr1" required="true" class="form-control">
														<option value="<?php echo $CURRENT_ARREARS ?>"><?php echo $CURRENT_ARREARS ?></option>
														<?php 
                                        $year = date("Y");
                                        for($j = 0; $j <= 10; $j++) { 
                                    ?>
                                    <option value="<?php echo $j; ?>"><?php echo $j; ?></option>
                                    <?php } ?>
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div><br>


										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Technical_Skills</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Technical_Skills" class="form-control1" id="focusedinput" value="<?php echo $Technical_Skills ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Work_Experience</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Work_Experience" class="form-control1" id="focusedinput" value="<?php echo $Work_Experience ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Certifications</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Certifications" class="form-control1" id="focusedinput" value="<?php echo $Certifications ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Internships</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Internships" class="form-control1" id="focusedinput" value="<?php echo $Internships ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<div class="col ctl">
													<input type="submit" id="submit4" name="submit4" value="Update"class="btn btn-primary" style="margin-left: 75%">
													<input type="submit" id="submit5" name="submit5" value="Update"class="btn btn-primary" style="margin-left: 75%">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										</form>
	<?php 
				if($stat4==1){
		
					echo"
					<script type='text/javascript'> 
						document.getElementById('univ').disabled = true;
						document.getElementById('aggr1').disabled = true; 
						document.getElementById('aggrp1').disabled = true; 
						document.getElementById('arr1').disabled = true; 
						document.getElementById('submit4').style.display='none'; 
					</script>
					";
				}
				else{
					echo"
					<script type='text/javascript'> 
						
						document.getElementById('submit5').style.display='none'; 
					</script>
					";
				} 
			?>
									</section>
	<?php 
		if(isset($_POST['submit5'])){
			$Technical_Skills=$_POST['Technical_Skills'];
	        $Work_Experience=$_POST['Work_Experience'];
	        $Certifications=$_POST['Certifications'];
	        $Internships=$_POST['Internships'];
	        $qry="UPDATE academic set
	        	 Technical_Skills='$Technical_Skills',
                 Work_Experience='$Work_Experience',
                 Certifications='$Certifications',
                 Internships='$Internships'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
				swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
		}
      if(isset($_POST['submit4']))
      {
        $Aggr_CGPA=$_POST['Aggr_CGPA'];
        $Aggr_Percentage=$_POST['Aggr_Percentage'];
        $CURRENT_ARREARS=$_POST['CURRENT_ARREARS'];
        $PG_University=$_POST['PG_University'];
        $Technical_Skills=$_POST['Technical_Skills'];
        $Work_Experience=$_POST['Work_Experience'];
        $Certifications=$_POST['Certifications'];
        $Internships=$_POST['Internships'];
        $stat4=1;
$arrer=$CURRENT_ARREARS;
$total=$Aggr_CGPA;
        if($PG_University=="Others"){
        	$PG_University=$_POST['oth2'];
        }
        // UG_Course	UG_P	UG_CGPA	UG_YoP	UG_College	state_of_UG	UG_University
        $qry="UPDATE academic 
            set Aggr_CGPA='$Aggr_CGPA',
                 Aggr_Percentage='$Aggr_Percentage',
                 CURRENT_ARREARS='$CURRENT_ARREARS',
                 PG_University='$PG_University',
                 Technical_Skills='$Technical_Skills',
                 Work_Experience='$Work_Experience',
                 Certifications='$Certifications',
                 Internships='$Internships',
                 stat4='$stat4'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
				swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
     //new Update
       		// to fetch the notification

    $sql5="SELECT 10th_p,12th_p from academic where stud_id=$stud";
    	 $result=mysqli_query($conn,$sql5);
              if(mysqli_num_rows($result)>0)
              {
              	$row = mysqli_fetch_array($result);
              	$tenth=$row['10th_p'];
              	$plus_two=$row['12th_p'];
              	  
              }
    $qry2="SELECT notif_id,elig_branch,tenth,plus_two,degree,backlog,date1 from notification";
      $result=mysqli_query($conn,$qry2);
              if(mysqli_num_rows($result)>0)
              {
                while($row = mysqli_fetch_array($result)){
	                $ten=$row['tenth'];
	                $branch=explode(",", $row['elig_branch']);
	                $twelve=$row['plus_two'];
	                $degree=$row['degree'];
	                $back=$row['backlog'];

	                $notif_id=$row['notif_id'];
	                	$date1=$row['date1'];
	                	$pieces = explode("-", $date1);
	                $dt1=$pieces[0].$pieces[1].$pieces[2];
	                	$today=date("Y/m/d");
	                	$pieces = explode("/", $today);
	                $Cur_date=$pieces[0].$pieces[1].$pieces[2];
	                
	                if($dt1>$Cur_date){
	                	// check eligibility...
		                	$r=0;
		                	foreach ($branch as $value) {
		                		
		                		if($mydepartment==$value){

		                			$r=1;
		                			break;
		                		}
		                	}
		                	
		                	if($ten<$tenth){ $r=1;} else{ $r=0; }
		                	
		  					if($twelve<$plus_two){ $r=1; } else{ $r=0;}
		  					
		  					if($total>$degree){ $r=1;} else{ $r=0;}
		  					
		  					if($arrer<$back){$r=1;} else{ $r=0; }
		  					
		  					$status=1;
		  					if($r==1){
				            	$sql2="INSERT into drive_elig (notif_id,stud_id,status)values($notif_id,$stud,$status)";
				            	$result1=mysqli_query($conn,$sql2);
				            	?><script>
				            		swal('Updated!', 'Successfully..!', 'success');
				            	</script><?php
				            }else{
				            	  ?>
				                <script type="text/javascript">
				                
								swal('Sorry!', 'No New Notifications for you !', 'error');
				                </script>
				                <?php
				            }
				    }else{
				        
				    }
	            }
	          }
}
         ?>
							<!-- Btech section -->

								<section id="section-7">
	<?php 
	$sql="SELECT Aggr_CGPA,Aggr_Percentage,CURRENT_ARREARS,Technical_Skills,Work_Experience,Certifications,Internships,stat3,UG_Course,UG_YOP from academic where stud_id=$stud";
    $res=mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)>0)
        {
        $row1 = mysqli_fetch_array($res);
        $stat4=$row1['stat3'];
        $course=$row1['UG_Course'];
        $yop=$row1['UG_YOP'];
        $Aggr_CGPA=$row1['Aggr_CGPA'];
        $Aggr_Percentage=$row1['Aggr_Percentage'];
        $CURRENT_ARREARS=$row1['CURRENT_ARREARS'];
        $Technical_Skills=$row1['Technical_Skills'];
        $Work_Experience=$row1['Work_Experience'];
        $Certifications=$row1['Certifications'];
        $Internships=$row1['Internships'];
        // echo"<script>alert('".$stat4."')</script>";
    }
    else
    {
        $course="choose";
        $yop="choose";
        $Aggr_CGPA="";
        $Aggr_Percentage="";
        $CURRENT_ARREARS="Choose ";
        $Technical_Skills="";
        $Work_Experience="";
        $Certifications="";
        $Internships="";
    } 
	?>			
									<form method="POST">
										<!-- <span style="margin-left: 30%; color: red">To edit values you need to enter values and press update</span> -->
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label"> Course</label>
												<div class="col-sm-8 ctl">
													<select name="clgcourse1" id="cour" required="true" class="form-control">
														<option value="<?php echo $Course_id ?>"><?php echo $UG_Course ?></option>

                                            <?php 
                                                $sql="SELECT * FROM department where dept_id='$dept_id' order by department_name ASC";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['dept_id'] ?>"><?php echo $row['department_name']; ?></option>

                                            <?php }
                                     }  ?>  
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Year of Pass</label>
												<div class="col-sm-8 ctl">
													<select name="clgyear1" id="yearof" required="true" class="form-control">
														<option value="<?php echo $yop ?>"><?php echo $yop ?></option>
                                    <?php 
                                    // echo"<script>alert('".$yop."')</script>";
                                        $year = date("Y");
                                        for($j = $year+1; $j > $year-6; $j--) { 
                                            $_SESSION['y']=$year;
                                    ?>
                                    <option value="<?php echo $j; ?>"><?php echo $j; ?></option>
                                    <?php } ?>
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Aggrigate CGPA</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Aggr_CGPA1" class="form-control1" id="aggr" value="<?php echo $Aggr_CGPA ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Aggrigate Percentage</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Aggr_Percentage1" class="form-control1" id="aggrp" value="<?php echo $Aggr_Percentage ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Current Arrears</label>
												<div class="col-sm-8 ctl">
													<select name="CURRENT_ARREARS1" id="arr" required="true" class="form-control">
														<option value="<?php echo $CURRENT_ARREARS ?>"><?php echo $CURRENT_ARREARS ?></option>
														<?php 
                                        $year = date("Y");
                                        for($j = 0; $j <= 10; $j++) { 
                                    ?>
                                    <option value="<?php echo $j; ?>"><?php echo $j; ?></option>
                                    <?php } ?>
													</select>
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div><br>


										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Technical_Skills</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Technical_Skills" class="form-control1" id="focusedinput" value="<?php echo $Technical_Skills ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Work_Experience</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Work_Experience" class="form-control1" id="focusedinput" value="<?php echo $Work_Experience ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Certifications</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Certifications" class="form-control1" id="focusedinput" value="<?php echo $Certifications ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												<label for="focusedinput" class="col-sm-2 control-label">Internships</label>
												<div class="col-sm-8 ctl">
													<input type="text" name="Internships" class="form-control1" id="focusedinput" value="<?php echo $Internships ?>">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										<div class="fo-top">
											<div class="form-group">
												
												
												<div class="col ctl">
													<input type="submit" id="submit7" name="submit7" value="Update"class="btn btn-primary" style="margin-left: 75%">
													<input type="submit" id="submit8" name="submit8" value="Update"class="btn btn-primary" style="margin-left: 75%">
												</div>
												<div class="col-sm-2 hp">
													<!-- <p class="help-block">(GLOBAL)</p> -->
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
										
									</form>
<?php 
				if($stat4==1){
		
					echo"
					<script type='text/javascript'> 

				 		document.getElementById('submit7').style.display='none'; 
						
					</script>	";
					echo"
						<script>
							document.getElementById('cour').disabled = true;
							document.getElementById('yearof').disabled = true;
							document.getElementById('aggr').disabled = true;
							document.getElementById('aggrp').disabled = true;
							document.getElementById('arr').disabled = true;
						</script>
					";
				}else{
					echo"
					<script type='text/javascript'> 
						
						document.getElementById('submit8').style.display='none'; 
					</script>   ";
				}
				// 
			?>

	<?php 
		if(isset($_POST['submit8'])){
			$Technical_Skills=$_POST['Technical_Skills'];
	        $Work_Experience=$_POST['Work_Experience'];
	        $Certifications=$_POST['Certifications'];
	        $Internships=$_POST['Internships'];
	        $qry="UPDATE academic set
	        	 Technical_Skills='$Technical_Skills',
                 Work_Experience='$Work_Experience',
                 Certifications='$Certifications',
                 Internships='$Internships'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
				swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
		}
      if(isset($_POST['submit7']))
      {
        $Year_of_Pass=$_POST['clgyear1'];
        $course=$_POST['clgcourse1'];
        $Agg_CGPA=$_POST['Aggr_CGPA1'];
        $Agg_Per=$_POST['Aggr_Percentage1'];
        $Cur_Arr=$_POST['CURRENT_ARREARS1'];
        $stat3=1;
$arrer=$Cur_Arr;
$total=$Agg_CGPA; 
        	$Technical_Skills=$_POST['Technical_Skills'];
	        $Work_Experience=$_POST['Work_Experience'];
	        $Certifications=$_POST['Certifications'];
	        $Internships=$_POST['Internships'];
        $qry="UPDATE academic 
            set Aggr_CGPA='$Agg_CGPA',
                 Aggr_Percentage='$Agg_Per',
                 CURRENT_ARREARS='$Cur_Arr',
                 UG_YOP='$Year_of_Pass',
                 UG_Course='$course',
                 stat3='$stat3',
                 Technical_Skills='$Technical_Skills',
                 Work_Experience='$Work_Experience',
                 Certifications='$Certifications',
                 Internships='$Internships'
            where stud_id='$stud'";
            if ($conn->query($qry) === TRUE) 
            {
                ?>
                <script type="text/javascript">
                    setTimeout(function() {
                        swal({
                            title: "Updated!",
                            text: "Successfully..!!",
                            type: "success"
                        }, function() {
                            window.location = "personal.php";
                        });
                    }, 1000);
                    </script>
                <?php 
            } else {
                echo "Error: " . $qry . "<br>" . $conn->error;
                        ?>
                <script type="text/javascript">
                
				swal('Oops!', 'Something went wrong!', 'error');
                </script>
                <?php
            }
      //new Update
       		// to fetch the notification

    $sql5="SELECT 10th_p,12th_p from academic where stud_id=$stud";
    	 $result=mysqli_query($conn,$sql5);
              if(mysqli_num_rows($result)>0)
              {
              	$row = mysqli_fetch_array($result);
              	$tenth=$row['10th_p'];
              	$plus_two=$row['12th_p'];
              	  
              }
    $qry2="SELECT notif_id,elig_branch,tenth,plus_two,degree,backlog,date1 from notification";
      $result=mysqli_query($conn,$qry2);
              if(mysqli_num_rows($result)>0)
              {
                while($row = mysqli_fetch_array($result)){
	                $ten=$row['tenth'];
	                $branch=explode(",", $row['elig_branch']);
	                $twelve=$row['plus_two'];
	                $degree=$row['degree'];
	                $back=$row['backlog'];

	                $notif_id=$row['notif_id'];
	                	$date1=$row['date1'];
	                	$pieces = explode("-", $date1);
	                $dt1=$pieces[0].$pieces[1].$pieces[2];
	                	$today=date("Y/m/d");
	                	$pieces = explode("/", $today);
	                $Cur_date=$pieces[0].$pieces[1].$pieces[2];
	                
	                if($dt1>$Cur_date){
	                	// check eligibility...
		                	$r=0;
		                	foreach ($branch as $value) {
		                		
		                		if($mydepartment==$value){

		                			$r=1;
		                			break;
		                		}
		                	}
		                	
		                	if($ten<$tenth){ $r=1;} else{ $r=0; }
		                	
		  					if($twelve<$plus_two){ $r=1; } else{ $r=0;}
		  					
		  					if($total>$degree){ $r=1;} else{ $r=0;}
		  					
		  					if($arrer<$back){$r=1;} else{ $r=0; }
		  					
		  					$status=1;
		  					if($r==1){
				            	$sql2="INSERT into drive_elig (notif_id,stud_id,status)values($notif_id,$stud,$status)";
				            	$result1=mysqli_query($conn,$sql2);
				            	?><script>
				            		swal('Updated!', 'Successfully..!', 'success');
				            	</script><?php
				            }else{
				            	  ?>
				                <script type="text/javascript">
				                
								swal('Sorry!', 'No New Notifications for you !', 'error');
				                </script>
				                <?php
				            }
				    }else{
				        
				    }
	            }
	          }
}
      
         ?>
									</section>											
								</div><!-- /content -->
						</div>
												<!-- /tabs -->
											</div>	
								<script src="js/cbpFWTabs.js"></script>
									<script>
										new CBPFWTabs( document.getElementById( 'tabs' ) );
									</script>
											
	</div>
<!---728x90--->

	<!-- end content -->
	<div class="fo-top-di">
			<div class="foot-top">
				
					<div class="col-md-6 s-c">
						<li>
							<div class="fooll">
								<h1>follow us on</h1>
							</div>
						</li>
						<li>
							<div class="social-ic">
								<ul>
									<li><a href="#"><i class="facebok"> </i></a></li>
									<li><a href="#"><i class="twiter"> </i></a></li>
									<li><a href="#"><i class="goog"> </i></a></li>
									<li><a href="#"><i class="be"> </i></a></li>
										<div class="clearfix"></div>	
								</ul>
							</div>
						</li>
							<div class="clearfix"> </div>
					</div>
					<div class="col-md-6 s-c">
						<div class="stay">
									
										<div class="clearfix"> </div>
						</div>
					</div>
					<div class="clearfix"> </div>
				
			</div>
				<div class="clearfix"> </div>
						<p style="margin-left: 40%">© 2019 Cam-RA. All Rights Reserved </p>
			</div>
		</div>	
	
</div>

</div>
			<!--content-->
		</div>
</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<header class="logo1">
						 <span style="color: white;font-size: 30px;margin-left: 40px">Cam-RA</span><br><span style="color: white;font-size: 16px">Campus Recruiter Assistant</span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<?php include 'user_nav.php'; ?>
								</div>
							  </div>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>
	<script type="text/javascript">

	$(function() {

		// We use an inline data source in the example, usually data would
		// be fetched from a server

		var data = [],
			totalPoints = 300;

		function getRandomData() {

			if (data.length > 0)
				data = data.slice(1);

			// Do a random walk

			while (data.length < totalPoints) {

				var prev = data.length > 0 ? data[data.length - 1] : 50,
					y = prev + Math.random() * 10 - 5;

				if (y < 0) {
					y = 0;
				} else if (y > 100) {
					y = 100;
				}

				data.push(y);
			}

			// Zip the generated y values with the x values

			var res = [];
			for (var i = 0; i < data.length; ++i) {
				res.push([i, data[i]])
			}

			return res;
		}

		// Set up the control widget

		var updateInterval = 30;
		$("#updateInterval").val(updateInterval).change(function () {
			var v = $(this).val();
			if (v && !isNaN(+v)) {
				updateInterval = +v;
				if (updateInterval < 1) {
					updateInterval = 1;
				} else if (updateInterval > 2000) {
					updateInterval = 2000;
				}
				$(this).val("" + updateInterval);
			}
		});

		var plot = $.plot("#placeholder", [ getRandomData() ], {
			series: {
				shadowSize: 0	// Drawing is faster without shadows
			},
			yaxis: {
				min: 0,
				max: 100
			},
			xaxis: {
				show: false
			}
		});

		function update() {

			plot.setData([getRandomData()]);

			// Since the axes don't change, we don't need to call plot.setupGrid()

			plot.draw();
			setTimeout(update, updateInterval);
		}

		update();

		// Add the Flot version string to the footer

		$("#footer").prepend("Flot " + $.plot.version + " &ndash; ");
	});

	</script>
<!-- /real-time -->
<script src="js/jquery.fn.gantt.js"></script>
    <script>

		$(function() {

			"use strict";

			$(".gantt").gantt({
				source: [{
					name: "Sprint 0",
					desc: "Analysis",
					values: [{
						from: "/Date(1320192000000)/",
						to: "/Date(1322401600000)/",
						label: "Requirement Gathering", 
						customClass: "ganttRed"
					}]
				},{
					name: " ",
					desc: "Scoping",
					values: [{
						from: "/Date(1322611200000)/",
						to: "/Date(1323302400000)/",
						label: "Scoping", 
						customClass: "ganttRed"
					}]
				},{
					name: "Sprint 1",
					desc: "Development",
					values: [{
						from: "/Date(1323802400000)/",
						to: "/Date(1325685200000)/",
						label: "Development", 
						customClass: "ganttGreen"
					}]
				},{
					name: " ",
					desc: "Showcasing",
					values: [{
						from: "/Date(1325685200000)/",
						to: "/Date(1325695200000)/",
						label: "Showcasing", 
						customClass: "ganttBlue"
					}]
				},{
					name: "Sprint 2",
					desc: "Development",
					values: [{
						from: "/Date(1326785200000)/",
						to: "/Date(1325785200000)/",
						label: "Development", 
						customClass: "ganttGreen"
					}]
				},{
					name: " ",
					desc: "Showcasing",
					values: [{
						from: "/Date(1328785200000)/",
						to: "/Date(1328905200000)/",
						label: "Showcasing", 
						customClass: "ganttBlue"
					}]
				},{
					name: "Release Stage",
					desc: "Training",
					values: [{
						from: "/Date(1330011200000)/",
						to: "/Date(1336611200000)/",
						label: "Training", 
						customClass: "ganttOrange"
					}]
				},{
					name: " ",
					desc: "Deployment",
					values: [{
						from: "/Date(1336611200000)/",
						to: "/Date(1338711200000)/",
						label: "Deployment", 
						customClass: "ganttOrange"
					}]
				},{
					name: " ",
					desc: "Warranty Period",
					values: [{
						from: "/Date(1336611200000)/",
						to: "/Date(1349711200000)/",
						label: "Warranty Period", 
						customClass: "ganttOrange"
					}]
				}],
				navigate: "scroll",
				scale: "weeks",
				maxScale: "months",
				minScale: "days",
				itemsPerPage: 10,
				onItemClick: function(data) {
					alert("Item clicked - show some details");
				},
				onAddClick: function(dt, rowId) {
					alert("Empty space clicked - add an item!");
				},
				onRender: function() {
					if (window.console && typeof console.log === "function") {
						console.log("chart rendered");
					}
				}
			});

			$(".gantt").popover({
				selector: ".bar",
				title: "I'm a popover",
				content: "And I'm the content of said popover.",
				trigger: "hover"
			});

			prettyPrint();

		});

    </script>
		   <script src="js/menu_jquery.js"></script>
</body>

</html>