<?php
include 'connection.php';
 
    // for the database
    $stud_id = $_GET['stud_id'];
    // echo"<script>alert('".$stud_id."')</script>";
    $profileImageName = time() . '-' . $_FILES["profileImage"]["name"];
    // For image upload
    $target_dir = "profile/";
    $target_file = $target_dir . basename($profileImageName);
    // VALIDATION
    // validate image size. Size is calculated in Bytes
    if($_FILES['profileImage']['size'] > 200000) {
      $msg = "Image size should not be greated than 200Kb";
      $msg_class = "alert-danger";
    }
    // check if file exists
    if(file_exists($target_file)) {
      $msg = "File already exists";
      $msg_class = "alert-danger";
    }
    // Upload image only if no errors
    if (empty($error)) {
      if(move_uploaded_file($_FILES["profileImage"]["tmp_name"], $target_file)) {
        $qry="UPDATE users set status=0 where stud_id=$stud_id";
        if(mysqli_query($conn, $qry)){
              $sql = "INSERT INTO users SET profile_image='$profileImageName', stud_id='$stud_id',status=1";
              if(mysqli_query($conn, $sql)){
                $msg = "Image uploaded and saved in the Database";
                $msg_class = "alert-success";
                echo"<script>alert('updated')</script>";
                header("location:personal.php");
              } else {
                $msg = "There was an error in the database";
                $msg_class = "alert-danger";
                header("location:personal.php");
              }
        } else {
          $error = "There was an error uploading the file";
          $msg = "alert-danger";
          echo"<script>alert('not updated')</script>";
          header("location:personal.php");
        }
    }
  }
?>