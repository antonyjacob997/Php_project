<?php
session_start();
include 'connection.php';
include 'sweetalerttest.php';
$uni_no=$_POST['uni_no'];
$title=$_POST['title'];
$fname=$_POST['fname'];
$mname=$_POST['mname'];
if(empty($mname)){
    $mname=" ";
}
$lname=$_POST['lname'];
$father=$_POST['father'];
$mother=$_POST['mother'];
$address=$_POST['address'];
$pincode=$_POST['pincode'];
$place=$_POST['place'];
$country=$_POST['country'];
$state=$_POST['state'];
$district=$_POST['dist'];
$city=$_POST['city'];
$mob=$_POST['mobile'];
$alt_mob=$_POST['alt_mobile'];
if(empty($alt_mob)){
    $alt_mob="";
}
$email=$_POST['email'];
$alt_email=$_POST['alt_email'];
if(empty($alt_email)){
    $alt_email=" ";
}
$password=md5($_POST['password']);
$gender=$_POST['gender'];
$course3=$_POST['course3'];
$name=$fname." ".$mname." ".$lname;
$y=date("Y"); 
$yop=$_POST['YOP'];
// $dob=$day."/".$month."/".$year;
$dob=$_POST['dob'];
$year=substr($dob,0,4);
$age=$y-$year;
$status=1;
$dept=$_POST['depart'];
$user_type="Student";
$login="";

            $sel="select email from login where email='$email'";
            $result=mysqli_query($conn,$sel);
            $sel2="select * from stud where University_Reg_No='$uni_no'";
            $result2=mysqli_query($conn,$sel2);
            if(mysqli_num_rows($result) > 0){
                echo"<script>";
                echo "alert('email already exist...')";
                echo "window.location='registration.php'";
                echo"</script>";
            }
            else if(mysqli_num_rows($result2) > 0){
                
                echo"<script>";
                echo "alert('Register Number already exist...!')";
                echo "window.location='registration.php'";
                echo"</script>";                           
            }
            else{
$qry="INSERT into login(user_type,email,password,status,psw) values('$user_type','$email','$password','$status',0)"; 


if ($conn->query($qry) === TRUE) 
    	{
    		
		} 

        $sel="select login_id from login where email='$email' and password='$password'";
        $result=mysqli_query($conn,$sel);
             if(mysqli_num_rows($result) > 0){
             		 $row = mysqli_fetch_array($result);
             			$login=$row['login_id'];
            }
         $sql="INSERT into stud (University_Reg_No,Title,First_Name,Middle_Name,Last_Name,Full_Name,Placed,dept_id,Mobile,Alt_Mobile,Alt_Email,DoB,Gender,Father_Name,Mother_Name,House_name,Street,City,dist_id,state_id,Pincode,country_id,login_id,status,course,year_of_pass)values('$uni_no','$title','$fname','$mname','$lname','$name',0,'$dept','$mob','$alt_mob','$alt_email','$dob','$gender','$father','$mother','$address','$place','$city','$district','$state','$pincode','$country','$login',1,'$course3','$yop')";


    if ($conn->query($sql) === TRUE) 
    {
        $qry="SELECT stud_id,Full_Name from stud where login_id='$login'";
        $result=mysqli_query($conn,$qry);
        if(mysqli_num_rows($result)>0)
            {
            $row = mysqli_fetch_array($result);
            $stud=$row['stud_id'];
        }

          $sql1="INSERT into academic(stud_id, Aggr_CGPA, Aggr_Percentage, CURRENT_ARREARS,HISTORY_OF_ARREARS,10th_p,10th_CGPA,10th_YoP,10th_Board,10th_School,10th_State_of_school,12th_p,12th_CGPA,12th_YoP,12th_Board,12th_School,12th_State_of_School,UG_Course,UG_P,UG_CGPA,UG_YoP,UG_College,state_of_UG,UG_University,PG_University,Technical_Skills,Work_Experience,Certifications,Internships,login_id,stat1,stat2,stat3,stat4)values($stud,'','',0,'','','','','','',12,'','','','','',12,'','','','','','','','','','','','',0,0,0,0,0)";
          if ($conn->query($sql1) === TRUE) 
        {

        ?>
        <script type="text/javascript">
        location.href="../index.php";
        alert("Registered successfully...");
    </script>
        <?php	
    } 
        
        else {
    		echo "Error: " . $sql . "<br>" . $conn->error;
		
        ?>
        <script type="text/javascript">
     //   location.href="registion.php";
        alert("Registion Failed...");
    </script>
        <?php
    }
}
}
?>
