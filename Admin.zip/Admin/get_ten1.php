<?php
include 'connection.php';

if(!empty($_POST['year1'])){
    $c=$_POST['year1'];

    $qry="SELECT * from history where year='$c'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result) > 0){
       $row = mysqli_fetch_array($result);
        $pp1= $row[1];  //company
        $pp2= $row[2];  //btech
        $pp3= $row[4];  //mtech
        $pp4= $row[3];  //mca
        $pp5= $row[7];  //reg_stud
        $pp6=$row[6];   //total placed
 
         // $response = array($row[1], $row[2],$row[3], $row[4],$row[6]); // add return data to an array
         // echo json_encode($response); // json encode that array
      echo' <label class="control-label" for="basicinput">Companies Visited</label>
                                        <div class="controls">
                                            <input type="text" disabled id="company" class="span8" value="'.$pp1.'">
                                        </div><br>
                                        <label class="control-label" for="basicinput">B-Tech total placed</label>
                                        <div class="controls">
                                            <input type="text" value="'.$pp2.'" disabled id="btech" class="span8">
                                        </div><br>
                                        <label class="control-label" for="basicinput">M-Tech total placed</label>
                                        <div class="controls">
                                            <input type="text" value="'.$pp3.'" disabled id="mtech" class="span8">
                                        </div><br>
                                        <label class="control-label" for="basicinput">MCA total placed</label>
                                        <div class="controls">
                                            <input type="text" disabled id="mca" class="span8" value="'.$pp4.'">
                                        </div><br>
                                        <label class="control-label" for="basicinput">Overall placed</label>
                                        <div class="controls">
                                            <input type="text" disabled id="tot" value="'.$pp6.'" class="span8" >
                                        </div><br>
                                        <label class="control-label" for="basicinput">Registered Students</label>
                                        <div class="controls">
                                            <input type="text" disabled id="total" class="span8" value="'.$pp5.'">
                                        </div><br>';

    }                                
     else{

        echo "$row[5]"; 
     }                                 
}

?>
