<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>

	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="myscript.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>	
<div>
    <?php include 'admin_top_nav.php'; ?>
</div>
        <!-- /navbar -->
	<div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->
                    <div class="span9">
                    	<div class="content">
                    		<div class="module">
	                            <div class="module-head">
	                                <h3>New Admin Registration</h3>
	                            </div>
              <div class="module-body">
                <div class="stream-composer media">
                                    
                    <form class="form-horizontal row-fluid" method="POST">
                        <div class="control-group">
                    		<div class="control-group" id="mark">
                                    <div id="disp">
                                    	<label class="control-label" for="basicinput">Name</label>
                                        <div class="controls">
                                            <input type="text" name="name" id="name" placeholder="Full Name" class="span8" onchange="Validatename(this);" required="required" autocomplete="off">
                                            <span style="color: red">*</span>
                                        <label class="errortext" style="display:none; color:red" id="name_l"></label>
                                        </div><br>
                                        <script>
                                        function Validatename(input)
                                            {
                                                  var val = document.getElementById('name').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_l").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('name').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('name').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                          </script>
                                       
                                        <label class="control-label" for="basicinput">Mobile</label>
                                        <div class="controls">
                                            <input type="text" name="mobile" id="mobile" placeholder="Mobile No" class="span8" onchange="Validatephone(this)" required="required">
                                        <span style="color: red">*</span>
                                        <label class="errortext" style="display:none; color:red" id="mobile_1">
                                        </label>
                                        </div><br>
                           			    <script>
                                              function Validatephone(input)
                                              {
                                                  var val = document.getElementById('mobile').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                  $("#mobile_1").html('Must. 10 and Only Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  input.style.borderColor = "#e74c3c";
                                                      document.getElementById('mobile').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                        </script>
                                        <label class="control-label" for="basicinput">Alternative Mobile</label>
                                        <div class="controls">
                                            <input type="text" name="alt_mob" id="alt_mob" placeholder="Alternative Mobile No" class="span8" onchange="Validatephone2(this)" >
                                        
                                        <label class="errortext" style="display:none; color:red" id="mobile_2">
                                        </div><br>
                                        <script>
                                              function Validatephone2(input)
                                              {
                                                  var val = document.getElementById('alt_mob').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                  $("#mobile_2").html('Must. 10 and Only Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  input.style.borderColor = "#e74c3c";
                                                      document.getElementById('alt_mob').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                        </script>
                                        <label class="control-label" for="basicinput">Email</label>
                                        <div class="controls">
                                            <input type="email" name="email" id="emailid" placeholder="Email id" class="span8" onchange="Validateemail3(this)" required="required"> 
                                        <span style="color: red">*</span>
                                        <label class="errortext" style="display:nne; color:red" id="email_1">
                                        </label></div><br>
                                         <script>
                                              function Validateemail3(input)
                                              {
                                                   var email = document.getElementById('emailid');
                                                     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                                     if (!filter.test(email.value)) {
                                                      email.value="";
                                                      $("#email_1").html('Please provide a valid email').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('emailid').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                          </script>
                                        <label class="control-label" for="basicinput">Alternative Email</label>
                                        <div class="controls">
                                             <input type="email" name="alt_email" id="emailid2" placeholder="Alt Email id" class="span8" onchange="Validateemail2(this)" > 
                                        <label class="errortext" style="display:nne; color:red" id="email_2">
                                        </label></div><br>
                                        <script>
                                        	function Validateemail2(input)
                                              {
                                                   var email = document.getElementById('emailid2');
                                                     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                                     if (!filter.test(email.value)) {
                                                      email.value="";
                                                      $("#email_2").html('Please provide a valid email').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('emailid2').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                        </script>
                                        <label class="control-label" for="basicinput">Password</label>
                                        <div class="controls">
                                            <input type="password" name="passw" id="password" placeholder="Password" class="span8" onchange="Validatepass(this)" required="required"> <span style="color: red">*</span>
                                            <label class="errortext" style="display:nne; color:red" id="psw_1"></label>
                                        </div><br>

                                        <label class="control-label" for="basicinput">Confirm Password</label>
                                        <div class="controls">
                                            <input type="password" name="confirm" id="confirm" placeholder="Retype Password" class="span8" onchange="confirm_password(this)" required="required"><span style="color: red">*</span>
                                            <label class="errortext" style="display:nne; color:red" id="psw_2"></label>
                                        </div><br>
                                        <script>
                                              function Validatepass(input)
                                              {
                                                   var pass = document.getElementById('password');
                                                     var filter = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
                                                     if (!filter.test(pass.value)) {
                                                      pass.value="";
                                                      $("#psw_1").html('Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters ').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('password').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                              function confirm_password(input)
                                              {
                                                  var pas = document.getElementById('password').value;
                                                  var cpas = document.getElementById('confirm').value;
                                                  if (pas!=cpas)
                                                  {
                                                  $("#psw_2").html('Password Miss Match..!').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('confirm').focus();
                                                      return false;
                                                  }
                                                  
                                                  if (pas==cpas)
                                                  {
                                                  
                                                  input.style.borderColor = "#2ecc71";
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  
                                                  return true;
                                              }
                                              </script>
                                    </div>    
                                        
                            </div> <!--mark-->
                          <input type="submit" name="submit" value="Submit" class="btn btn-success pull-right"> 
                        </div><!--ctrl-group-->

                    </form>
                </div><!--media-->
              </div><!--module body-->
                    		</div>   <!--module-->
                		</div>    <!--content-->
                    </div>   <!--span 9-->
                </div>
            </div>
            <!--/.container-->
        </div><!--/.wrapper-->

	<div class="footer">
		<div class="container">
			 
<b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
		</div>
	</div>

<?php
    include 'connection.php';
    include 'sweetalerttest.php';
    if(isset($_POST['submit'])){
    	$name=$_POST['name'];
    	$department=$_POST['department'];
    	$mobile=$_POST['mobile'];
    	$alt_mob=$_POST['alt_mob'];
    	if(empty($alt_mob)){
    		$alt_mob=" ";
    	}
    	$email=$_POST['email'];
    	$alt_email=$_POST['alt_email'];
    	if(empty($alt_email)){
    		$alt_email=" ";
    	}
    	$passw=md5($_POST['passw']);
    	
    	$designation="Placement officer";
    	$status=1;
    	$psw=0;
    	$qry="INSERT into login(user_type,email,password,status,psw) values('$designation','$email','$passw','$status','$psw')";

		if ($conn->query($qry) === TRUE) 
    	{
    		$sel="select login_id from login where email='$email' and password='$passw'";
        	$result=mysqli_query($conn,$sel);
             if(mysqli_num_rows($result) > 0){
             		 $row = mysqli_fetch_array($result);
             			$login=$row['login_id'];
            }
	    	$sql="INSERT into faculty (name,designation,dept,Mobile,Alt_Mob,Alt_Email,login_id,status) values('$name','$designation','$department','$mobile','$alt_mob','$alt_email','$login','$status')";
	    	if ($conn->query($sql) === TRUE) 
	    	{
	    		echo"<script>swal('New Admin Registered..','Successfully...','success')</script>";
	    		header("location:admin_home.php");

			} else {
	    		echo "Error: " . $sql . "<br>" . $conn->error;
	    		echo"<script>swal('Sorry..','Something went Wrong..Try Again later...','error')</script>";
			}
		} else {
    		echo "Error: " . $qry . "<br>" . $conn->error;
    		echo"<script>swal('Sorry..','Something went Wrong..Try Again later...','error')</script>";
		}
    }
?>
	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('.table-message tbody tr').click(
				function() 
				{
					$(this).toggleClass('resolved');
				}
			);
		} );
	</script>
</body>