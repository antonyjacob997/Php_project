<ul class="widget widget-menu unstyled" >
                                <li><a href="admin_home.php"><i class="menu-icon icon-dashboard"></i>Dashboard
                                </a></li>
                                <li><a href="view_payment.php"><i class="menu-icon fa fa-rupee"></i>Caution Deposit</a>
                                </li>
                                <li><a href="message.php"><i class="menu-icon icon-inbox"></i>Notification </a></li>
                                <li><a href="task.php"><i class="menu-icon fa fa-plus"></i> Add Titles </a></li>
                            </ul>
                            

                        <ul class="widget widget-menu unstyled">
                            <li>
                                <a class="collapsed" data-toggle="collapse" href="#togglePages">
                                    <i class="menu-icon icon-cog"></i>
                                    <i class="icon-chevron-down pull-right"></i><i class="icon-chevron-up pull-right"></i>
                                    Student Details
                                </a>
                                <ul id="togglePages" class="collapse unstyled">
                                    <li>
                                        <a href="search.php">
                                            <i class="icon-inbox"></i>
                                            View Student
                                        </a>
                                    </li>
                                    <li>
                                        <a href="view_uploads.php">
                                            <i class="icon-inbox"></i>
                                            View Student Uploads
                                        </a>
                                    </li>
                                    <li>
                                        <a href="placed.php">
                                            <i class="menu-icon fa fa-star"></i>
                                            Placed Students
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            
                            <li>
                                <a href="view_feedback.php">
                                    <i class="menu-icon icon-signout"></i>
                                    View Placement Feedback
                                </a>
                            </li>
                        </ul>
                        <ul class="widget widget-menu unstyled">
                                <li><a href="companies.php"><i class="menu-icon fa fa-institution"></i> Recruiters </a></li>
                               
                                <li><a href="admin_rules.php"><i class="menu-icon icon-book"></i>Rules</a></li>
                                <li><a href="filter.php"><i class="menu-icon icon-table"></i>Filter Student data </a></li>
                                <li><a href="report.php"><i class="menu-icon icon-bar-chart"></i>Placement Records</a></li>
                            </ul>