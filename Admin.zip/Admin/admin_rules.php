<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
   <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
   <script src="js/3dslider.js"></script>

    <link rel="stylesheet" type="text/css" href="sweetalert.css">
    <script type="text/javascript" src="sweetalert.js"></script>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>
<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->
	<div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>

					</div><!--/.sidebar-->
				</div><!--/.span3-->
<?php

include 'connection.php';
$sql = "SELECT * FROM rules where status=1";
$result = mysqli_query($conn, $sql);
$row=mysqli_fetch_array($result);
$rule_id=$row['rule_id'];
?>

				<div class="span9" >
					<div class="content">
						<div class="module message">
							<div class="module-head">
								<h3>Rules</h3>
							</div>

                    <form class="form-horizontal row-fluid" method="POST" enctype="multipart/form-data">
							<div class="module-option clearfix">
								<br>
								<div class="control-group"><br>
                                    <label class="control-label" for="basicinput">Rules</label>
                                        <div class="controls">
                                          

                                            <a href="../User/rules/<?php echo $row['doc']; ?>" target="_blank"><img src="images/download.png" width="50px" height="50px"></a>  
                                       <input type="submit"  style="float: right" name="submit" value="Update Rules" class="btn btn-primary">
                                            <input placeholder="New Rules" required type="file" style="float: right;margin-right: 15%" name="rules" id="rules" onchange="fileCheck1(this)">
                                            
    										 <p id="op1" style="float: right;margin-right: 38%;color: red" name="rules" ></p>
    									
                                          </div>                                          
                                        
                                        <br>
								</div>
<script type="text/javascript">
      function fileCheck1(obj) {
              var fileExtension = ['pdf'];
              if ($.inArray($(obj).val().split('.').pop().toLowerCase(), fileExtension) == -1)
              {
                   $("#op1").html('Only .pdf formats are allowed..!').fadeIn().delay(2000).fadeOut();
              document.getElementById('rules').value="";
            
           
              return false;
            }
              else
              {
                  $("#op1").html("");
                return true;
              }
          
      }
</script>
								<div class="pull-right">
									
								</div>
							</div>
							 
							<div class="module-foot">
							</div>
						</div>
						
					</form>
					</div><!--/.btn-controls-->

				</div><!--/.content-->
			</div><!--/.row-->
			
		</div><!--/.container-->
	</div><!--/.wrapper-->

	<?php   
		if(isset($_POST['submit'])){
		
		$filename2=md5(date("Y/m/d")."-". date("h:i:sa"));
		$y=date("Y-m-d");
		
		$file2=$filename2.".pdf";
		move_uploaded_file($_FILES["rules"]["tmp_name"], "../User/rules/" . $file2);

		$qry="INSERT into rules(doc,date1,status)values('$file2','$y',1)";
					if ($conn->query($qry) === TRUE) 
		            {
		                
		                $sql="update rules set status=0 where rule_id=$rule_id";
		                $re=$conn->query($sql);
		                ?>
		                
		                <?php 
		                echo '<script>
    setTimeout(function() {
        swal({
            title: "Document Uploaded!",
            text: "successfully...!",
            type: "success"
        }, function() {
            window.location = "admin_rules.php";
        });
    }, 1000)
</script>';
		            } 
		            else{
		            ?>
		                <script type="text/javascript">
		                
		                swal('Document Uploaded!', 'Failed...!', 'error')
		                    </script>
		                <?php 
		        }
	}
	?>

	<div class="footer">
		<div class="container">
			 
<b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
		</div>
	</div>

	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>


</body>