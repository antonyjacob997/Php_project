
<?php 
session_start();
include 'connection.php';
	$p=1; 

			$notifid=$_SESSION["notifid"];
			$Branch1=$_SESSION["Branch"];
			$Branch = explode(',', $Branch1);
			$res=mysqli_query($conn,"SELECT Org from organization where org_id='$notifid'");
			$row1 = mysqli_fetch_array($res);

	$fname=$row1['Org'];
	header("content-type:application/vnd.ms-excel");
	header("content-Disposition:attachment;filename=".$fname.".xls");
	
	$len=count($Branch);
				?>
				
					<table>
							<thead style=" background-color: #cbd1cc;">
								<tr><td colspan="<?php echo $len ?>" style="text-align: center;font-size: 24px; font-family: 'Times New Roman', Times, serif;"><b><?php echo"Students Register for ".$fname." Recruitment Drive" ?></b></td></tr>
								<tr>
								<?php
							   	$i=1;

								   	foreach($Branch as $values)
									  {
									  	$arr[$i]=$values;
									  	
									    ?>
									    <td style="text-align: center;font-size: 16px; font-family: 'Times New Roman', Times, serif;"><b><?php echo $arr[$i]; ?></td>
									    <?php
									    
									    $i=$i+1;
									  }
									
							   ?></tr>
							</thead>

							<tbody>
						<?php  
							$sql = "SELECT * FROM stud_list where stud_id in(SELECT stud_id from drive_reg where org_id='$notifid')";
							if ($result1 = $conn -> query($sql)){ 
								while($row=mysqli_fetch_array($result1)){
							?>
							
								<tr>
									
									<?php
									$i=0;
								   	foreach($Branch as $values)
									  {
									  	$arr[$i]=$values;
									  	if($arr[$i]=="Department"){
									  		$arr[$i]="department_name";
									  	}
									  	if($arr[$i]=="State"){
									  		$arr[$i]="state_name";
									  	}
									  	if($arr[$i]=="District"){
									  		$arr[$i]="dist_name";
									  	}
									  	if($arr[$i]=="Country"){
									  		$arr[$i]="country_name";
									  	}
									  	if($arr[$i]=="Email"){
									  		$arr[$i]="email";
									  	}
									    ?>
									    <th style="text-align: left;font-size: 14px; font-family: 'Times New Roman', Times, serif;"><?php echo $row[$arr[$i]]; ?></th>
									    <?php
									    
									    $i=$i+1;

									  }
									?>
								</tr>
							<?php  }
							} 
							?>
							</tbody>
						</table>

					