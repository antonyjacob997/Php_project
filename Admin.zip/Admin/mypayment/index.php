<?php
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width-device-width">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
    <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
	<style>
		.razorpay-payment-button{
			color: #ffffff !important;
			background-color: #B52E31;
			border-color: #B52E31;
			font-size: 14px;
			padding: 10px;
		}
	</style>
</head>
<body>
	<form action="" method="post">
<button id="rzp-button1" class="razorpay-payment-button">Pay</button>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var options = {
    "key": "<?php echo $razor_api_key; ?>", // Enter the Key ID generated from the Dashboard
    "amount": "50000", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Cam-RA",
    "description": "Caution Deposit",
    "image": "https://example.com/your_logo",
   
    "handler": function (response){
        alert(response.razorpay_payment_id);
        // alert(response.razorpay_order_id);
        var pay_id=response.razorpay_payment_id;
        var stud_id='4';
        $.ajax({
                type:'POST',
                url:'insert_payment.php',
                data:{ pay_id: pay_id,stud_id: stud_id },
                success:function (html) {
                    // $('#depart').html(html);
                    alert("success");
                }
            }); 
        // alert(response.razorpay_signature)
        
    },
    "prefill": {
        "name": "Gaurav Kumar",
        "email": "gaurav.kumar@example.com",
        "contact": "9999999999"
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#324aa8"
    }
};
var rzp1 = new Razorpay(options);
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>
	</form>

</body>
</html>