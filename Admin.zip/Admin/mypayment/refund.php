<?php
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width-device-width">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
    <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
	<style>
		.razorpay-payment-button{
			color: #ffffff !important;
			background-color: #B52E31;
			border-color: #B52E31;
			font-size: 14px;
			padding: 10px;
		}
	</style>
</head>
<body>
	<form action="" method="post">
<button id="rzp-button1" class="razorpay-payment-button">Refund</button>
<script>
    {
  "id":"rfnd_5UXHCzSiC02RBz",
  "entity":"refund",
  "speed":"optimum",
  "amount":10000,
  "currency":"INR",
  "payment_id":"pay_EbtqhGAmNZHwCN",
  "notes":[],
  "receipt":null,
  "acquirer_data":{
    "rrn":"918113090878"
  },
  // "created_at":1462887226,
  "status": "processed",
  "speed_processed":"instant",
  "speed_requested":"optimum"
}
</script>

<?php


// $payment = $api->payment->fetch('pay_DgExayLn3RBbZX');
// // $refund = $payment->refund();  full refund

// $refund = $payment->refund(array('amount' => 20000)); 
// // for partial refund

?>
	</form>

</body>
</html>