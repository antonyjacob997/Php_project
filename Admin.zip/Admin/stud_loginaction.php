<?php
	
session_start();

	$user=trim($_POST['email']);
	$pass=md5(trim($_POST['password']));


	include 'connection.php';
	$sql="select login_id,user_type,status,psw from login where email='$user' and password='$pass'";

	$result=mysqli_query($conn,$sql);

		if(mysqli_num_rows($result)>0)
		{
			$row = mysqli_fetch_array($result);
     		$type=$row['user_type'];
     		$status=$row['status'];
     		$psw=$row['psw'];
     		$id=$row['login_id'];
				if($type==="Student" && $status==="1"){
					$_SESSION["loggedin"] = "$id";
					if($psw===1){
						?><script >window.location='../User/resetpsw.php'</script>
						<?php
						
					}
					else{
						?><script >window.location='../User/personal.php'</script>
						<?php
					}
				}
				elseif ($type==="Placement officer") {
					$_SESSION["loggedin"] = "$id";
					
					?><script >window.location='admin_home.php'</script>
					<?php
				}
				elseif($status==="2")
				{
					$_SESSION["loggedin"] = "$id";
					
					?><script >window.location='admin_home.php'</script>
					<?php
				}
				else{
						$message = "Your account is blocked please contact placement officer...";
	        			echo "<script>alert('$message');
						window.location='index.php'</script>";
				}
	    }
	else
	{
		$message = "Incorrect username or password...";
        

        
        echo "<script>
      var myWindow = window.open('', 'MsgWindow', 'width=500,height=100');
        myWindow.document.write('<p>Incorrect username or password...</p>');

setTimeout(function(){
       myWindow.close(); 
    }, 3000);

    window.location='index.php'
      </script>";
	}

 ?>