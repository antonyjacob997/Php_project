<!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cam-RA</title>
    <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
    <link type="text/css" href="css/theme.css" rel="stylesheet">
    <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
    <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
  <!--  <script type="text/javascript" src="myscript.js"></script>  -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
  <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script type="text/javascript">
    $(document).ready(function(){

        $('#org').on('change',function() {
        var org1=$(this).val();
        if(org1){
            $.ajax({
                type:'POST',
                url:'getdata.php',
                data:'org_id='+org1,
                success:function (response) {
                    $('#de').html(response);
                }
            });          
        }
        else{
            $('#de').val("Not Registered");
        }
      });
    });
</script>

<body>

<?php   
include 'connection.php';
include 'sweetalerttest.php';
session_start();
if(isset($_GET['stid'])){
  $stid=$_GET['stid'];
}
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";
 
                
                    $sql="SELECT * from stud_list where stud_id=$stid";
                    $result=mysqli_query($conn,$sql);
                    if(mysqli_num_rows($result) > 0){
                        $i=0;
                        $row2 = mysqli_fetch_array($result);
                    }
}
?>
<body>
        <div class="navbar navbar-fixed-top" >
            <div class="navbar-inner" style="background-color: #25274D; height:80px">
                <div class="container" >
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a><a class="brand" href="index.php">Cam-RA </a>
                    <div class="nav-collapse collapse navbar-inverse-collapse">
                        <ul class="nav nav-icons">
                            <li><a href="#"><i class="icon-envelope"></i></a></li>
                            <li><a href="#"><i class="icon-eye-open"></i></a></li>
                            <li><a href="#"><i class="icon-bar-chart"></i></a></li>
                        </ul>
                        <!-- <form class="navbar-search pull-left input-append" action="#">
                        <input type="text" class="span3">
                        <button class="btn" type="button">
                            <i class="icon-search"></i>
                        </button>
                        </form> -->
                        <ul class="nav pull-right">
                          
                            <li><a href="#"><?php echo $name ?> </a></li>  
                            <li class="nav-user dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                               <!-- <img src="images/user.png" class="nav-avatar" />-->
                                <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="#">Your Profile</a></li>
                                    <li><a href="#">Edit Profile</a></li>
                                    <li><a href="#">Account Settings</a></li>
                                    <li class="divider"></li>
                                    <li><a href="Logout.php">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>
        <!-- /navbar -->
  <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                            <!--/.widget-nav-->

          </div><!--/.sidebar-->
        </div><!--/.span3-->
                    
                <div class="span9">
                    <div class="content">

                        <div class="module">
                            <div class="module-head">
                                <h3>Mark Placed Student</h3>
                            </div>
                            <div class="module-body">
                                <div class="stream-composer media">
                                    
                    <form class="form-horizontal row-fluid" method="POST">
                      <div class="control-group" id="dept">
                          <label class="control-label">Name</label>
                              <div class="controls">
                                  <input type="text" class="span8" readonly name="sname" value="<?php echo $row2['Full_Name'] ?>"> 
                              </div><br>
                      <?php 
                          $cr=$row2['course'];
                          if($cr=="1"){
                             $course="Btech";
                          }
                          else if($cr=="2"){
                             $course="MCA";
                          }
                          else{
                            $course="Mtech";
                           }
                      ?>
                      <div class="control-group" id="dept">
                          <label class="control-label">Course</label>
                              <div class="controls">
                                  <input type="text" class="span8" readonly name="course" value="<?php echo $course; ?>"> 
                              </div><br>
                      
                      <div class="control-group" id="dept">
                          <label class="control-label">Departments</label>
                              <div class="controls">
                                    <input type="text" class="span8" readonly name="dept" value="<?php echo $row2['department_name'] ?>">               
                              </div>
                      </div><br>
                    <input type="text" id="ppp" style="display: none;" name="yop" value="<?php echo $row2['year_of_pass'] ?>">    
                        <div class="control-group">
                            <label class="control-label" for="basicinput">Company</label>
                                <div class="controls">
                                    <select name="Organization" id="org"  data-placeholder="Select here.." class="span8" required="required">
                                        <option value="">Select here..</option>
                            <?php 
                                $sql="SELECT org_id,Org from organization where org_id in(SELECT org_id from notification where notif_id in( SELECT notif_id from drive_reg where stud_id=$stid) )";
                                echo "$sql";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['org_id'] ?>"><?php echo $row['Org']; ?></option>
                                            <?php }
                                     }  ?>  
                                    </select>
                                            </div><br>
                                        <div class="control-group" id="mark">
                                          
                                          <label class="control-label" for="basicinput">Designation</label>
                                            <div class="controls" id="de">
                                              <input type="text" id="desig" name="desig" class="span8">
                                            </div><br>
                                            <div class="controls">
                                                  <input type="submit" name="submit" value="Mark" style="width: 15%">
                                            </div><br>
                                        
                                        </div>
                                         
                                </form>
                                    </div>
                                </div>
                          </div>
                        </div>
</div>
<?php
   if(isset($_POST['submit'])){
   
   $name=$_POST['sname'];
   $course=$_POST['course'];
   $department=$_POST['dept'];
   $company=$_POST['Organization'];
   $desig=$_POST['desig'];
   $yop=$_POST['yop'];
   $status=1;
    $res5=mysqli_query($conn,"INSERT into placed(stud_id,Name,Course,Department,Company,Designation,YOP,status)values($stid,'$name','$course','$department','$company','$desig','$yop',$status)");
    $res6=mysqli_query($conn,"UPDATE stud set placed=1 where stud_id=$stid");
    if($res5){
    ?>
    <script>swal('Marked placed student', 'successfully..!', 'success');</script>
    <?php
  }
 }

?>
                        </div><!--/.module-->
                        
                    </div><!--/.content-->
                </div><!--/.span9-->
            </div>
        </div><!--/.container-->
    </div><!--/.wrapper-->

    <div class="footer">
        <div class="container">
             

            <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
        </div>
    </div>

    <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>
