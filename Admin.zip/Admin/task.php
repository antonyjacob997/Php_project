<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>

	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="myscript.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script>
        $(document).ready(function(){
             var response="";
             $("#addnew").hide();    //add button
             $("#filter").on('change',function()
             {
                var opt=$(this).val();
                if(opt=="Others"){             //add new
                   
                        $("#dept").show();             //add new company name
                   
                        $("#addnew").show();
                        $("#delete").hide();

                } 
                else{                           //display old
                    $("#dept").hide();
                    $("#addnew").hide();
                    $("#delete").show();

                      
                }
            });
            $("#filter1").on('change',function(){
                var opt=$(this).val();
                if(opt=="Others"){             //add new
                   
                        $("#dept1").show();             //add new company name
                   
                        $("#addnew1").show();
                        $("#delete1").hide();

                } 
                else{                           //display old
                    $("#dept1").hide();
                    $("#addnew1").hide();
                    $("#delete1").show();

                      
                }
            });
        });
</script>
</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>	

<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->
	<div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
					
					</div><!--/.sidebar-->
				</div><!--/.span3-->


				<div class="span9">
					<div class="content">

						<div class="module message">
							

                    <form class="form-horizontal row-fluid" method="POST">
							
							<div class="module-head">
								<h3>New Department</h3>
							</div>
							<div class="module-option clearfix">
                                <div class="control-group"><br><br><br>
                            <label class="control-label" for="basicinput">Department</label>
                                <div class="controls">
                                    <select name="Organ" id="filter" data-placeholder="Select here.." class="span8" required="required">
                                                    <option value="">Select here..</option>
                                                    <option value="Others">----------------------------------------   Add New   --------------------------------------------</option>

                            <?php 
                                $sql="SELECT * FROM department where chk=1 and status=1";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['dept_id'] ?>"><?php echo $row['department_name']; ?></option>
                                            <?php }
                                     }  ?>  
                                     
                                    </select>
                                    <input class="btn btn-primary" id="delete" style="margin-left: 10%;width: 125px" type="submit"  name="submit" value="Delete">
                                    <div id="dept" style="display:none;"><br>
                                       <input type="text" placeholder="Department Name" name="Department" class="span8" id="oth" onchange="Validatename3(this)"  autocomplete="of">
                                       <input class="btn btn-primary" id="addnew" style="margin-left: 10%;width: 125px" type="submit"  name="submit1" value="Add Department">
                                       <label class="errortext" style="display:none; color:red" id="name_2"></label><br>
                                    </div>  
                                    <script>
                                        function Validatename3(input)
                                            {
                                                  var val = document.getElementById('oth').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "()]{2,}$/))
                                                  {
                                                      $("#name_2").html('Min. 3 and Only Alphabets and parentheses Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('oth').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('oth').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>     
                                
                                
                            </div><br>
                            </div><br>
								
							</div>
                        </form>
                        <form class="form-horizontal row-fluid" method="POST">
							 <div class="module-head">
								<h3>New upload Fields</h3>
							</div>
							<div class="module-option clearfix">
								<br><br>
								<div class="control-group"><br>
                                    <label class="control-label" for="basicinput">Title</label>
                                        <div class="controls">
                                            <select name="Organ1" id="filter1" data-placeholder="Select here.." class="span8" required="required">
                                                    <option value="">Select here..</option>
                                                    <option value="Others">----------------------------------------   Add New   --------------------------------------------</option>

                            <?php 
                                $sql="SELECT * FROM upload_title where status=1";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['title_id'] ?>"><?php echo $row['title']; ?></option>
                                            <?php }
                                     }  ?>  
                                     
                                    </select>
                                    <input class="btn btn-primary" id="delete1" style="margin-left: 10%;width: 125px" type="submit"  name="delete1" value="Delete">
                                    <div id="dept1" style="display:none;"><br>
                                       <input type="text" placeholder="Title Name" name="title11" class="span8" id="oth1" onchange="Validatename3(this)"  autocomplete="of">
                                       <input class="btn btn-primary" id="addnew1" style="margin-left: 10%;width: 125px" type="submit"  name="submit5" value="Add Title">
                                       <label class="errortext" style="display:none; color:red" id="name_5"></label><br>
                                    </div>  
                                        </div><br><br>
								</div>
								
							</div> 
							
                                <div class="controls">
                                    
                                    
                                    <script>
                                        function Validatename3(input)
                                            {
                                                  var val = document.getElementById('oth1').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "()]{2,}$/))
                                                  {
                                                      $("#name_5").html('Min. 3 and Only Alphabets and parentheses Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('oth1').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('oth1').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>     
                                
                                
                            </div><br>
                            </div><br>
                                
                            </div>
							</div>
                        </form>
						</div>
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->

	<div class="footer">
		<div class="container">
			 
<b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
		</div>
	</div>

<?php
    include 'connection.php';
    include 'sweetalerttest.php';
    if(isset($_POST['submit1'])){
        $dept=$_POST['Department'];
        if($dept==""){
            echo"<script>swal('Oops..','Fields are empty','warning')</script>";   
        }else{
            $sel="SELECT department_name from department where department_name='$dept'";
            $result=mysqli_query($conn,$sel);
            if(mysqli_num_rows($result) > 0){
                echo"<script>";
                echo "swal('Oops...','Department already exist..!','error');";
                echo"</script>";
            }
            else{
                    $sql="INSERT into department(department_name,chk,status) values ('$dept',1,1)";
                    if ($conn->query($sql) === TRUE) 
                    {
                         echo '<script>
                            setTimeout(function() {
                                swal({
                                    title: "Department Added !",
                                    text: "Successfully!",
                                    type: "success"
                                }, function() {
                                    window.location = "admin_home.php";
                                });
                            }, 1000);
                        </script>';
                                                
                            
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }
            }
    }
    if(isset($_POST['submit'])){
        $dept=$_POST['Organ'];
        $sql="UPDATE department set status=0 where dept_id=$dept";
        $resu=mysqli_query($conn,$sql);
        if($resu){
        echo '<script>
            setTimeout(function() {
                swal({
                    title: "Department Deleted !",
                    text: "Successfully!",
                    type: "success"
                }, function() {
                    window.location = "task.php";
                });
            }, 1000);
        </script>';
     // echo"<script>alert('uigiug')</script>"; 
        }
    }
    if(isset($_POST['submit5'])){
        $tit=$_POST['title11'];
        if($tit==""){
            echo"<script>swal('Oops..','Fields are empty','warning')</script>";   
        }else{
            $sel="SELECT title from upload_title where title='$tit'";
            $result=mysqli_query($conn,$sel);
            if(mysqli_num_rows($result) > 0){
                echo"<script>";
                echo "swal('Oops...','Title already exist..!','error');";
                echo"</script>";
            }
            else{
                    $sql="INSERT into upload_title(title,status) values ('$tit',1)";
                    if ($conn->query($sql) === TRUE) 
                    {
                         echo '<script>
                            setTimeout(function() {
                                swal({
                                    title: "Upload Title Added !",
                                    text: "Successfully!",
                                    type: "success"
                                }, function() {
                                    window.location = "admin_home.php";
                                });
                            }, 1000);
                        </script>';
                                                
                            
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }
            }
    }
    if(isset($_POST['delete1'])){
        $title_id=$_POST['Organ1'];
        $sql="UPDATE upload_title set status=0 where title_id=$title_id";
        $resu=mysqli_query($conn,$sql);
        if($resu){
        echo '<script>
            setTimeout(function() {
                swal({
                    title: "Upload Title Deleted !",
                    text: "Successfully!",
                    type: "success"
                }, function() {
                    window.location = "task.php";
                });
            }, 1000);
        </script>';
     // echo"<script>alert('uigiug')</script>"; 
        }
    }
?>


	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('.table-message tbody tr').click(
				function() 
				{
					$(this).toggleClass('resolved');
				}
			);
		} );
	</script>
</body>