<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cam-RA</title>
        <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="css/theme.css" rel="stylesheet">
        <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
            rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .big{   width:2000px;    }
            .med{   width:500px;    }
            .sml{   width:50px;     }
        </style>
        
    </head>
    <body>
       <?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";
    $today = date("Y-m-d");
    // echo "<br>" . $date1 . "<br>";
    $qy="SELECT date1,notif_id from notification";
    $result=mysqli_query($conn,$qy);
    $f=0;
    if(mysqli_num_rows($result)>0)
        {
        while($row = $result->fetch_assoc()) { 
        $da=$row['date1'];
        if ($da < $today) 
            $f=$row['notif_id'];

          
    if($f!=0){
         $qry2="UPDATE notification set status = 0 where notif_id=$f";
         $res=mysqli_query($conn,$qry2);
       }
    }
  }
}
?>
<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->
 <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->
                    <div class="span9" style="width: 70%">
                        <div class="content">
                            <div class="module-head">
                                    <h3>
                                        Message</h3>
                                        <span style="margin-left: 90%"><a href="create_notif.php" class="btn btn-primary">Compose</a></span>
                                    
                                </div>

                            <div class="module message" style="overflow-x:auto;overflow-y:auto;">
                                
                                <div class="module-option clearfix">
                          <!--          <div class="pull-left">
                                        <div class="btn-group">
                                            <button class="btn">
                                                Inbox</button>
                                            <button class="btn dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a href="#">Inbox(11)</a></li>
                                                <li><a href="#">Sent</a></li>
                                                <li><a href="#">Draft(2)</a></li>
                                                <li><a href="#">Trash</a></li>
                                                <li class="divider"></li>
                                                <li><a href="#">Settings</a></li>
                                            </ul>
                                        </div>
                                    </div>   -->
                                    
                                </div>
                                <div class="module-body table">
                                    <table class="table table-message " style="width:2000px">
                                        <thead>
                                            <tr class="heading" style=";background-color:#cbd1cc">
                                                <td>
                                                	Sl.No
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    Organization
                                                </td>
                                                <td class="cell-title big" >
                                                   Eligible Branches
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet sml">
                                                    Tenth
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet sml">
                                                    Plus two
                                                </td>
                                                
                                                <td class="cell-time align-right sml">
                                                    Degree
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet sml">
                                                    Backlogs
                                                </td>
                                                <td class="cell-title med">
                                                    Other Criteria
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    Date of Registration
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    Date of Recruitment
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet med">
                                                    Venue
                                                </td>
                                                
                                                <td class="cell-time align-right med">
                                                    Designation
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet sml">
                                                    CTC
                                                </td>
                                                <td class="cell-title med">
                                                    Rounds
                                                </td>
                                                <td>
                                                	Edit
                                                </td>
                                                <td>
                                                	Delete
                                                </td>
                                                
                                            </tr>
                                        </thead>
                <?php
    $sql="SELECT Org,notif_id, elig_branch, tenth, plus_two, degree, backlog, other_criteria, date1,date2, venue, venue2, designation, ctc, rounds
FROM notification, organization
WHERE Org
IN (
SELECT Org
FROM organization
WHERE organization.org_id = notification.org_id)
AND notification.status=1";
    $result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    $b=0;
    while($row = $result->fetch_assoc()) { $notif_id=$row['notif_id']; $b=$b+1; ?>
                                        <tbody>
                                            <tr class="read">
                                                
                                                <td><?php echo $b; ?></td>
                                                <td class="cell-icon hidden-phone hidden-tablet">
                                                    <?php echo  $row["Org"];?>
                                                </td>
                                                <td class="cell-icon hidden-phone hidden-tablet">
                                                    <?php echo  $row["elig_branch"];?>
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    <?php echo  $row["tenth"];?>
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    <?php echo  $row["plus_two"];?>
                                                </td>
                                                <td class="cell-time align-right">
                                                    <?php echo  $row["degree"];?>
                                                </td>
                                                <td class="cell-icon hidden-phone hidden-tablet">
                                                    <?php echo  $row["backlog"];?>
                                                </td>
                                                <td class="cell-icon hidden-phone hidden-tablet">
                                                    <?php echo  $row["other_criteria"];?>
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    <?php echo  $row["date1"];?>
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    <?php echo  $row["date2"];?>
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    <?php echo  $row["venue"];?>
                                                </td>
                                                <td class="cell-time align-right">
                                                    <?php echo  $row["designation"];?>
                                                </td>
                                                <td class="cell-author hidden-phone hidden-tablet">
                                                    <?php echo  $row["ctc"];?>
                                                </td>
                                                <td class="cell-time align-right">
                                                    <?php echo  $row["rounds"];?>
                                                </td>
                                                <td class="center">
				                           			 <a href="edit_notif.php?notif_id=<?php echo $notif_id;?>"><i class="menu-icon fa fa-edit" style='font-size:24px'></i></a>
				                       			 </td>
                                                <td><a href='delete_notif.php?notif_id=<?php echo $notif_id; ?>' ><i class='fa fa-trash' style='font-size:24px'></i></a></td>
                                            </tr>
                                        </tbody>
            <?php 
        }
   } else {
        ?>
            <tbody>
                <tr><td colspan="6">No Messages to Show</td></tr>
            </tbody>
        <?php
   }
?>
                                    </table>
                                </div>
                                <div class="module-foot">
                                </div>
                            </div>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
        <div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>
        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    </body>
