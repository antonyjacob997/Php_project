<?php
include 'connection.php';
	$result_id=$_GET['result_id'];
	$sql="UPDATE result set status=0 where result_id=$result_id";
	$res=mysqli_query($conn,$sql);
	header("location:placed.php");
?>
<script>
	window.location('placed.php');
</script>