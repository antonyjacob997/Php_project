<?php
	include 'connection.php';
	$notif_id=$_GET['notif_id'];
	$sql="UPDATE notification set status=0 where notif_id=$notif_id";
	$res=mysqli_query($conn,$sql);
	header("location:message.php");
?>
<script>
	window.location('message.php');
</script>