<?php
include 'connection.php';
  if(!empty($_POST['org_id'])){
    $c=$_POST['org_id'];
   
    $qry="SELECT * from organization where org_id='$c'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result) > 0){
       $row = mysqli_fetch_array($result);
       
       $description=$row['description'];
       $tagline=$row['captions'];
       $name=$row['name'];
        $email=$row['email'];
        $phone=$row['phone'];
        if(empty($name)){
         $name="No name Entered";
       }
       if(empty($email)){
         $email="No email Id Added";
       }
       if(empty($phone)){
         $phone="No phone Number Added";
       }
       if(empty($description)){
         $description="No description";
       }
       if(empty($tagline)){
         $tagline="No tagline";
       }
       $imgname="images/".$row['img_name'];

       echo '<label class="control-label" for="basicinput">Tagline</label>
                                <div class="controls">
                                    <input type="text" placeholder="Tagline" name="Tagline" class="span8" id="Tagline" value="'.$tagline.'">                                         
                                </div><br>
       <label class="control-label" for="basicinput">Description</label>
                <div class="controls">
                    <textarea name="Description" id="Description"  placeholder="Description" autocomplete="off" class="span8">'.$description.'</textarea>                                         
                </div><br><br>

                <div id="myimg">
                            <label class="control-label" for="basicinput">Image</label>   
                                <div class="controls">
                                    <input type="file" name="c_image" id="c_image" onchange="fileCheck1(this)">
                                    <p id="op1" style="float: right;margin-right: 35%;color: red" name="rules" id="rules" onchange="fileCheck1(this)"></p>                                               
                                </div><br><br>  
                        </div>';

              echo'<div style="margin-left: 21%">
                    <img src="'.$imgname.'" width="300px" height="300px" alt="No image uploaded">
              </div>';
              echo'</div>
                    </div>



      <div class="contact2">

          <div class="module-head">
                  <h3>Contact Details</h3>
                </div><br><br>
                    <label class="control-label" for="basicinput">Name</label>
                      <div class="controls">
                          <input type="text" placeholder="Name" name="name5" class="span8" id="name5" onchange="Validatename6(this)"  autocomplete="off" value="'.$name.'">
                                    <label class="errortext" style="display:none; color:red" id="name_6"></label>                                         
                                </div><br>
                                
                    <label class="control-label" for="basicinput">Email</label>
                      <div class="controls">
                                    <input type="text" placeholder="Email" name="email" class="span8" id="email" onchange="Validatename7(this)"  autocomplete="off" value="'.$email.'">
                                    <label class="errortext" style="display:none; color:red" id="email_1"></label>                                         
                                </div><br>
                                
                    <label class="control-label" for="basicinput">Phone No</label>
                      <div class="controls">
                          <input type="text" placeholder="Phone No" name="phone" class="span8" id="phone" onchange="Validatename8(this)"  autocomplete="off" value="'.$phone.'">
                              <label class="errortext" style="display:none; color:red" id="phone_1"></label>
                      </div><br>
                      <input class="btn btn-primary" id="update" style="margin-left: 70%" type="submit"  name="submit2" value="Update">
                      </div>';
    }
    else{
      echo '<input type="text" disabled id="desig" class="span8" value="sorry">';
    }
}
?>
