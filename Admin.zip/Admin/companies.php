<!DOCTYPE html>
<html lang="en">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cam-RA</title>
        <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="css/theme.css" rel="stylesheet">
        <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
    <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script>
		$(document).ready(function(){
             var response="";
             $("img").hide();
             $("#contact").hide();
             $("#addnew").hide();    //add button
			 $("#filter").on('change',function()
			 {
				var opt=$(this).val();
				if(opt=="Others"){             //add new

					    $("#dept").show();             //add new company name
              $("img").hide();
              $("#addnew").show();
              $("#delete").hide();
              $("#update").hide();
              $("#contact").hide();
              $("#display2").show();
              $("#c_image").show();
              $("#lbl").show();
              document.getElementById('Description').value="";
              document.getElementById('Tagline').value="";
              document.getElementById('name5').value="";
              document.getElementById('email').value="";
              document.getElementById('phone').value="";

				} 
				else{                           //display old
					$("#dept").hide();
                    $("#addnew").hide();
                    $("#delete").show();
                    $("#contact").hide();
                    $("#display2").hide();

					$.ajax({

                        type:'POST',
                        url:'getdata2.php',
                        data:'org_id='+opt,
                        success:function (response) {
                            $('#display').html(response);
                            $("#c_image").hide();
                            $("#lbl").hide();
                        }
                    });   
				}
			});
		});
</script>

</head>
    <body >
<?php   
include 'connection.php';
include 'sweetalerttest.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";
}
?>
  <div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->
        <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->
                    <div class="span9">
                        <div class="content">
                        	<div class="module message">
								<div class="module-head">
									<h3>Add Company</h3>
								</div>

                    <form class="form-horizontal row-fluid" method="POST" enctype="multipart/form-data">
							<div class="control-group"><br><br><br>
                            <label class="control-label" for="basicinput">Company</label>
                                <div class="controls">
                                    <select name="Organ" id="filter" data-placeholder="Select here.." class="span8" required="required">
                                                    <option value="">Select here..</option>
                                                    <option value="Others">----------------------------------------   Add New   --------------------------------------------</option>

                            <?php 
                                $sql="SELECT * FROM organization where status=1";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['org_id'] ?>"><?php echo $row['Org']; ?></option>
                                            <?php }
                                     }  ?>  
                                     
                                    </select>
                                    <input class="btn btn-primary" id="delete" style="margin-left: 10%" type="submit"  name="submit" value="Delete">
                                    <div id="dept" style="display:none;"><br>
                                       <input type="text" placeholder="Company Name" name="comp_nam" class="span8" id="oth" onchange="Validatename3(this)"  autocomplete="off">
                                       <label class="errortext" style="display:none; color:red" id="name_2"></label><br>
                                	</div>  
                                    <script>
                                        function Validatename3(input)
                                            {
                                                  var val = document.getElementById('oth').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_2").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('oth').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('oth').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>  	
                                </div>
                            </div><br>
                    <div id="display">
                        <div id="display2">
                            <label class="control-label" for="basicinput">Tagline</label>
                                <div class="controls">
                                    <input type="text" placeholder="Tagline" name="Tagline" class="span8" id="Tagline" onchange="Validatename4(this)"  autocomplete="of">
                                    <label class="errortext" style="display:none; color:red" id="name_3"></label><br>                                         
                                </div><br>
                                <script>
                                        function Validatename4(input)
                                            {
                                                  var val = document.getElementById('Tagline').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_3").html('Min. 3 and Only Alphabet Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('Tagline').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('Tagline').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>  
                            <label class="control-label" for="basicinput">Description</label>
                                <div class="controls">
                                    <textarea name="Description" id="Description" placeholder="Description" autocomplete="off" class="span8" onchange="Validatename5(this)" ></textarea>  
                                    <label class="errortext" style="display:none; color:red" id="name_4"></label><br>
                                    <script>
                                        function Validatename5(input)
                                            {
                                                  var val = document.getElementById('Description').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "," "-.]{2,}$/))
                                               
                                                  {
                                                      $("#name_4").html('Min. 3 and Alphabet, Hypen and Commas are Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('Description').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('Description').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>                                         
                                </div><br><br>
                            
                            <label class="control-label" id="lbl" for="basicinput">Image</label>   
                                <div class="controls">
                                    <input type="file" name="c_image" id="c_image" onchange="fileCheck1(this)">
                                    <p id="op1" style="float: right;margin-right: 35%;color: red" name="rules" id="rules" onchange="fileCheck1(this)"></p>                                               
                                </div><br><br>  
  <?php $imgname=""; ?>                          
                            <div style="margin-left: 21%" >
                                <img src="<?php echo $imgname ?>"  width="300px" height="300px" alt="select org">
                            </div>
                        </div>
                    </div>

    <script type="text/javascript">
      function fileCheck1(obj) {
              var fileExtension = ['jpg','png','jpeg'];
              if ($.inArray($(obj).val().split('.').pop().toLowerCase(), fileExtension) == -1)
              {
                   $("#op1").html('Only JPG,JPEG,PNG formats are allowed..!').fadeIn().delay(2000).fadeOut();
                     document.getElementById('c_image').value="";
            
           
              return false;
            }
              else
              {
                  $("#op1").html("");
                return true;
              }
          
      }
</script> 
<input class="btn btn-primary" id="addnew" style="margin-left: 70%" type="submit"  name="submit1" value="Add New">
         </form><br><br>
      <form class="form-horizontal row-fluid" method="post">
        <div id=contact>
          <div class="module-head">
                  <h3>Contact Details</h3>
                </div><br><br>
                    <label class="control-label" for="basicinput">Name</label>
                      <div class="controls">
                          <input type="text" placeholder="Name" name="name5" class="span8" id="name5" onchange="Validatename6(this)"  autocomplete="of">
                                    <label class="errortext" style="display:none; color:red" id="name_6"></label>                                         
                                </div><br>
                                <script>
                                        function Validatename6(input)
                                            {
                                                  var val = document.getElementById('name5').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_6").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('name5').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('name5').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;   
                                              }
                                              </script> 
                    <label class="control-label" for="basicinput">Email</label>
                      <div class="controls">
                                    <input type="text" placeholder="Email" name="email" class="span8" id="email" onchange="Validatename7(this)"  autocomplete="off">
                                    <label class="errortext" style="display:none; color:red" id="email_1"></label>                                         
                                </div><br>
                                <script>
                                        function Validatename7(input)
                                            {
                                                  var val = document.getElementById('email').value;
                                                  var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                                  if (!filter.test(val)) 
                                                  {
                                                      $("#email_1").html('Please provide a valid email..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('email').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('email').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>
                    <label class="control-label" for="basicinput">Phone No</label>
                      <div class="controls">
                          <input type="text" placeholder="Phone No" name="phone" class="span8" id="phone" onchange="Validatename8(this)"  autocomplete="off">
                              <label class="errortext" style="display:none; color:red" id="phone_1"></label>
                      </div><br>
                                <script>
                                        function Validatename8(input)
                                            {
                                                  var val = document.getElementById('phone').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                      $("#phone_1").html('Enter a Valid Mobile Number').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('phone').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('phone').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script> 


                    <input class="btn btn-primary" id="update" style="margin-left: 70%" type="submit"  name="submit2" value="Update">
             </div>    <!-- contact -->
         </form> <br><br><br>
							</div>  
								<!--module -->	 
                    	</div>
                    	<!--content  -->   	
                    </div>	
                    	<!--span9  -->

</div>                        
            </div>    
           		<!--/.container-->
        </div>   
        	<!--/.wrapper-->
        	
<?php
	if(isset($_POST['submit1'])){
    	  $new1=$_POST['comp_nam'];
        $desc=$_POST['Description'];
        $tagline=$_POST['Tagline'];
        $name=$_POST['name5'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
    if( (empty($name)) || (empty($email)) || (empty($phone))|| ($new1=="") || ($desc=="") || ($tagline=="")){
        echo"<script>swal('Oops..','Fields are empty','warning')</script>";
    } 
   
        else{

              $filename2=md5(date("Y/m/d")."-". date("h:i:sa"));
              $file2=$filename2.".jpg";        
              move_uploaded_file($_FILES["c_image"]["tmp_name"], "images/" . $file2);

          $sql1="INSERT into organization(Org,status,img_name,description,captions,name,email,phone)values('$new1',1,'$file2','$desc','$tagline','$name','$email','$phone')";

          	$resu=mysqli_query($conn,$sql1);
              if($resu){
          	echo '<script>
                setTimeout(function() {
                    swal({
                        title: "Organization Added !",
                        text: "Successfully!",
                        type: "success"
                    }, function() {
                        window.location = "companies.php";
                    });
                  }, 1000);
            </script>';}
        }
	}
?>
<?php
	if(isset($_POST['submit'])){
		$org=$_POST['Organ'];
		$sql="UPDATE organization set status=0 where org_id=$org";
		$resu=mysqli_query($conn,$sql);
        if($resu){
		echo '<script>
    setTimeout(function() {
        swal({
            title: "Organization Deleted !",
            text: "Successfully!",
            type: "success"
        }, function() {
            window.location = "companies.php";
        });
    }, 1000);
</script>';
	 // echo"<script>alert('uigiug')</script>";	
}
}

  if(isset($_POST['submit2'])){
    $org=$_POST['Organ'];
    $name=$_POST['name5'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    if( (empty($name)) || (empty($email)) || (empty($phone)) ){
        echo"<script>alert('Fields are Empty')</script>";
    }
    else{
      $sql2="UPDATE organization set name='$name',email='$email',phone='$phone' where org_id=$org";
      $res=mysqli_query($conn,$sql2);
      echo '<script>
    setTimeout(function() {
        swal({
            title: "Contact Updated !",
            text: "Successfully!",
            type: "success"
        }, function() {
            window.location = "companies.php";
        });
    }, 1000);
</script>';
    }
  }

?>
       <div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>
        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="scripts/common.js" type="text/javascript"></script>

    </body>