<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; char et=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <!--  <script type="text/javascript" src="myscript.js"></script>  -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
	<script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
  <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <script type="text/javascript">
		$(document).ready(function(){
			$("#search").on('change',function()
			{
				var opt=$(this).val();
				if(opt=="Gender"){
            		
					    $("#gend").show();
					    $("#sea").hide();
					    $("#field2").hide();
					   document.getElementById('gend').value="";				
				} else if(opt=="dept_id"){
						$("#gend").hide();						
					    $("#field2").show();
		             	$("#sea").hide();
		             	document.getElementById('dept_id').value="";
				}
				else {

						$("#gend").hide();						
					    $("#sea").show();
					    // $('#tit').show();
		             // $('#disp').hide();
		             	$("#field2").hide();
					 document.getElementById('sea').value="";  
				} 
				
			});
			// $("#filter").on('change',function(){

			// 	var s=$(this).val();
				
			// 	if(s==0){
			// 		alert(s);
			// 		document.getElementByTagName('Branch[]').checked=false;
			// 	}
			// });
		});
	</script>
	<style >
		td.hover{
			background-color: #aff0ba;
		}
		input.checkbox1{
			width: 25px;
			height: 25px;
		}
	</style>

</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>

<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->

	<div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                            <!--/.widget-nav-->

					</div><!--/.sidebar-->
				</div><!--/.span3-->


				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3 style="margin-left: 10%">Filter Student Data Fields</h3>
							</div><br>
							<h5 style="margin-left: 10%">Choose the required fields </h5>
							<div class="module-body">
							<form class="form-horizontal row-fluid" method="POST">  
                                <div class="control-group" id="comp" >
                                	<label class="control-label" for="basicinput">Company</label>
                                	<div class="controls">
                                	<select name="Organ" id="filter" data-placeholder="Select here.." class="span6" required="required">
                                                    <option value="0">Select here..</option>

                            <?php 
                                $sql="SELECT * FROM organization where status=1";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['org_id'] ?>"><?php echo $row['Org']; ?></option>
                                            <?php }
                                     }  ?>  
                                     
                                    </select><br><br>
                                    </div>
									<div style="margin-left: 10%">
										
                                        <table>
                                  
                                 <?php 
                                 //$notifid="<script>document.getElementById('filter').value;</script>";
                                 	
									
									// $sql = "SELECT University_Reg_No,department_name as Department,Mobile,Alt_Mobile,Alt_Email,DoB,Gender,Father_Name,Mother_Name,House_Name,Street,City,dist_name as District ,state_name as State ,Pincode,country_name as Country,email as Email,Aggrigate_CGPA,Aggrigate_Percentage,Current_Arrears,History_of_Arrears,Tenth_Percentage,Tenth_CGPA,Tenth_Year_of_pass,Tenth_Board,Tenth_School_Name,Tenth_state_of_School,Twelfth_Percentage,Twelfth_CGPA,Twelfth_Year_of_pass,Twelfth_Board,Twelfth_School_Name,Twelfth_state_of_School,UG_Course,UG_Percentage,UG_CGPA,UG_Year_of_pass,UG_College,state_of_UG,UG_University,PG_University,Technical_Skills,Work_Experience,Certifications,Internships FROM stud_list ";

									$sql = "SELECT University_Reg_No,department_name as Department,Mobile,Alt_Mobile,Alt_Email,DoB,Gender,Father_Name,Mother_Name,House_Name,Street,City,dist_name as District ,state_name as State ,Pincode,country_name as Country,email as Email,Aggrigate_CGPA,Aggrigate_Percentage,Current_Arrears,Tenth_Percentage,Tenth_CGPA,Tenth_Year_of_pass,Twelfth_Percentage,Twelfth_CGPA,Twelfth_Year_of_pass,UG_Course,UG_Percentage,UG_CGPA,UG_Year_of_pass,PG_University FROM stud_list ";
									
									if ($result = $conn -> query($sql)) {
										$i=1;
											echo "<td>";
											echo'<input type="checkbox" id="recr" class="checkbox1" name="Branch[]" required hidden value="Full_Name">Full_Name</td>';			  // Get field information for all fields
										while ($fieldinfo = $result -> fetch_field()) {
														    
											echo "<td>";
											if($i<3){
													           ?>
												<label class="checkbox">
                                                    <input type="checkbox" id="recr" name="Branch[]" value="<?php echo $fieldinfo -> name; ?>" class="checkbox1">
                                                    <?php echo $fieldinfo -> name; ?>
                                                </label>
												<?php
												$i=$i+1;
												echo"</td>";
											}
											else{
												 ?>
												<label class="checkbox">
                                                    <input type="checkbox" id="recr" class="checkbox1" name="Branch[]" value="<?php echo $fieldinfo -> name; ?>">
                                                    <?php echo $fieldinfo -> name; ?>
                                                </label>
												<?php
												$i=0;
												echo"</td></tr>";
											}
										}
										$result -> free_result();
									} ?>
												    </table>
                                            </div>
                                        </div>
                                        <input class="btn btn-small btn-info" type="submit" name="preview" value="Preview" style="float: right;margin-right: 10%"><br><br>
 				</form>
 				<form method="POST" action="excel_file.php">
 					<?php
	if(isset($_POST['preview'])){
		$p=0; 
		$notifid=$_POST['Organ'];
		$res=mysqli_query($conn,"SELECT Org from organization where org_id='$notifid'");
		$row1 = mysqli_fetch_array($res);
			$fname=$row1['Org'];
			$len=count($_POST['Branch']);
				?>
				<div style="overflow-x:auto;overflow-y:auto;">
					<table>
							<thead style=" background-color: #cbd1cc;">
								<tr><td colspan="<?php echo $len+1 ?>" style="text-align: center;font-size: 24px; font-family: 'Times New Roman', Times, serif;"><b><?php echo"Students Register for ".$fname." Recruitment Drive" ?></b></td></tr>
								<tr><td style="text-align: center;font-size: 16px; font-family: 'Times New Roman', Times, serif;"><b>Sl.No</td>
								<?php
							   	$i=1;

								   	foreach($_POST['Branch'] as $values)
									  {
									  	$arr[$i]=$values;
									  	
									    ?>
									    <td style="text-align: center;font-size: 16px; font-family: 'Times New Roman', Times, serif;"><b><?php echo $arr[$i]; ?></td>
									    <?php
									    
									    $i=$i+1;
									  }
									
							   ?></tr>
							</thead>

							<tbody>
						<?php  
							$sql = "SELECT * FROM stud_list where stud_id in(SELECT stud_id from drive_reg where org_id='$notifid')";
							if ($result1 = $conn -> query($sql)){ 
								while($row=mysqli_fetch_array($result1)){
							?>
							
								<tr>
									<td><?php echo $p=$p+1; ?></td>
									<?php
									$i=0;
								   	foreach($_POST['Branch'] as $values)
									  {
									  	$arr[$i]=$values;
									  	if($arr[$i]=="Department"){
									  		$arr[$i]="department_name";
									  	}
									  	if($arr[$i]=="State"){
									  		$arr[$i]="state_name";
									  	}
									  	if($arr[$i]=="District"){
									  		$arr[$i]="dist_name";
									  	}
									  	if($arr[$i]=="Country"){
									  		$arr[$i]="country_name";
									  	}
									  	if($arr[$i]=="Email"){
									  		$arr[$i]="email";
									  	}
									    ?>
									    <th style="text-align: left;font-size: 14px; font-family: 'Times New Roman', Times, serif;"><?php echo $row[$arr[$i]]; ?></th>
									    <?php
									    
									    $i=$i+1;

									  }
									?>
								</tr>
							<?php  }
							} 
							$Branch1=$_POST['Branch'];
							$Branch = implode(',', $Branch1);
							 $_SESSION["notifid"] = "$notifid";
							 $_SESSION["Branch"]="$Branch";
							?>
							</tbody>
						</table>
					</div>
					
 									<br><br>

                                    <input class="btn btn-small btn-success" type="submit" name="generate_pdf" value="Export to Excel" style="float: right;margin-right: 10%">
                                   
                                         <br> 
										</div>
					<?php
						}
					?>		
							<br><br>
						
                	
						
							<br><br><br>
					
						</div>
					</div><!--/.content-->
				</form>
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
</div>
</div>

	<div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>

	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
</body>