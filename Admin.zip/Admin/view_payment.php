<?php
include 'mypayment/config.php';
include 'connection.php';
include 'sweetalerttest.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; char et=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cam-RA</title>
    <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
    <link type="text/css" href="css/theme.css" rel="stylesheet">
    <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
    <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
  <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        .razorpay-payment-button{
            color: #ffffff !important;
            background-color: green;
            border-color: green;
            font-size: 14px;
        
        }
    </style>
     <script type="text/javascript">
        $(document).ready(function(){
            $("#search").on('change',function()
            {
                var opt=$(this).val();
                if(opt=="Gender"){
                    
                        $("#gend").show();
                        $("#sea").hide();
                        // $('#tit').show();
                        $("#field2").hide();
                       document.getElementById('gend').value="";                
                } else if(opt=="dept_id"){
                    $("#gend").hide();                      
                        $("#field2").show();
                        // $('#tit').show();
                        // $('#disp').hide();
                        $("#sea").hide();
                        document.getElementById('dept_id').value="";
                }
                else {

                        $("#gend").hide();                      
                        $("#sea").show();
                        // $('#tit').show();
                     // $('#disp').hide();
                     $("#field2").hide();
                     document.getElementById('sea').value="";  
                } 
                
            });
        });
        var inc=1;
    </script>
    <style >
        td.hover{
            background-color: #aff0ba;
        }
    </style>

</head>
<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->
    <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                            <!--/.widget-nav-->

                    </div><!--/.sidebar-->
                </div><!--/.span3-->
            <div class="span9">
                    <div class="content">

                        <div class="module">
                            <div class="module-head">
                                <h3>Payed Students</h3>
                            </div>
                            <div class="module-body">

                              <form class="form-horizontal row-fluid" method="POST">

                                <div class="control-group" id="comp" hidden="hide">
                                <label class="control-label">Companies</label>
                                                <div class="controls">
                                                    <table>
                                                    <?php 
                                                        $inc=1;
                                                        $sql="select org_id,Org from organization";
                                                        $result=mysqli_query($conn,$sql);
                                                        if(mysqli_num_rows($result) > 0){
                                                            $i=0;
                                                             while($row = mysqli_fetch_array($result)) {
                                                                echo "<td>";
                                                                if($i<2){
                                                               ?>
                
                                                <label class="checkbox">
                                                    <input type="checkbox" name="Branch[]" value="<?php echo $row['Org'] ?>">
                                                    <?php echo $row['Org']; ?>
                                                </label>
                                                
                                                             <?php
                                                                $i=$i+1;
                                                                echo"</td>";
                                                             }
                                                             else{$i=0;
                                                                echo"</td></tr>";
                                                             }
                                                            }
                                                        }  ?>
                                                    </table>
                                            </div>
                                        </div>
                                    <form method="post">    
                                <div class="control-group" id="mark">
                                        
                                <br>
                                    <select id="search"  name="search" id="filter" data-placeholder="Search By" class="span8" style="width: 35%;margin-left: 10%">
                                        <option value="">Search By</option>
                                        <option value="University_reg_no">University reg no</option>
                                        <option value="Full_Name">Student Name</option>
                                        <option value="dept_id">Department</option>
                                        <option value="Gender">Gender</option>
                                    </select>
                                            
                                            <!-- <div class="controls"> -->
                                                
                                    <select id="gend"  name="Gender" style="display: none;margin-left: 10%;width: 35%">
                                                    <option value="">Choose</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Others">Other</option>
                                    </select>
                                    
                                    <select name="dept" id="field2" class="form-control" style="display: none;margin-left: 10%;width: 35%">
                                                        <option value="">Search</option>

                                            <?php 
                                                $sql="SELECT * FROM department where chk=1 order by department_name ASC";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['dept_id'] ?>"><?php echo $row['department_name']; ?></option>

                                            <?php }
                                     }  ?>  
                                    </select>
                                    
                                    <input type="text" placeholder="Search" id="sea" name="sea" style="margin-left: 10%;width: 35%">
                                    <input type="submit" name="submit" value="Search" style="color: #ffffff !important;background-color: green;border-color: green;font-size: 14px;">
                                         <br> <br>
                                        </div>
                            </form>
                        <div class="module-body">
                                <div style="overflow-x:auto;overflow-y:auto;">
                                <table class="table">
                                  <thead id="tit" style="background-color:#cbd1cc">
                                    <tr>
                                      <th>SL.No</th>
                                      <th>University reg no</th>
                                      <th>Full Name</th>
                                      <th>Payment Date</th>
                                      <th>Transaction Id</th>
                                      <th></th>                         
                                    </tr>
                                  </thead> <?php
                               if(isset($_POST['submit'])){

                                   $search=$_POST['search'];
                                   $gender=$_POST['Gender'];
                                   $dept=$_POST['dept'];
                                   $sea=$_POST['sea'];
                                   if(($sea=="")and($dept=="")and($search=="")and($gender=="")){
                                        $sql="SELECT * from stud_info where stud_id in(SELECT stud_id from caution)";
                                        $result=mysqli_query($conn,$sql);
                                        
                                    }
                                   elseif(($sea=="")and($dept=="")){
                                       $sql="SELECT * from stud_info where stud_id in(SELECT stud_id from caution) and ". $search."='$gender' ";
                                       $result=mysqli_query($conn,$sql);
                                       
                                    }
                                   else if(($sea=="")and($gender=="")){
                                            $sql="SELECT * FROM stud_info WHERE stud_id in(SELECT stud_id from caution) and dept_id ='$dept'";
                                            $result=mysqli_query($conn,$sql);
                                            
                                        }
                                    else if(($dept=="")and($gender=="")){
                                          $sql="SELECT * from stud_info where stud_id in(SELECT stud_id from caution) and ". $search." like '%$sea%'";
                                          $result=mysqli_query($conn,$sql);
                                          
                                    }  
                               }
                               else{
                                    $sql="SELECT * from stud_info where stud_id in(SELECT stud_id from caution)";
                                    $result=mysqli_query($conn,$sql);
                                    
                                }
                            if(mysqli_num_rows($result)<1){
                                ?>
                                <tr class="odd gradeX">

                                        <td colspan="10"><h3 style="margin-left: 30%"><?php echo "No search Result Found" ?><h3></td>
                                <?php
                            }else{
                            $i=0;
                            while($row=mysqli_fetch_array($result)){;
                                $i=$i+1;
                                    ?>
                                    
                                     <tr class="odd gradeX">

                                        <td><?php echo  $i;?></td>
                                        <td>
                                            <?php echo  $row["University_Reg_No"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Full_Name"];?>
                                        </td>
                                        <?php  
                                            $stud_id=$row['stud_id'];
                                            $sql2="SELECT * FROM caution where stud_id='$stud_id'";
                                                $result2=mysqli_query($conn,$sql2);
                                                $row2=mysqli_fetch_array($result2);
                                        ?>
                                        <td>
                                            <?php echo  $row2["payment_date"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row2["pay_id"];?>
                                        </td>
                                        <!-- <td class="center">
                                            <button id="<?php //  echo'rzp-button'.$inc ?>" class="razorpay-payment-button">Refund</button> 
                                            <script src="https://checkout.razorpay.com/v1/checkout.js"> </script>
<script>

var options = {
    "key": "<?php // echo $razor_api_key; ?>", // Enter the Key ID generated from the Dashboard
    "amount": "50000", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Cam-RA",
    "description": "Caution Deposit",
    "image": "https://example.com/your_logo",
   
    "handler": function (response){
        alert(response.razorpay_payment_id);
        // alert(response.razorpay_order_id);
        var pay_id=response.razorpay_payment_id;
        var stud_id=document.getElementById('stud_id').value;

        $.ajax({
                type:'POST',
                url:'insert_payment.php',
                data:{ pay_id: pay_id,stud_id: stud_id },
                success:function (html) {
                    // $('#depart').html(html);
                    alert("success");
                }
            }); 
        // alert(response.razorpay_signature)
        
    },
    "prefill": {
        // "name": document.getElementById('name').value,
        // "email": document.getElementById('Email').value,
        // "contact": document.getElementById('Mobile').value
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#B52E31"
    }
};
var rzp1 = new Razorpay(options);
document.getElementById('rzp-button'+inc).onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
inc=inc+1;
</script>
                                        </td> -->
                                                                           
                                    </tr> 
                                  </tbody>
                                <?php $inc=$inc+1; } } ?>
                                                                                   
                                </table>
                                </div>
                                <br><br>
                            </form>                            
                        </div>
                    </div><!--/.content-->
                </div><!--/.span9-->
            </div>
        </div><!--/.container-->
    </div><!--/.wrapper-->
</div>
</div>


    <div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>

    <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
</body>