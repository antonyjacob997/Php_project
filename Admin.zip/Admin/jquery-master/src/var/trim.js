define( function() {
	"use strict";

	return "".trim;
} );
