<?php
  	include 'connection.php';
  	$org=$_POST['Organization'];
  	$dept=$_POST['Department'];
  	$des=$_POST['Designation'];
  	if($org != ""){
  		$sel="SELECT Org from organization where Org='$org'";
            $result=mysqli_query($conn,$sel);
            if(mysqli_num_rows($result) > 0){
                echo"<script>";
                echo "alert('organization already exist...');";
                echo"</script>";
            }
            else{

  				$sql="INSERT into organization(Org,status) values ('$org',1)";
					if ($conn->query($sql) === TRUE) 
					{
					    ?> 
					    	<script >alert("Organization added successfully...");
					    	location.href="admin_home.php";
					    	document.getElementsByTagName('Organization').values="";
					    </script>
					    <?php
					    	
					} else {
					    echo "Error: " . $sql . "<br>" . $conn->error;
					}
				}

  	}
  	else if ($dept != "") {
  			$sel="SELECT department_name from department where department_name='$dept'";
            $result=mysqli_query($conn,$sel);
            if(mysqli_num_rows($result) > 0){
                echo"<script>";
                echo "alert('department already exist...');";
                echo"</script>";
            }
            else{
					$sql="INSERT into department(department_name,status) values ('$dept',1)";
					if ($conn->query($sql) === TRUE) 
					{
					     ?> 
					    	<script >alert("Department added successfully...");
					    	location.href="admin_home.php";
					    	document.getElementsByTagName('Department').values="";
					    </script>
					    <?php
					    	
					} else {
					    echo "Error: " . $sql . "<br>" . $conn->error;
					}
				}
  	}
  	else if ($des != "") {
  		$sel="SELECT designation from designation where designation='$des'";
            $result=mysqli_query($conn,$sel);
            if(mysqli_num_rows($result) > 0){
                echo"<script>";
                echo "alert('designation already exist...');";
                echo"</script>";
            }
            else{
  		$sql="INSERT into designation(designation,status)values('$des',1)";
					if ($conn->query($sql) === TRUE) 
					{
					     ?> 
					    	<script >alert("Designation added successfully...");
					    	location.href="admin_home.php";
					    	document.getElementsByTagName('Designation').values="";
					    </script>
					    <?php
					    	
					} else {
					    echo "Error: " . $sql . "<br>" . $conn->error;
					}
				}
  	}
  	else
  	{
  		echo"<script>";
  		echo"alert('please add something')";
  		echo"</script>";
  	}

?>
<script>
	window.location.href="task.php";
</script>