<!DOCTYPE html>
<html lang="en">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cam-RA</title>
        <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="css/theme.css" rel="stylesheet">
        <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' 
            rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
    <body >
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>
        <div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->
        <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                            
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->
                    <?php 
                    $year=date("Y");             
                    $sql ="SELECT * from history where year='$year'";
                    $sql2="SELECT count(stud_id) from stud where course=1 and year_of_pass='$year'";
                    $sql3="SELECT count(stud_id) from stud where course=2 and year_of_pass='$year'";
                    $sql4="SELECT count(stud_id) from stud where course=3 and year_of_pass='$year'";
                                $result=mysqli_query($conn,$sql);
                                $result2=mysqli_query($conn,$sql2);
                                    $row2 = mysqli_fetch_array($result2);
                                $result3=mysqli_query($conn,$sql3);
                                    $row3 = mysqli_fetch_array($result3);
                                $result4=mysqli_query($conn,$sql4);
                                    $row4 = mysqli_fetch_array($result4);
                                    $Btech=0;
                                    $mca=0;
                                    $mtech=0;
                                    if(mysqli_num_rows($result) > 0){
                                        $row = mysqli_fetch_array($result);
                                        if(!empty($row2[0])){
                                            $Btech=$row['btech_count']/$row2[0]*100;
                                        }
                                        if(!empty($row3[0])){
                                            $mca=$row['mca_count']/$row3[0]*100;
                                        }
                                        if(!empty($row4[0])){
                                            $mtech=$row['mtech_count']/$row4[0]*100;
                                        }
                                        $comp=$row['company_count'];
                                    }      
                                    
              
                    $sql6="SELECT count(stud_id) from stud where year_of_pass='$year'";
                    $result6=mysqli_query($conn,$sql6);
                        $row6 = mysqli_fetch_array($result6);
                        $stud=$row['total_placed']/$row6[0]*100;
                        
                     ?>
                    <div class="span9">
                        <div class="content">
                            <div class="btn-controls">
                                <div class="btn-box-row row-fluid">
                                    <a href="placed.php" class="btn-box big span4"><i class=" icon-random"></i><b><?php echo intval($stud).'%';?></b>
                                        <p class="text-muted">
                                            Placed Students</p>
                                    </a><a href="ui-button-icon.php" class="btn-box big span4"><img width="45px" height="49px" src="images/company.jpg"></i><b><?php echo $comp.'+'; ?></b>
                                        <p class="text-muted">
                                            Companies</p>
                                    </a><a href="#" class="btn-box big span4"><i class="icon-money"></i><b>Cam-RA</b>
                                        <p class="text-muted">
                                            Campus Recrutent Assistant</p>
                                    </a>
                                </div>
                                <div class="btn-box-row row-fluid">
                                    <div class="span8">
                                        <div class="row-fluid">
                                            <div class="span12">
                                                <a href="message.php" class="btn-box small span4"><i class="icon-envelope"></i><b>Notifications</b>
                                                </a><a href="form.php" class="btn-box small span4"><i class="icon-group"></i><b>Students</b>
                                                </a><a href="filter.php" class="btn-box small span4"><i class="icon-exchange"></i><b>Filter data</b>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row-fluid">
                                            <div class="span12">
                                                <a href="create_notif.php" class="btn-box small span4"><i class="icon-save"></i><b>New Notification</b>
                                                </a><a href="admin_rules.php" class="btn-box small span4"><i class="icon-bullhorn"></i><b>Rules</b>
                                                </a><a href="report.php" class="btn-box small span4"><i class="icon-sort-down"></i><b>Report</b> </a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <ul class="widget widget-usage unstyled span4">
                                        <h3>Placements</h3>
                                        <li>
                                            <p>
                                                <strong>B-Tech</strong> <span class="pull-right small muted"><?php echo  intval($Btech).'%' ?></span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar" style="width: <?php echo $Btech.'%' ?>;">
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <p>
                                                <strong>MCA</strong> <span class="pull-right small muted"><?php echo  intval($mca).'%' ?></span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar bar-success" style="width: <?php echo $mca.'%' ?>;">
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <p>
                                                <strong>M-Tech</strong> <span class="pull-right small muted"><?php echo  intval($mtech).'%' ?></span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar bar-warning" style="width: <?php echo $mtech.'%' ?>;">
                                                </div>
                                            </div>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </div>
                            <!--/#btn-controls
        chart
                            <div class="module">
                                <div class="module-head">
                                    <h3>Profit Chart</h3>
                                </div>
                                <div class="module-body">
                                    <div class="chart inline-legend grid">
                                        <div id="placeholder2" class="graph" style="height: 500px">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            /.module-->
                            <div class="module hide">
                                <div class="module-head">
                                    <h3>
                                        Adjust Budget Range</h3>
                                </div>
                                <div class="module-body">
                                    <div class="form-inline clearfix">
                                        <a href="#" class="btn pull-right">Update</a>
                                        <label for="amount">
                                            Price range:</label>
                                        &nbsp;
                                        <input type="text" id="amount" class="input-" />
                                    </div>
                                    <hr />
                                    <div class="slider-range">
                                    </div>
                                </div>
                            </div>
                            <div class="module">
                                <div class="module-head">
                                    <h3>
                                        Registered Student for Upcoming Drive
                                    </h3>
                                </div>
                                <div class="module-body table">
                                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped  display"width="100%">
                                        <thead>
                                            <tr>
                                                <th>Company</th>
                                                <th>Full Name</th>
                                                <th>Department</th>
                                                <th>Date</th>
                                                <th>Venue</th>
                                            </tr>
                                        </thead>
                        <tbody>
                            <?php
                                $sql="SELECT drive_reg.org_id,date2,venue,Full_Name,dept_id
from notification,stud,drive_reg
where 
notification.status=1 and
notification.notif_id=drive_reg.notif_id and
drive_reg.stud_id=stud.stud_id
";

                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                    while($row = $result->fetch_assoc()) { 
                                                  $org_id=$row['org_id'];
                                                  $dept_id=$row['dept_id'];
                                           $sql2="SELECT Org from organization where org_id=$org_id";
                                           $sql3="SELECT department_name from department where dept_id=$dept_id";
                                        $result2 = $conn->query($sql2);

                                            if ($result2->num_rows > 0) {
                                                $row2 = $result2->fetch_assoc();
                                                $organization=$row2['Org'];
                                            }
                                        $result3 = $conn->query($sql3);

                                            if ($result3->num_rows > 0) {
                                                $row3 = $result3->fetch_assoc();
                                                $department=$row3['department_name'];
                                            }
                                           ?>
                                            <tr class="odd gradeX">
                                                <td>
                                                    <?php echo $organization; ?>
                                                </td>
                                                <td>
                                                    <?php echo  $row["Full_Name"];?>
                                                </td>
                                                <td>
                                                    <?php echo  $department; ?>
                                                </td>
                                                <td class="center">
                                                    <?php echo  $row["date2"];?>
                                                </td>
                                                <td class="center">
                                                    <?php echo  $row["venue"];?>
                                                </td>
                                            </tr>
                                    <?php  } ?> 
                                        </tbody>
<?php 
        
   } 
?>
                                        
                                    </table>
                                </div>
                            </div>
                            <!--/.module-->
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
        <div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>
        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="scripts/common.js" type="text/javascript"></script>

    </body>
