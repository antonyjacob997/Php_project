<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; char et=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <!--  <script type="text/javascript" src="myscript.js"></script>  -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
	<script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
  <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <script type="text/javascript">
		$(document).ready(function(){
			$("#search").on('change',function()
			{
				var opt=$(this).val();
				if(opt=="Gender"){
            		
					    $("#gend").show();
					    $("#sea").hide();
					    // $('#tit').show();
					    $("#field2").hide();
					   document.getElementById('gend').value="";				
				} else if(opt=="dept_id"){
					$("#gend").hide();						
					    $("#field2").show();
					    // $('#tit').show();
		             	// $('#disp').hide();
		             	$("#sea").hide();
		             	document.getElementById('dept_id').value="";
				}
				else {

						$("#gend").hide();						
					    $("#sea").show();
					    // $('#tit').show();
		             // $('#disp').hide();
		             $("#field2").hide();
					 document.getElementById('sea').value="";  
				} 
				
			});
		});
	</script>
	<style >
		td.hover{
			background-color: #aff0ba;
		}
	</style>

</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>

<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->

	<div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                            <!--/.widget-nav-->

					</div><!--/.sidebar-->
				</div><!--/.span3-->


				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Student Details</h3>
							</div>
							<div class="module-body">

<!--


									<div class="alert">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Warning!</strong> Something fishy here!
									</div>
									<div class="alert alert-error">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Oh snap!</strong> Whats wrong with you? 
									</div>
									<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Well done!</strong> Now you are listening me :) 
									</div>

									<br />
-->
									<form class="form-horizontal row-fluid" method="POST">
										
	
                                
                                <div class="control-group" id="comp" hidden="hide">
                                <label class="control-label">Companies</label>
                                            	<div class="controls">
                                            		<table>
                                                	<?php 
				
													    $sql="select org_id,Org from organization";
													    $result=mysqli_query($conn,$sql);
													    if(mysqli_num_rows($result) > 0){
													    	$i=0;
													         while($row = mysqli_fetch_array($result)) {
													         	echo "<td>";
													         	if($i<2){
													           ?>
                
                                                <label class="checkbox">
                                                    <input type="checkbox" name="Branch[]" value="<?php echo $row['Org'] ?>">
                                                    <?php echo $row['Org']; ?>
                                                </label>
                                                
												             <?php
												             	$i=$i+1;
												             	echo"</td>";
												             }
												             else{$i=0;
												             	echo"</td></tr>";
												             }
												            }
												        }  ?>
												    </table>
                                            </div>
                                        </div>
                            <form method="post">    
                                <div class="control-group" id="mark">
										
                                <br>
                                    <select id="search"  name="search" id="filter" data-placeholder="Search By" class="span8" style="width: 35%;margin-left: 10%">
                                        <option value="">Search By</option>
                                        <option value="University_reg_no">University reg no</option>
                                        <option value="Full_Name">Student Name</option>
                                        <option value="dept_id">Department</option>
                                        <option value="Gender">Gender</option>
                                    </select>
                                            
											<!-- <div class="controls"> -->
                                                
                                    <select id="gend"  name="Gender" style="display: none;margin-left: 10%;width: 35%">
                                    				<option value="">Choose</option>
                                                	<option value="Male">Male</option>
                                                	<option value="Female">Female</option>
                                                	<option value="Others">Other</option>
                                    </select>
                                    
									<select name="dept" id="field2" class="form-control" style="display: none;margin-left: 10%;width: 35%">
														<option value="">Search</option>

                                            <?php 
                                                $sql="SELECT * FROM department where chk=1 order by department_name ASC";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['dept_id'] ?>"><?php echo $row['department_name']; ?></option>

                                            <?php }
                                     }  ?>  
									</select>
									
                                    <input type="text" placeholder="Search" id="sea" name="sea" style="margin-left: 10%;width: 35%">
                                    <input type="submit" name="submit" value="Search">
                                         <br> <br>
										</div>
							</form>
                                <div class="module-body">
                                <div style="overflow-x:auto;overflow-y:auto;">
                                <table class="table" style="width: 5500px">
								  <thead id="tit" style="background-color:#cbd1cc">
									<tr>
									  <th>SL.No</th>
									  <th>University reg no</th>
									  <th>Full Name</th>
									  <th>Department</th>
									  <th>Placed </th>
									  <th>Company</th>
									  <th>Email</th>
									  <th>Alt Email</th>
									  <th>mobile</th>
									  <th>Alt mobile</th>
									  <th>Date of Birth</th>
									  <th>Gender</th>
									  <th>Father's Name</th>
									  <th>Mother's Name</th>
									  <th>House Name</th>
									  <th>Street</th>
									  <th>City</th>
									  <th>District</th>
									  <th>State</th>
									  <th>Country</th>
									  <th>Pincode</th>
									<th>Aggr_CGPA</th>
									<th>Aggr_Percentage</th>
									<th>CURRENT_ARREARS</th>
									<th>HISTORY_OF_ARREARS</th>
									<th>10th_p</th>
									<th>10th_CGPA</th>
									<th>10th_YoP </th>
									<th>10th_Board </th>
									<th>10th_School </th>
									<th>10th_State_of_school </th>
									<th>12th_p </th>
									<th>12th_CGPA </th>
									<th>12th_YoP </th>
									<th>12th_Board </th>
									<th>12th_School </th>
									<th>12th_State_of_School </th>
									<th>UG_Course </th>
									<th>UG_P </th>
									<th>UG_CGPA </th>
									<th>UG_YoP </th>
									<th>UG_College </th>
									<th>state_of_UG </th>
									<th>UG_University </th>
									<th>PG_University </th>
									<th>Technical_Skills </th>
									<th>Work_Experience </th>
									<th>Certifications </th>
									<th>Internships </th>
									
									</tr>
								  </thead> <?php
							   if(isset($_POST['submit'])){

							   	   $search=$_POST['search'];
							   	   $gender=$_POST['Gender'];
							   	   $dept=$_POST['dept'];
							   	   $sea=$_POST['sea'];
							   	   if(($sea=="")and($dept=="")and($search=="")and($gender=="")){
							   	   		$sql="SELECT * from stud_info";
										$result=mysqli_query($conn,$sql);
										
							   	   	}
							   	   elseif(($sea=="")and($dept=="")){
								   	   $sql="SELECT * from stud_info where ". $search."='$gender'";
								   	   $result=mysqli_query($conn,$sql);
								   	   
								   	}
							   	   else if(($sea=="")and($gender=="")){
							   	   			$sql="SELECT * FROM stud_info WHERE dept_id ='$dept'";
							   	   			$result=mysqli_query($conn,$sql);
							   	   			
							   	   		}
							   	   	else if(($dept=="")and($gender=="")){
								   	   	  $sql="SELECT * from stud_info where ". $search." like '%$sea%'";
								   	   	  $result=mysqli_query($conn,$sql);
								   	   	  
							   	   	}  
							   }
							   else{
									$sql="SELECT * from stud_info";
									$result=mysqli_query($conn,$sql);
									
								}
							if(mysqli_num_rows($result)<1){
								?>
								<tr class="odd gradeX">

										<td colspan="10"><h3 style="margin-left: 30%"><?php echo "No search Result Found" ?><h3></td>
								<?php
							}else{
							$i=0;
							while($row=mysqli_fetch_array($result)){;
								$i=$i+1;
									?>
								  	
									 <tr class="odd gradeX">

										<td><?php echo  $i;?></td>
				                     	<td>
				                            <?php echo  $row["University_Reg_No"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Full_Name"];?>
				                        </td>
				                        <?php  
				                        	$dept_id=$row['dept_id'];
				                        	$sql2="SELECT department_name FROM department where dept_id='$dept_id'";
                                                $result2=mysqli_query($conn,$sql2);
                                                $row2=mysqli_fetch_array($result2);
				                        ?>
				                        <td>
				                            <?php echo  $row2["department_name"];?>
				                        </td>
				                        <?php
				                        $stid=$row['stud_id']; ?>
				                        <td class="center">
				                            <a href="add_stud.php?stid=<?php echo $stid;?>"><i class="menu-icon fa fa-edit"></i></a>
				                        </td>
				                        <?php 
				                        
				                        $result55=mysqli_query($conn,"SELECT Org from organization where org_id in(SELECT Company from placed where stud_id=$stid)");
				                        if(mysqli_num_rows($result55)<1){
				                         	$company="Not Placed";
				                        }else{
				                        	$roww=mysqli_fetch_array($result55);
				                        	$company=$roww["Org"];
				                        }
				                        ?>
				                        <td class="center">
				                            <?php echo  $company;?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["email"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Alt_Email"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["Mobile"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Alt_Mobile"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["DoB"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Gender"];?>
				                        </td>
				                        
				                        <td class="center">
				                            <?php echo  $row["Father_Name"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Mother_Name"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["House_Name"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Street"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["City"];?>
				                        </td>
				                        <?php  
				                        	$dist_id=$row['dist_id'];
				                        	$sql5="SELECT dist_name FROM district where dist_id='$dist_id'";
                                                $result5=mysqli_query($conn,$sql5);
                                                $row5=mysqli_fetch_array($result5);
				                        ?>
				                        <td class="center">
				                            <?php echo  $row5["dist_name"];?>
				                        </td>
				                        <?php  
				                        	$state_id=$row['state_id'];
				                        	$sql3="SELECT state_name FROM state where state_id='$state_id'";
                                                $result3=mysqli_query($conn,$sql3);
                                                $row3=mysqli_fetch_array($result3);
				                        ?>
				                        <td>
				                            <?php echo  $row3["state_name"];?>
				                        </td>
				                        <?php  
				                        	$country_id=$row['country_id'];
				                        	$sql4="SELECT country_name FROM country where country_id='$country_id'";
                                                $result4=mysqli_query($conn,$sql4);
                                                $row4=mysqli_fetch_array($result4);
				                        ?>
				                        <td>
				                            <?php echo  $row4["country_name"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Pincode"];?>
				                        </td>
				                        
				                        <td class="center">
				                            <?php echo  $row["Aggr_CGPA"];?>
				                        </td>
				                        
				                        <td>
				                            <?php echo  $row["Aggr_Percentage"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["CURRENT_ARREARS"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["HISTORY_OF_ARREARS"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["10th_p"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["10th_CGPA"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["10th_YoP"];?>
				                        </td>
				                        
				                        <td>
				                            <?php echo  $row["10th_Board"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["10th_School"];?>
				                        </td>
				                        <?php  
				                        	$state_id=$row['10th_State_of_school'];
				                        	$sql7="SELECT state_name FROM state where state_id='$state_id'";
                                                $result7=mysqli_query($conn,$sql7);
                                                $row7=mysqli_fetch_array($result7);
				                        ?>
				                        <td class="center">
				                            <?php echo  $row7["state_name"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["12th_p"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["12th_CGPA"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["12th_YoP"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["12th_Board"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["12th_School"];?>
				                        </td>
				                        <?php  
				                        	$state_id=$row['12th_State_of_School'];
				                        	$sql8="SELECT state_name FROM state where state_id='$state_id'";
                                                $result8=mysqli_query($conn,$sql8);
                                                
                                                $row8=mysqli_fetch_array($result8);
				                        ?>
				                        <td class="center">
				                            <?php echo  $row8["state_name"];?>
				                        </td>
				                        <?php  
				                        	$UG_Course=$row['UG_Course'];
				                        	$sql12="SELECT department_name FROM department where dept_id='$UG_Course'";
                                                $result12=mysqli_query($conn,$sql12);
                                                
                                                $row12=mysqli_fetch_array($result12);
				                        ?>
				                        <td>
				                            <?php echo  $row12["department_name"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["UG_P"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["UG_CGPA"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["UG_YoP"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["UG_College"];?>
				                        </td>
				                        <?php  
				                        	$state_id=$row['state_of_UG'];
				                        	$sql9="SELECT state_name FROM state where state_id='$state_id'";
                                                $result9=mysqli_query($conn,$sql9);
                                                $row9=mysqli_fetch_array($result9);
				                        ?>
				                        <td class="center">
				                            <?php echo  $row9["state_name"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["UG_University"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["PG_University"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Technical_Skills"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Work_Experience"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["Certifications"];?>
				                        </td>
				                        <td class="center">
				                            <?php echo  $row["Internships"];?>
				                        </td>
				                        
				                    </tr> 
								  </tbody>
								<?php } } ?>
								
														
								</table>
								</div>
								<br>

											<br>
                                        	
                            
							</form>
							
						</div>
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
</div>
</div>


	<div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>

	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
</body>