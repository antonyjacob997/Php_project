<?php
include 'connection.php';

if(!empty($_POST['countryid'])){
	$c=$_POST['countryid'];
	$qry="SELECT * from state where country_id='$c' ORDER BY state_name ASC";
	$result=mysqli_query($conn,$qry);
	if(mysqli_num_rows($result) > 0){
		echo'<option value=""> select State</option>';
        while($row = mysqli_fetch_array($result)) {                              
            echo"<option value=".$row['state_id'].">".$row['state_name']."</option>";
         }   
    }                                
     else{

		echo'<option value="">State not available</option>';
     }                                 
}

?>
