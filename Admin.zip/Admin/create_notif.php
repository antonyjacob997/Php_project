<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cam-RA</title>
    <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
    <link type="text/css" href="css/theme.css" rel="stylesheet">
    <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
    <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <!--  <script type="text/javascript" src="myscript.js"></script>  -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
  <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";
}
?>
<body>
        <div class="navbar navbar-fixed-top" >
            <div class="navbar-inner" style="background-color: #25274D; height:80px">
                <div class="container" >
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a><a class="brand" href="index.php">Cam-RA </a>
                    <div class="nav-collapse collapse navbar-inverse-collapse">
                        <ul class="nav nav-icons">
                            <li><a href="#"><i class="icon-envelope"></i></a></li>
                            <li><a href="#"><i class="icon-eye-open"></i></a></li>
                            <li><a href="#"><i class="icon-bar-chart"></i></a></li>
                        </ul>
                        <!-- <form class="navbar-search pull-left input-append" action="#">
                        <input type="text" class="span3">
                        <button class="btn" type="button">
                            <i class="icon-search"></i>
                        </button>
                        </form> -->
                        <ul class="nav pull-right">
                          
                            <li><a href="#"><?php echo $name ?> </a></li>  
                            <li class="nav-user dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                               <!-- <img src="images/user.png" class="nav-avatar" />-->
                                <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="#">Your Profile</a></li>
                                    <li><a href="#">Edit Profile</a></li>
                                    <li><a href="#">Account Settings</a></li>
                                    <li class="divider"></li>
                                    <li><a href="Logout.php">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>
        <!-- /navbar -->
    <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                    </div><!--/.sidebar-->
                </div><!--/.span3-->


                <div class="span9">
                    <div class="content">

                        <div class="module">
                            <div class="module-head">
                                <h3>Create Notification</h3>
                            </div>
                            <div class="module-body">
                                <div class="stream-composer media">
                                    
                    <form class="form-horizontal row-fluid" action="notif_action.php" method="POST">
                        <div class="control-group">
                            <label class="control-label" for="basicinput">Organization</label>
                                <div class="controls">
                                    <select name="Organization" data-placeholder="Select here.." class="span8" required="required">
                                                    <option value="">Select here..</option>

                            <?php 
                                $sql="SELECT * FROM organization where status=1";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['org_id'] ?>"><?php echo $row['Org']; ?></option>
                                            <?php }
                                     }  ?>  
                                                </select>
                                            </div>
                                        </div>
                                        <div class="control-group" id="dept">
        <label class="control-label">Departments</label>
        <div class="controls">
            <table>
                <?php 
                
                    $sql="SELECT dept_id,department_name from department where status=1 and chk=1 order by department_name asc";
                    $result=mysqli_query($conn,$sql);
                    if(mysqli_num_rows($result) > 0){
                        $i=0;
                        while($row = mysqli_fetch_array($result)) {
                            echo "<td>";
                            if($i<2){
                ?>
                                <label class="checkbox">
                                    <input type="checkbox" name="Branch[]" value="<?php echo $row['department_name'] ?>">
                                        <?php echo $row['department_name'] ?>
                                </label>
                                                
                            <?php
                                $i=$i+1;
                                    echo"</td>";
                            }
                            else{
                                $i=1;
                                echo"</td></tr><tr><td>";?>
                                <label class="checkbox">
                                    <input type="checkbox" name="Branch[]" value="<?php echo $row['department_name'] ?>">
                                        <?php echo $row['department_name'] ?>
                                </label><?php
                            }
                        }
                        $Year=date("Y");
                    }  ?>
            </table>
        </div>
    </div>
                                        <div class="control-group" id="mark">
                                          <label class="control-label" for="basicinput">Pass out Year</label>
                                            <div class="controls">
                                                <select name="YOP" class="span8" required>
                                                  <option value="">Choose</option>
                                                  <option value="<?php echo $Year; ?>"><?php echo $Year; ?></option>
                                                  <option value="<?php echo $Year+1; ?>"><?php echo $Year+1; ?></option>
                                                </select>
                                                <label class="errortext" style="display:none; color:red" id="Year"></label>
                                            </div><br>
                                        
                                        <label class="control-label" for="basicinput">Tenth percentage</label>
                                            <div class="controls">
                                                <input type="text" id="Per_ten" onchange="Valid_ten(this);" name="Per_ten" class="span8">
                                                <label class="errortext" style="display:none; color:red" id="addr"></label>
                                            </div><br>
                                        <script type="text/javascript">                      
                                            function Valid_ten(input)
                                              {
                                                  var val = document.getElementById('Per_ten').value;
                                                  if (!val.match(/^[0-9]{2}$/))
                                                  {
                                                  $("#addr").html('Must.  Only Numbers Allowed..! lessthan 100').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('Per_ten').value = "";
                                                  input.style.borderColor = "#e74c3c";
                                                  document.getElementById('Per_ten').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        </script>

                                            <label class="control-label" for="basicinput">Plus two Percentage</label>
                                            <div class="controls">
                                                <input type="text" id="Per_twe" onchange="Valid_twe(this);" name="Per_twe" class="span8">
                                            <label class="errortext" style="display:none; color:red" id="addr1"></label>
                                            </div><br>
                                        <script type="text/javascript">                      
                                            function Valid_twe(input)
                                              {
                                                  var val = document.getElementById('Per_twe').value;
                                                  if (!val.match(/^[0-9]{2}$/))
                                                  {
                                                  $("#addr1").html('Must.  Only Numbers Allowed..! lessthan 100').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('Per_twe').value = "";
                                                  input.style.borderColor = "#e74c3c";
                                                  document.getElementById('Per_twe').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        </script>
                                            <label class="control-label" for="basicinput">Degree CGPA</label>
                                            <div class="controls">
                                                <input type="text" id="Per_deg" onchange="Valid_deg(this);" name="Per_deg" class="span8">
                                              <label class="errortext" style="display:none; color:red" id="addr2"></label>
                                            </div><br>
                                        <script type="text/javascript">                      
                                            function Valid_deg(input)
                                              {
                                                  var val = document.getElementById('Per_deg').value;
                                                  if (!val.match(/^\d+\.\d{0,2}$/))
                                                  {
                                                  $("#addr2").html('Must.  Only Numbers Allowed..! lessthan 10').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('Per_deg').value = "";
                                                  input.style.borderColor = "#e74c3c";
                                                  document.getElementById('Per_deg').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        </script>
                                            <label class="control-label" for="basicinput">Backlogs</label>
                                            <div class="controls">
                                                <input type="text" id="backlg"  name="backlog" class="span8" onchange="backlo(this);">
                                            <label class="errortext" style="display:none; color:red" id="addr3"></label>
                                            </div><br>
                                        <script type="text/javascript">                      
                                            function backlo(input)
                                              {
                                                  var val = document.getElementById('backlg').value;
                                                  if (!val.match(/^[0-9]{1,2}$/))
                                                  {
                                                  $("#addr3").html('Must.  Only one or two digit Numbers Allowed..! ').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('backlg').value = "";
                                                  input.style.borderColor = "#e74c3c";
                                                  document.getElementById('backlg').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        </script>

                                            
                                        <div class="control-group">
                                            <label class="control-label" for="basicinput">Other Criteria</label>
                                            <div class="controls">
                                                <textarea class="span8" name="criteria" rows="5"></textarea>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                             <label class="control-label" for="basicinput">Date of Registration</label>
                                             <?php 
                                                $d=date("Y-m-d");
                                             ?>
                                             <div class="controls">
                                                <input type="date" id="date_of_reg" name="date1" min="<?php echo($d); ?>" max="2021-12-31" onchange=valid();>
                                            </div>
                                        </div>
                                        <script>
                                          function valid(){
                                            var date12=document.getElementById('date_of_reg').value;
                                            document.getElementById('drive_date').min=date12;
                                          }
                                        </script><br>
                                        <div class="control-group">
                                             <label class="control-label" for="basicinput">Date of Recruitment</label>
                                             <div class="controls">
                                                <input type="date" name="date2" id="drive_date" max="2021-12-31">
                                                
                                            </div>
                                        </div>
                            <div class="control-group">
                                <label class="control-label" for="basicinput">Venue</label>
                                    <div class="controls">
                                        <input type="text" name="venue" id="basicinput" placeholder="Type something here..." class="span8">                                               
                                    </div>
                                </div>
                                <div class="control-group">
                                <label class="control-label" for="basicinput">Venue 2</label>
                                    <div class="controls">
                                        <input type="text" name="venue2" id="basicinput" placeholder="Venue 2 if needed." class="span8">                                               
                                    </div>
                                </div>
                            <div class="control-group">
                                <label class="control-label" for="basicinput">Designation</label>
                                    <div class="controls">
                                        <input type="text" name="Designation" id="basicinput" placeholder="Type something here..." class="span8">                                               
                                    </div>
                                </div>
                                <div class="control-group">
                                <label class="control-label" for="basicinput">CTC</label>
                                    <div class="controls">
                                        <input type="text" name="ctc" id="basicinput" placeholder="Type something here..." class="span8">                                               
                                    </div>
                                </div>

                                    <div class="control-group">
                                        <label class="control-label">Rounds</label>
                                        <div class="controls">
                                            <label class="checkbox inline">
                                                <input type="checkbox" name="rounds[]" value="Online Aptitude">
                                                    Online Aptitude
                                            </label>
                                            <label class="checkbox inline">
                                                <input type="checkbox" name="rounds[]" value="Offline Aptitude">
                                                    Offline Aptitude
                                            </label>
                                            <label class="checkbox inline">
                                                <input type="checkbox" name="rounds[]" value="Group Discussion">
                                                    Group Discussion
                                            </label>
                                            <label class="checkbox inline">
                                                <input type="checkbox" name="rounds[]" value="Personal Interview">
                                                    Personal Interview
                                            </label>
                                            <label class="checkbox inline">
                                                <input type="checkbox" name="rounds[]" value="Technical Interview">
                                                    Technical Interview
                                            </label>
                                            <label class="checkbox inline">
                                                <input type="checkbox" name="rounds[]" value="HR Interview">
                                                    HR Interview
                                            </label>
                                                
                                            </div>
                                        </div><div class="control-group">
                                <label class="control-label" for="basicinput">Other Rounds</label>
                                    <div class="controls">
                                        <input type="text" name="other_rounds" id="basicinput" placeholder="Other Rounds if any..." class="span8">                                               
                                    </div>
                                </div>
                                        <div class="control-group">
                                            
                                            <div class="controls">
                                                
                                            </div>
                                        </div>
                    
                                        <div class="clearfix">
                                            <input type="submit" name="submit" value="Send Notification" class="btn btn-primary pull-right" >
                                            
                                            <a href="message.php" class="btn btn-primary pull-right">
                                                Cancel
                                            </a>
                                            <br>
                                        </div><br>
                                </form>
                                    </div>
                                </div>
</div>
                        </div><!--/.module-->
                        
                    </div><!--/.content-->
                </div><!--/.span9-->
            </div>
        </div><!--/.container-->
    </div><!--/.wrapper-->

    <div class="footer">
        <div class="container">
             

            <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
        </div>
    </div>

    <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>