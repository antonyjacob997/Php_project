<?php
include 'connection.php';

if(!empty($_POST['stateid'])){
	$c=$_POST['stateid'];
	$qry="SELECT * from district where state_id='$c' ORDER BY dist_name ASC";
	$result=mysqli_query($conn,$qry);
	if(mysqli_num_rows($result) > 0){
		echo'<option value=""> select District</option>';
        while($row = mysqli_fetch_array($result)) {                              
            echo"<option value=".$row['dist_id'].">".$row['dist_name']."</option>";
         }   
    }                                
     else{

		echo'<option value="">District not available</option>';
     }                                 
}

?>
