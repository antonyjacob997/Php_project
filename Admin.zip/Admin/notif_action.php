<?php
session_start();
include 'connection.php';
include 'sweetalerttest.php';
$organization=$_POST['Organization'];

$criteria=$_POST['criteria'];

$venue=$_POST['venue'];
$venue2=$_POST['venue2'];
$designation=$_POST['Designation'];
$ctc=$_POST['ctc'];
$other_rounds=$_POST['other_rounds'];
$yop=$_POST['YOP'];
$Per_ten=$_POST['Per_ten'];
$Per_twe=$_POST['Per_twe'];
$Per_deg=$_POST['Per_deg'];
$backlog=$_POST['backlog'];


$date1=$_POST['date1'];
$date2=$_POST['date2'];
$status=1;
$user_type="Student";

$br="";
$de="";
foreach($_POST['Branch'] as $values)
  {
    $br=$br . $values .", ";
    
  }

//  echo $br . "<br>";

  $rou="";
foreach($_POST['rounds'] as $values)
  {
    
    $rou=$rou . $values.", ";
  }
//  echo $rou;
$chk="SELECT * from notification where org_id='$organization' and YOP=$yop";
$chk_res=mysqli_query($conn,$chk);
    if(mysqli_num_rows($chk_res)>0)
        {
        echo "<script>swal('Oops.!', 'Already Posted this notification..!', 'error');</script>";
    }else{
//  Insert into database

  $qry1="INSERT into notification(org_id,elig_branch,tenth,plus_two,degree,backlog,other_criteria,date1,date2,venue,venue2,designation,ctc,rounds,other_round,status,YOP)values($organization,'$br','$Per_ten','$Per_twe','$Per_deg',$backlog,'$criteria','$date1','$date2','$venue','$venue2','$designation','$ctc','$rou','$other_rounds',$status,$yop)";
  if ($conn->query($qry1) === TRUE) 
      {

        
    } else {
        echo "<script>swal('Oops.!', 'Something went Wrong..!', 'error');</script>";
    }

// to fetch the notification

    $qry2="SELECT notif_id from notification where org_id=$organization and date1='$date1'";
      $result=mysqli_query($conn,$qry2);
              if(mysqli_num_rows($result)>0)
              {
                $row = mysqli_fetch_array($result);
                $notif_id=$row['notif_id'];
              }

// to fetch stud from eligible department

    $rou=1;
foreach($_POST['Branch'] as $values)
  {
//To fetch students with eligibility
//echo "<script>alert('rereh');</script>";

  $sql="SELECT stud_id from stud_info where 10th_p >= $Per_ten and 12th_p >= $Per_twe and UG_CGPA >= $Per_deg and CURRENT_ARREARS <= $backlog and dept_id in (SELECT dept_id from department where department_name='$values')";
  $result=mysqli_query($conn,$sql);
          if(mysqli_num_rows($result)>0)
          {
           while($row = mysqli_fetch_array($result)){
                 $stud_id=$row['stud_id'];
          
  
            $sql2="INSERT into drive_elig (notif_id,stud_id,status)values($notif_id,$stud_id,$status)";

        $result1=mysqli_query($conn,$sql2);
          
            }
            if($result1)
                {
                  echo "<script>alert('notification send successfully...');</script>";
              } 
              else {
                  echo "<script>alert('notification send failed...');</script>";
              }
          }
      }
  }
  ?>
                 <script >window.location='admin_home.php'</script>
