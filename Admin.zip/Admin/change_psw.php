<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>

	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="myscript.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>	
<div>
    <?php include 'admin_top_nav.php'; ?>
</div>
        <!-- /navbar -->
	<div class="wrapper" style="background-color: #101820ff">
		<div class="container">
			<div class="row">
				<div class="module module-login span8 offset2">
					<form class="form-vertical" method="post">
						<div class="module-head">
							<h3>Change Password</h3>
						</div><br>
						<div class="module-body">
							<div class="control-group">
								<div class="controls row-fluid offset1">									
									<input style="width: 60%" name="cpass"  type="password" id="cpass" placeholder="Current Password" required="required"> 
									<label class="errortext" style="display:none; color:red" id="psw_1">
								</div>
							</div><br>
							<div class="control-group">
								<div class="controls row-fluid offset1">
									<input style="width: 60%" name="npass" id="npass" type="password" placeholder="New Password"onchange="Validatepass(this)" required="required"> 
									<label class="errortext" style="display:none; color:red" id="psw_2">
								</div>
							</div>
							<div class="control-group">
								<div class="controls row-fluid offset1">
									<input style="width: 60%" name="password" type="password" id="password" placeholder="Confirm Password" onchange="confirm_password(this)" required="required"> 
									<label class="errortext" style="display:none; color:red" id="psw_3">
								</div><br>
							</div>
						</div>
						<div class="module-foot">
							<div class="control-group">
								<div class="controls clearfix">
									<button type="submit" name="submit" style="width: 20%" class="btn btn-success offset3">Login</button>
									
								</div>
							</div>
						</div>
						<script>
                            function Validatepass(input)
                            {
                                var pass = document.getElementById('npass');
                                var filter = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
                                if (!filter.test(pass.value)) {
                                    pass.value="";
                                    $("#psw_2").html('Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters ').fadeIn().delay(4000).fadeOut();
                                    input.style.borderColor = "#e74c3c";
                                    document.getElementById('npass').focus();
                                    return false;
	                            }
	                            input.style.borderColor = "#2ecc71";
	                            return false;
                            }
                            function confirm_password(input)
                            {
                                var pas = document.getElementById('npass').value;
                                var cpas = document.getElementById('password').value;
                                if (pas!=cpas)
                                {
                                    $("#psw_3").html('Password Miss Match..!').fadeIn().delay(4000).fadeOut();
                                    input.style.borderColor = "#e74c3c";
                                    document.getElementById('password').focus();
                                    document.getElementById('password').value="";
                                    return false;
                                }
                                                  
                                if (pas==cpas)
                                {
                                    input.style.borderColor = "#2ecc71";
                                }
                                input.style.borderColor = "#2ecc71";
                                return true;
                            }
                        </script>

					</form>
				</div>
			</div>
		</div><br><br>
	</div><!--/.wrapper--><br>

	<div class="footer">
		<div class="container">
			 
<b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
		</div>
	</div>

<?php
    include 'connection.php';
    include 'sweetalerttest.php';
    if(isset($_POST['submit'])){
    	
    	$cpass=md5($_POST['cpass']);
    	$npass=md5($_POST['npass']);
    	$password=md5($_POST['password']);
    	
    	$sel="select * from login where login_id='$id' and password='$cpass'";
        $result=mysqli_query($conn,$sel);
        if(mysqli_num_rows($result) > 0){
            $sql="UPDATE login set password='$npass' where login_id='$id'";
            if ($conn->query($sql) === TRUE) 
    		{
    			echo"<script>swal('Password..','Updated Successfully','success')</script>";
	        }
		    else {  
		    	echo"<script>swal('Sorry..','Please try later','error')</script>";
			}
    	}
    	else{
    		echo"<script>swal('Sorry..','Wrong Password','error')</script>";
    	}
    }
?>
	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('.table-message tbody tr').click(
				function() 
				{
					$(this).toggleClass('resolved');
				}
			);
		} );
	</script>
</body>