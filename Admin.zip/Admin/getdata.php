<?php
include 'connection.php';
  if(!empty($_POST['org_id'])){
    $c=$_POST['org_id'];

    $qry="SELECT * from notification where org_id='$c'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result) > 0){
       $row = mysqli_fetch_array($result);
       $pp1= $row['designation'];
       echo '<input type="text" id="desig" readonly name="desig" class="span8" value="'.$pp1.'">';
    }
    else{
      echo '<input type="text" readonly id="desig" class="span8" value="sorry">';
    }
}
?>
