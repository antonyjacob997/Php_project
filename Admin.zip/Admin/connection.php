
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cam-ra";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
 {
    die("Connection failed: " . $conn->connect_error);
}
?>
 <?php 
// $servername = "localhost";
// $username = "id13080501_camra";
// $password = "mypassword";
// $dbname = "id13080501_camra";

// // Create connection
// $conn = new mysqli($servername, $username, $password, $dbname);

// // Check connection
// if ($conn->connect_error)
//  {
//     die("Connection failed: " . $conn->connect_error);

// }

?>