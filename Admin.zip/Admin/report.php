<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>

	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="myscript.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script type="text/javascript">
    $(document).ready(function(){
        //select state
        $('#year1').on('change',function() {
        var year1=$(this).val();
        if(year1){
            $.ajax({
                type:'POST',
                url:'get_ten1.php',
                data:'year1='+year1,   
                success:function (response) {
                    $('#disp').html(response);
                }
            });          
        }
        else{
            
        }
    	});
    });
</script>
</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>	
<div>
    <?php include 'admin_top_nav.php'; ?>
</div>
        <!-- /navbar -->
	<div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->
                    <div class="span9">
                    	<div class="content">
                    		<div class="module">
	                            <div class="module-head">
	                                <h3>Report</h3>
	                            </div>
              <div class="module-body">
                <div class="stream-composer media">
                                    
                    <form class="form-horizontal row-fluid" method="POST">
                        <div class="control-group">
                    		<div class="control-group" id="mark">
                    			<label class="control-label" for="basicinput">Year</label>
                                <div class="controls">
                                    <select name="year1" id="year1" data-placeholder="Select here.." class="span8" >
                                                    <option value="">Select here..</option>

                            <?php 
                                $sql="SELECT year FROM history order by year DESC";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['year'] ?>"><?php echo $row['year']; ?></option>
                                            <?php }
                                     }  ?>  
                                                </select>
                                            </div><br>
                                    <div id="disp">
                                    	<label class="control-label" for="basicinput">Companies Visited</label>
                                        <div class="controls">
                                            <input type="text" disabled id="company" class="span8" >
                                        </div><br>
                                        <label class="control-label" for="basicinput">B-Tech total placed</label>
                                        <div class="controls">
                                            <input type="text" disabled id="btech" class="span8">
                                        </div><br>
                                        <label class="control-label" for="basicinput">M-Tech total placed</label>
                                        <div class="controls">
                                            <input type="text"  disabled id="mtech" class="span8">
                                        </div><br>
                                        <label class="control-label" for="basicinput">MCA total placed</label>
                                        <div class="controls">
                                            <input type="text" disabled id="mca" class="span8" >
                                        </div><br>
                                        <label class="control-label" for="basicinput">Overall placed</label>
                                        <div class="controls">
                                            <input type="text" disabled id="tot" class="span8" >
                                        </div><br>
                                        <label class="control-label" for="basicinput">Registered Students</label>
                                        <div class="controls">
                                            <input type="text" disabled id="total" class="span8" >
                                        </div><br>';
                                    </div>    
                                        
                            </div> <!--mark-->
                          <input type="submit" name="submit" value="Refresh" class="btn btn-danger pull-right"> 
                        </div><!--ctrl-group-->

                    </form>
                </div><!--media-->
              </div><!--module body-->
                    		</div>   <!--module-->
                		</div>    <!--content-->
                    </div>   <!--span 9-->
                </div>
            </div>
            <!--/.container-->
        </div><!--/.wrapper-->

	<div class="footer">
		<div class="container">
			 
<b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
		</div>
	</div>

<?php
    include 'connection.php';
    include 'sweetalerttest.php';
   
    if(isset($_POST['submit'])){
        $yop=$_POST['year1'];
        $sql="SELECT count(notif_id) as comp_ct from notification where YOP=$yop";
        $result=mysqli_query($conn,$sql);
            if(mysqli_num_rows($result) > 0){
                $row2 = mysqli_fetch_array($result);
                $comp_ct=$row2['comp_ct'];
            }
            else{  $comp_ct=0;  }

        $sql="SELECT count(stud_id) as btec_ct from placed where Course='Btech' and YOP=$yop";
        $result=mysqli_query($conn,$sql);
            if(mysqli_num_rows($result) > 0){
                $row2 = mysqli_fetch_array($result);
                $btec_ct=$row2['btec_ct'];
            }
            else{  $btec_ct=0;  }

        $sql="SELECT count(stud_id) as mca_ct from placed where Course='MCA' and YOP=$yop";
        $result=mysqli_query($conn,$sql);
            if(mysqli_num_rows($result) > 0){
                $row2 = mysqli_fetch_array($result);
                $mca_ct=$row2['mca_ct'];
            }
            else{  $mca_ct=0;  }

        $sql="SELECT count(stud_id) as mtech_ct from placed where Course='Mtech' and YOP=$yop";
        $result=mysqli_query($conn,$sql);
            if(mysqli_num_rows($result) > 0){
                $row2 = mysqli_fetch_array($result);
                $mtech_ct=$row2['mtech_ct'];
            }
            else{  $mtech_ct=0;  }

        $total_ct=$mtech_ct+$mca_ct+$btec_ct;

        $sql="SELECT count(stud_id) as reg_stud from stud where year_of_pass=$yop";
        $result=mysqli_query($conn,$sql);
            if(mysqli_num_rows($result) > 0){
                $row2 = mysqli_fetch_array($result);
                $reg_stud=$row2['reg_stud'];
            }
            else{  $reg_stud=0;  }
            $college="Amal Jyothi college of Engineering";
        $sql="SELECT count(notif_id) as oncam_ct from notification where YOP=$yop and venue='$college'";
        $result=mysqli_query($conn,$sql);
            if(mysqli_num_rows($result) > 0){
                $row2 = mysqli_fetch_array($result);
                $oncam_ct=$row2['oncam_ct'];
            }
            else{  $oncam_ct=0;  }
        
        $sql="SELECT count(notif_id) as offcam_ct from notification where YOP=$yop and venue!='$college'";
        $result=mysqli_query($conn,$sql);
            if(mysqli_num_rows($result) > 0){
                $row2 = mysqli_fetch_array($result);
                $offcam_ct=$row2['offcam_ct'];
            }
            else{  $offcam_ct=0;  }

        $sql="Update history set
            company_count=$comp_ct,
            btech_count=$btec_ct,
            mca_count=$mca_ct,
            mtech_count=$mtech_ct,
            total_placed=$total_ct,
            registered_stud=$reg_stud,
            oncampus=$oncam_ct,
            ofcampus=$offcam_ct
            where `year`=$yop";

        $resu=mysqli_query($conn,$sql);
        if($resu){
        echo '<script>
            setTimeout(function() {
                swal({
                    title: "Refreshed Successfully..!",
                    text: "Check Again for Updates",
                    type: "success"
                }, function() {
                    // window.location = "task.php";
                });
            }, 1000);
        </script>';
     // echo"<script>alert('uigiug')</script>"; 
        }
    }
    if(isset($_POST['submit5'])){
        $tit=$_POST['title11'];
        if($tit==""){
            echo"<script>swal('Oops..','Fields are empty','warning')</script>";   
        }else{
            $sel="SELECT title from upload_title where title='$tit'";
            $result=mysqli_query($conn,$sel);
            if(mysqli_num_rows($result) > 0){
                echo"<script>";
                echo "swal('Oops...','Title already exist..!','error');";
                echo"</script>";
            }
            else{
                    $sql="INSERT into upload_title(title,status) values ('$tit',1)";
                    if ($conn->query($sql) === TRUE) 
                    {
                         echo '<script>
                            setTimeout(function() {
                                swal({
                                    title: "Upload Title Added !",
                                    text: "Successfully!",
                                    type: "success"
                                }, function() {
                                    window.location = "admin_home.php";
                                });
                            }, 1000);
                        </script>';
                                                
                            
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }
            }
    }
    if(isset($_POST['delete1'])){
        $title_id=$_POST['Organ1'];
        $sql="UPDATE upload_title set status=0 where title_id=$title_id";
        $resu=mysqli_query($conn,$sql);
        if($resu){
        echo '<script>
            setTimeout(function() {
                swal({
                    title: "Upload Title Deleted !",
                    text: "Successfully!",
                    type: "success"
                }, function() {
                    window.location = "task.php";
                });
            }, 1000);
        </script>';
     // echo"<script>alert('uigiug')</script>"; 
        }
    }
?>


	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('.table-message tbody tr').click(
				function() 
				{
					$(this).toggleClass('resolved');
				}
			);
		} );
	</script>
</body>