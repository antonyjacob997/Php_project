<!DOCTYPE html>
<html lang="en">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cam-RA</title>
        <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="css/theme.css" rel="stylesheet">
        <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
            rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
 <?php   
include 'connection.php';
include 'sweetalerttest.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: ../index.php");
    exit;
}else{
	if((isset($_GET['f'])==1)||(isset($_GET['f'])==2)){
		echo"<script>swal('feedback forwarded','successfully','success');</script>";
	}else if(isset($_GET['f'])==3){
		echo"<script>swal('feedback Deleted','successfully','success');</script>";
	}
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";
    $today = date("Y-m-d");
    // echo "<br>" . $date1 . "<br>";
    $qy="SELECT date1,notif_id from notification";
    $result=mysqli_query($conn,$qy);
    $f=0;
    if(mysqli_num_rows($result)>0)
        {
        while($row = $result->fetch_assoc()) { 
        $da=$row['date1'];
        if ($da < $today) 
            $f=$row['notif_id'];

          
    if($f!=0){
         $qry2="UPDATE notification set status = 0 where notif_id=$f";
         $res=mysqli_query($conn,$qry2);
       }
    }
  }
}
?>
<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->



 <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->


				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Student Feedback</h3>
							</div>
							<div class="module-body">
								

								<div class="stream-list">
									<!-- <div class="media stream new-update">
										<a href="#">
											<i class="icon-refresh shaded"></i>
											11 updates
										</a>
									</div> -->
	<?php 
		$sql="SELECT feedback_id,Full_Name,org,feedback,date1 FROM feedback,stud WHERE feedback.status=1 and feedback.stud_id=stud.stud_id order by date1 DESC";
		$result1=mysqli_query($conn,$sql);
		if(mysqli_num_rows($result1)>0)
        {
	        while($row = mysqli_fetch_array($result1)){
	        	$name1=$row['Full_Name'];
	        	$date1=$row['date1'];
	        	$org=$row['org'];
	        	$feed=$row['feedback'];
	   			$feedback_id=$row['feedback_id'];
	?>
									<div class="media stream">
										<a href="#" class="media-avatar medium pull-left">
											
										</a>
										<div class="media-body">
											<div class="stream-headline">
												<h5 class="stream-author">
													<?php echo"$name1"; ?> 
													<small><?php echo"$date1"; ?></small>
												</h5>
												<h3>
													<small><b><?php echo"$org"; ?></b></small>
												</h3>
												<div class="stream-text">
													 <?php echo"$feed"; ?>
                                                </div>
												
											</div><!--/.stream-headline-->

											<div class="stream-options">
												
												<a href="forward_feedback.php?feedback_id=<?php echo $feedback_id ?>" class="btn btn-small">
													<i class="icon-retwet shaded"></i>
													Forward
												</a>
												<a href="delete_feedback.php?feedback_id=<?php echo $feedback_id ?>" class="btn btn-small">
													<i class="icon-del shaded"></i>
													Delete
												</a>
											</div>
										</div>
									</div><!--/.media .stream-->
	<?php 
			}
    	}
	?>							
								</div><!--/.stream-list-->
							</div><!--/.module-body-->
						</div><!--/.module-->
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->

    <div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>
        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    </body>