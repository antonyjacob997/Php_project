<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>

	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="myscript.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>	
<div>
    <?php include 'admin_top_nav.php'; ?>
</div>
        <!-- /navbar -->
	<div class="wrapper" style="background-color: #101820ff">
		<div class="container">
			<div class="row">
				<div class="module module-login span8 offset2">
					<form class="form-vertical" method="post">
						<div class="module-head">
							<h3>Confirm Password</h3>
						</div>
						<div class="module-body">
							
							<div class="control-group"><br><br>
								<div class="controls row-fluid offset1">
									<input class="span8" name="password" type="password" id="inputPassword" placeholder="Password">
								</div><br><br>
							</div>
						</div>
						<div class="module-foot">
							<div class="control-group">
								<div class="controls clearfix">
									<button type="submit" name="submit" style="width: 20%" class="btn btn-success offset3">Login</button>
									
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div><br><br><br><br>
	</div><!--/.wrapper--><br><br>

	<div class="footer">
		<div class="container">
			 
<b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
		</div>
	</div>

<?php
    include 'connection.php';
    include 'sweetalerttest.php';
    if(isset($_POST['submit'])){
    	
    	$password=md5($_POST['password']);
    	
    		$sel="select * from login where login_id='$id' and password='$password'";
        	$result=mysqli_query($conn,$sel);
            if(mysqli_num_rows($result) > 0){
             	echo"<script>window.location('new_admin.php');</script>";
             	header("location:new_admin2.php");
            }
	    	else {  
	    		echo"<script>swal('Sorry..','Wrong Password','error')</script>";
		}
    }
?>
	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('.table-message tbody tr').click(
				function() 
				{
					$(this).toggleClass('resolved');
				}
			);
		} );
	</script>
</body>