<?php
include 'connection.php';

if(!empty($_POST['course'])){
	$c=$_POST['course'];
	if($c==2){
		$course="MCA";
	}
	else{
		$course="Btech";
	}
	$qry="SELECT * from department where course='$course'";
	// echo"<script>alert('".$course."')</script>";
	$result=mysqli_query($conn,$qry);
	if(mysqli_num_rows($result) > 0){
		echo'<option value=""> select Department</option>';
        while($row = mysqli_fetch_array($result)) {                              
            echo"<option value=".$row['dept_id'].">".$row['department_name']."</option>";
         }   
    }                                
                                    
}

?>
