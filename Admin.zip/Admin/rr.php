<?php
    // not working duplicat record is created
$sql="CREATE view stud_list as( SELECT distinct 
t1.stud_id, 
t1.University_Reg_No, 
t1.Full_Name, 
t1.Placed,  
t4.department_name, 
t1.Mobile, 
t1.Alt_Mobile, 
t1.Alt_Email, 
t1.DoB, 
t1.Gender, 
t1.Father_Name, 
t1.Mother_Name, 
t1.House_Name, 
t1.Street, 
t1.City, 
t6.dist_name, 
t7.state_name, 
t1.Pincode, 
t5.country_name, 
t1.login_id, 
t1.course,
t1.year_of_pass,
t3.email, 
t2.academic_id, 
t2.Aggr_CGPA as Aggrigate_CGPA, 
t2.Aggr_Percentage as Aggrigate_Percentage, 
t2.CURRENT_ARREARS as Current_Arrears, 
t2.HISTORY_OF_ARREARS as History_of_Arrears, 
t2.10th_p as Tenth_Percentage, 
t2.10th_CGPA as Tenth_CGPA, 
t2.10th_YoP as Tenth_Year_of_pass, 
t2.10th_Board as Tenth_Board, 
t2.10th_School as Tenth_School_Name, 
t2.10th_State_of_school as Tenth_state_of_School, 
t2.12th_p as Twelfth_Percentage, 
t2.12th_CGPA as Twelfth_CGPA, 
t2.12th_YoP as Twelfth_Year_of_pass, 
t2.12th_Board as Twelfth_Board, 
t2.12th_School as Twelfth_School_Name, 
t2.12th_State_of_School as Twelfth_state_of_School, 
t2.UG_Course, 
t2.UG_P as UG_Percentage, 
t2.UG_CGPA , 
t2.UG_YoP as UG_Year_of_pass, 
t2.UG_College, 
t2.state_of_UG, 
t2.UG_University, 
t2.PG_University, 
t2.Technical_Skills, 
t2.Work_Experience, 
t2.Certifications, 
t2.Internships
    from stud t1,academic t2,login t3,department t4,country t5,district t6,state t7
    where t1.login_id=t3.login_id
    and t1.stud_id=t2.stud_id
    and t1.state_id=t7.state_id
    and t1.dept_id=t4.dept_id
    and t1.country_id=t5.country_id
    and t1.dist_id=t6.dist_id)  


"

"

SELECT stud.Full_Name,department.department_name,organization.Org,job_notification.Date1,job_notification.Venue from  job_notification
where drive_reg.job_id=job_notification.job_id and 
      stud.stud_id=drive_reg.stud_id 



SELECT Full_Name 


SELECT University_Reg_No,Full_Name,department_name,Alt_Email,Mobile from stud,department where department_name in(SELECT department_name from department where department.dept_id=stud.dept_id);

SELECT stud.Full_Name,department.department_name,organization.Org,job_notification.Date1,job_notification.Venue from  drive_reg
JOIN job_notification on drive_reg.job_id=job_notification.job_id
JOIN stud on drive_reg.stud_id=stud.stud_id
JOIN department on department.dept_id=stud.dept_id
JOIN organization on job_notification.org_id=organization.Org

SELECT stud.Full_Name,department.department_name,organization.Org,job_notification.Date1,job_notification.Venue
FROM drive_reg
JOIN job_notification ON drive_reg.job_id = job_notification.job_id
JOIN stud ON drive_reg.stud_id = stud.stud_id
JOIN department ON department.dept_id = stud.dept_id
JOIN organization ON job_notification.org_id = organization.Org


SELECT * from notification where notif_id in(SELECT notif_id from drive_elig where stud_id=$stud)


SELECT org_id,date1,venue,Full_Name,dept_id from notification,stud where notif_id in(SELECT DISTINCT notif_id from drive_reg) and stud_id in(SELECT DISTINCT stud_id from drive_reg)



SELECT notif_id from notification where org_id=$organization and date1='$date1'

SELECT stud_id from stud_info where 10th_p >= $Per_ten and 12th_p >= $Per_twe and UG_CGPA >= $Per_deg and CURRENT_ARREARS <= $backlog


create table stud(
stud_id int Primary key AUTO_INCREMENT,
University Reg.No varchar(15),
Title varchar(5),
First_Name varchar(15),
Middle_Name varchar(15),
Last_Name varchar(15),
Full_Name varchar(50),
Placed varchar(10),
Branch varchar(30),
Mobile varchar(15),
Alt_Mobile varchar(15),
Email varchar(30),
Alt_Email varchar(30),
DoB varchar(15),
Gender varchar(15),
Father's_Name varchar(20),
Mother's_Name varchar(20),
House_Name varchar(30),
Street varchar(30),
City varchar(30),
District varchar(30),
State varchar(30),
Pincode varchar(30),
Nationality varchar(30));

create table academic(
academic_id int Primary key AUTO_INCREMENT,
stud_id int,
Aggr_CGPA varchar(5),
Aggr_Percentage varchar(4),
CURRENT_ARREARS int (2),
HISTORY_OF_ARREARS varchar(100),
10th_p varchar(5),
10th_CGPA varchar(6),
10th_YoP varchar(5),
10th_Board varchar(30),
10th_School varchar(30),
10th_State_of_school int,
12th_p varchar(30),
12th_CGPA varchar(5),
12th_YoP varchar(30),
12th_Board varchar(30),
12th_School varchar(30),
12th_State_of_School int,
UG_Course varchar(30),
UG_P varchar(6),
UG_CGPA varchar(6),
UG_YoP varchar(6),
UG_College varchar(30),
state_of_UG varchar(30),
UG_University varchar(30),
PG_University varchar(30),
Technical_Skills varchar(100),
Work_Experience varchar(100),
Certifications varchar(100),
Internships varchar(100)
);

create table Job_Notification(
job_id int Primary Key Auto_increment,
Organization varchar(30),
Eligible_Branches varchar(30),
Criteria varchar(30),
Date varchar(26),
Venue varchar(30),
Placed int,
Registered int,
Absentees int,
Shortlisted int,
Designation_id int,
CTC int,
Rounds int);

create table designation(
Designation_id int Primary Key Auto_increment,
Designation varchar(30));

create table other_notification(
notif_id int Primary Key Auto_increment,
description varchar(100),
date varchar(15)
);

create table Eligible_branch(
El_branch_id int Primary Key Auto_increment,
job_id int,
branch varchar(300),
designation varchar(100),
rounds varchar(200)
);
create table organization(
org_id int Primary Key Auto_increment,
organization varchar(30)
);

CREATE VIEW stud_info AS SELECT
t1.stud_id,
t1.University_Reg_No,
t1.Full_Name,
t1.Placed,
t1.dept_id,
t1.Mobile,
t1.Alt_Mobile,
t1.Alt_Email,
t1.DoB,
t1.Gender,
t1.Father_Name,
t1.Mother_Name,
t1.House_Name,
t1.Street,
t1.City,
t1.dist_id,
t1.state_id,
t1.Pincode,
t1.country_id,
t1.login_id,
t1.course,
t1.year_of_pass,
t2.email,
t3.academic_id,
t3.Aggr_CGPA,
t3.Aggr_Percentage,
t3.CURRENT_ARREARS,
t3.HISTORY_OF_ARREARS,
t3.10th_p,
t3.10th_CGPA,
t3.10th_YoP,
t3.10th_Board,
t3.10th_School,
t3.10th_State_of_school,
t3.12th_p,
t3.12th_CGPA,
t3.12th_YoP,
t3.12th_Board,
t3.12th_School,
t3.12th_State_of_School,
t3.UG_Course,
t3.UG_P,
t3.UG_CGPA,
t3.UG_YoP,
t3.UG_College,
t3.state_of_UG,
t3.UG_University,
t3.PG_University,
t3.Technical_Skills,
t3.Work_Experience,
t3.Certifications,
t3.Internships
FROM stud t1, login t2, academic t3
WHERE t1.login_id=t2.login_id and t1.stud_id=t3.stud_id


CREATE VIEW V_REGION_SALES
AS SELECT A1.Region_Name REGION, SUM(A2.Sales) SALES
FROM Geography A1, Store_Information A2
WHERE A1.Store_Name = A2.Store_Name
GROUP BY A1.Region_Name;


placed on which company...?
update status...
payment...

......razorpay.....

key id=rzp_live_q76kGKn94LKWic
secret key=uDVmmJeaEkqvh9Uw3vV38sDz


test mode

key=rzp_test_sxHbFmjiohuHvc

secret key=pyNTenby48oHmZzIg2zidgHP
