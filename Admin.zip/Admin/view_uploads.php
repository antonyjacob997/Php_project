<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; char et=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cam-RA</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <!--  <script type="text/javascript" src="myscript.js"></script>  -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
	<script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
  <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <script type="text/javascript">
		$(document).ready(function(){
			$("#search").on('change',function()
			{
				var opt=$(this).val();
				if(opt=="Gender"){
            		
					    $("#gend").show();
					    $("#sea").hide();
					    // $('#tit').show();
					    $("#field2").hide();
					   document.getElementById('gend').value="";				
				} else if(opt=="dept_id"){
					$("#gend").hide();						
					    $("#field2").show();
					    // $('#tit').show();
		             	// $('#disp').hide();
		             	$("#sea").hide();
		             	document.getElementById('dept_id').value="";
				}
				else {

						$("#gend").hide();						
					    $("#sea").show();
					    // $('#tit').show();
		             // $('#disp').hide();
		             $("#field2").hide();
					 document.getElementById('sea').value="";  
				} 
				
			});
		});
	</script>
	<style >
		td.hover{
			background-color: #aff0ba;
		}
	</style>

</head>
<body>
<?php   
include 'connection.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";

}
?>

<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->

	<div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                            <!--/.widget-nav-->

					</div><!--/.sidebar-->
				</div><!--/.span3-->


				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>View Student Uploads</h3>
							</div>
							<div class="module-body">
									<form class="form-horizontal row-fluid" method="POST">
										
	
                                
                                <div class="control-group" id="comp" hidden="hide">
                                <label class="control-label">Companies</label>
                                            	<div class="controls">
                                            		<table>
                                                	<?php 
				
													    $sql="select org_id,Org from organization";
													    $result=mysqli_query($conn,$sql);
													    if(mysqli_num_rows($result) > 0){
													    	$i=0;
													         while($row = mysqli_fetch_array($result)) {
													         	echo "<td>";
													         	if($i<2){
													           ?>
                
                                                <label class="checkbox">
                                                    <input type="checkbox" name="Branch[]" value="<?php echo $row['Org'] ?>">
                                                    <?php echo $row['Org']; ?>
                                                </label>
                                                
												             <?php
												             	$i=$i+1;
												             	echo"</td>";
												             }
												             else{$i=0;
												             	echo"</td></tr>";
												             }
												            }
												        }  ?>
												    </table>
                                            </div>
                                        </div>
                            <form method="post">    
                                <div class="control-group" id="mark">
										
                                <br>
                                    <select id="search"  name="search" id="filter" data-placeholder="Search By" class="span8" style="width: 35%;margin-left: 10%">
                                        <option value="">Search By</option>
                                        <option value="University_reg_no">University reg no</option>
                                        <option value="Full_Name">Student Name</option>
                                        <option value="dept_id">Department</option>
                                        <option value="Gender">Gender</option>
                                    </select>
                                            
											<!-- <div class="controls"> -->
                                                
                                    <select id="gend"  name="Gender" style="display: none;margin-left: 10%;width: 35%">
                                    				<option value="">Choose</option>
                                                	<option value="Male">Male</option>
                                                	<option value="Female">Female</option>
                                                	<option value="Others">Other</option>
                                    </select>
                                    
									<select name="dept" id="field2" class="form-control" style="display: none;margin-left: 10%;width: 35%">
														<option value="">Search</option>

                                            <?php 
                                                $sql="SELECT * FROM department where chk=1 order by department_name ASC";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['dept_id'] ?>"><?php echo $row['department_name']; ?></option>

                                            <?php }
                                     }  ?>  
									</select>
									
                                    <input type="text" placeholder="Search" id="sea" name="sea" style="margin-left: 10%;width: 35%">
                                    <input type="submit" name="submit" value="Search">
                                         <br> <br>
										</div>
							</form>
                                <div class="module-body">
                                <div style="overflow-x:auto;overflow-y:auto;">
                                <table class="table" style="width: 1200px" >
								  <thead id="tit" style="background-color:#cbd1cc">
									<tr>
									  <th>SL.No</th>
									  <th>University reg no</th>
									  <th>Full Name</th>
									  <th>Department</th>
									  <th colspan="5" style="text-align: center">Uploads</th>
									 
									</tr>
								  </thead> <?php
							   if(isset($_POST['submit'])){

							   	   $search=$_POST['search'];
							   	   $gender=$_POST['Gender'];
							   	   $dept=$_POST['dept'];
							   	   $sea=$_POST['sea'];
							   	   if(($sea=="")and($dept=="")and($search=="")and($gender=="")){
							   	   		$sql="SELECT * from stud_info";
										$result=mysqli_query($conn,$sql);
										
							   	   	}
							   	   elseif(($sea=="")and($dept=="")){
								   	   $sql="SELECT * from stud_info where ". $search."='$gender'";
								   	   $result=mysqli_query($conn,$sql);
								   	   
								   	}
							   	   else if(($sea=="")and($gender=="")){
							   	   			$sql="SELECT * FROM stud_info WHERE dept_id ='$dept'";
							   	   			$result=mysqli_query($conn,$sql);
							   	   			
							   	   		}
							   	   	else if(($dept=="")and($gender=="")){
								   	   	  $sql="SELECT * from stud_info where ". $search." like '%$sea%'";
								   	   	  $result=mysqli_query($conn,$sql);
								   	   	  
							   	   	}  
							   }
							   else{
									$sql="SELECT * from stud_info";
									$result=mysqli_query($conn,$sql);
									
								}
							if(mysqli_num_rows($result)<1){
								?>
								<tr class="odd gradeX">

										<td colspan="10"><h3 style="margin-left: 30%"><?php echo "No search Result Found" ?><h3></td>
								<?php
							}else{
							$i=0;
							while($row=mysqli_fetch_array($result)){;
								$i=$i+1;
								
								  	$stud_id=$row["stud_id"];
								  	$qry1="SELECT upload_id,title,upload_name,stud_id from uploads,upload_title where stud_id='$stud_id' and uploads.title_id=upload_title.title_id and uploads.status=1";
								  
								  	$res=mysqli_query($conn,$qry1);
								  	?>
									 <tr class="odd gradeX">

										<td><?php echo  $i;?></td>
				                     	<td>
				                            <?php echo  $row["University_Reg_No"];?>
				                        </td>
				                        <td>
				                            <?php echo  $row["Full_Name"];?>
				                        </td>
				                        <?php  
				                        	$dept_id=$row['dept_id'];
				                        	$sql2="SELECT department_name FROM department where dept_id='$dept_id'";
                                                $result2=mysqli_query($conn,$sql2);
                                                $row2=mysqli_fetch_array($result2);
				                        ?>
				                        <td>
				                            <?php echo  $row2["department_name"];?>
				                        </td>
				                        <?php 
				                        	if(mysqli_num_rows($res)>0){
					                            while ($row1=mysqli_fetch_array($res)) {    	?>
					                            	<td><a href="../User/uploads/<?php echo $row1['upload_name']; ?>" target="_blank"><?php echo $row1['title'] ?></a></td>
				                        <?php
				                        		}
				                            }else{
				                            	echo"<td colspan='5'>Not Uploaded</td>";
				                            }
				                        ?>
				                        
				                    </tr> 
								  </tbody>
								<?php } } ?>
								
														
								</table>
								</div>
								<br>

											<br>
                                        	
                            
							</form>
							
						</div>
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
</div>
</div>


	<div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>

	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
</body>