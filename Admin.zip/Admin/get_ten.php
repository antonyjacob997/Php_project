<?php
include 'connection.php';

if(empty($_POST['per'])){
    $qry="SELECT * from stud_info";
}
    else{
	$c=$_POST['per'];
	$qry="SELECT * from stud_info where Gender='$c'";
}
	$result = $conn->query($qry);

            if(mysqli_num_rows($result) > 0){
            // output data of each row
            	?>
                <table>   
                          <thead>
                                    <tr>
                                      <th>SL.No</th>
                                      <th>University reg no</th>
                                      <th>Full Name</th>
                                      <th>mobile</th>
                                      <th>Alt mobile</th>
                                      <th>Email</th>
                                      <th>Alt Email</th>
                                      <th>Date of Birth</th>
                                      <th>Gender</th>
                                      <th>Father's Name</th>
                                      <th>Mother's Name</th>
                                      <th>House Name</th>
                                      <th>Street</th>
                                      <th>City</th>
                                      <th>District</th>
                                      <th>State</th>
                                      <th>Country</th>
                                      <th>Pincode</th>
                                      <th>Aggr_CGPA</th>
                                    <th>Aggr_Percentage</th>
                                    <th>CURRENT_ARREARS</th>
                                    <th>HISTORY_OF_ARREARS</th>
                                    <th>10th_p</th>
                                    <th>10th_CGPA</th>
                                    <th>10th_YoP </th>
                                    <th>10th_Board </th>
                                    <th>10th_School </th>
                                    <th>10th_State_of_school </th>
                                    <th>12th_p </th>
                                    <th>12th_CGPA </th>
                                    <th>12th_YoP </th>
                                    <th>12th_Board </th>
                                    <th>12th_School </th>
                                    <th>12th_State_of_School </th>
                                    <th>UG_Course </th>
                                    <th>UG_P </th>
                                    <th>UG_CGPA </th>
                                    <th>UG_YoP </th>
                                    <th>UG_College </th>
                                    <th>state_of_UG </th>
                                    <th>UG_University </th>
                                    <th>PG_University </th>
                                    <th>Technical_Skills </th>
                                    <th>Work_Experience </th>
                                    <th>Certifications </th>
                                    <th>Internships </th>
                                    </tr>
                                  </thead>    
                <?php

                $i=0;
                while($row = $result->fetch_assoc()) { $i=$i+1;?>

                            <tbody>               
                                <tr class="odd gradeX">
                     	                <td><?php echo  $i;?></td>
                                        <td>
                                            <?php echo  $row["University_Reg_No"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Full_Name"];?>
                                        </td>
                                        
                                        <td class="center">
                                            <?php echo  $row["Mobile"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Alt_Mobile"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["email"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Alt_Email"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["DoB"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Gender"];?>
                                        </td>
                                        
                                        <td class="center">
                                            <?php echo  $row["Father_Name"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Mother_Name"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["House_Name"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Street"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["City"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["dist_id"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["state_id"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["country_id"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Pincode"];?>
                                        </td>
                                        
                                        <td class="center">
                                            <?php echo  $row["Aggr_CGPA"];?>
                                        </td>
                                        
                                        <td>
                                            <?php echo  $row["Aggr_Percentage"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["CURRENT_ARREARS"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["HISTORY_OF_ARREARS"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["10th_p"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["10th_CGPA"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["10th_YoP"];?>
                                        </td>
                                        
                                        <td>
                                            <?php echo  $row["10th_Board"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["10th_School"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["10th_State_of_school"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["12th_p"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["12th_CGPA"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["12th_YoP"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["12th_Board"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["12th_School"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["12th_State_of_School"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["UG_Course"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["UG_P"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["UG_CGPA"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["UG_YoP"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["UG_College"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["state_of_UG"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["UG_University"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["PG_University"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Technical_Skills"];?>
                                        </td>
                                        <td>
                                            <?php echo  $row["Work_Experience"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["Certifications"];?>
                                        </td>
                                        <td class="center">
                                            <?php echo  $row["Internships"];?>
                                        </td>
                                        
                                    </tr>
                                
                <?php  } 
                       ?>
</tbody>
                                </table>  
                       <?php                   
                                    
}
else{

		echo "<script>";
		echo "alert('error')";
		echo "</script>";
     } 
?>

