<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cam-RA</title>
        <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="css/theme.css" rel="stylesheet">
        <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
            rel='stylesheet'>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
	$(document).ready(function(){
        $('#year').on('change',function () {
          var year=$(this).val();
          alert(year);
          if(year){
            $.ajax({
                type:'POST',
                url:'getyear.php',
                data:'year='+year,
                success:function (html) {
                    $('#disp').html(html);                }
            });          
        }
        else{
            //$('#depart').html('<option value="">Course first</option>');
            alert('faled');
        }
        })
	});
</script>

    </head>
    <body>
       <?php   
include 'connection.php';
include 'sweetalerttest.php';
session_start();
if(!isset($_SESSION["loggedin"])){
    header("location: index.php");
    exit;
}else{
    $id=$_SESSION["loggedin"] ;
    $qry="SELECT name from faculty where login_id='$id'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0)
        {
        $row = mysqli_fetch_array($result);
        $name=$row['name'];
    }
    $_SESSION["loggedin"] = "$id";
    $today = date("Y-m-d");
    // echo "<br>" . $date1 . "<br>";
    
  }

?>
<style type="text/css">
	
</style>
<div>
            <?php include 'admin_top_nav.php'; ?>
        </div>
        <!-- /navbar -->
 <div class="wrapper" style="background-color: #101820ff">
            <div class="container" >
                <div class="row" >
                    <div class="span3">
                        <div class="sidebar">
                            <?php include 'admin_nav.php'; ?>
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->
<!-- start here -->
<div class="span9" >
                    <div class="content">
                        <div class="module message">
                            <div class="module-head">
                                <h3>Placement Result</h3>
                            </div>

                    <form class="form-horizontal row-fluid" method="POST" enctype="multipart/form-data">
                            <div class="module-option clearfix">
                                <br>
                                <div class="control-group"><br>
                                    <label class="control-label" for="basicinput">Company</label>
                                <div class="controls">
                                    <select name="Organ" id="filter" data-placeholder="Select here.." required="required">
                                                    <option value="">Select here..</option>
                                                    <option value="Others">----------------------------------------   Add New   --------------------------------------------</option>

                            <?php 
                                $sql="SELECT * FROM organization where status=1";
                                $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result) > 0){
                                     while($row = mysqli_fetch_array($result)) {
                            ?>
                                            <option value="<?php echo $row['org_id'] ?>"><?php echo $row['Org']; ?></option>
                                            <?php }
                                     }  ?>  
                                     
                                    </select>
                                             
                                       
                                            <input placeholder="New Rules" required type="file" style="float: right;margin-right: 15%" name="rules" id="rules" onchange="fileCheck1(this)">
                                            
                                            <p id="op1" style="float: right;margin-right: 38%;color: red" name="rules" ></p>
                                        
                                          </div>  <br><br>
                                    <div class="controls">    
                                                                          
                                        <input type="submit" style="margin-right:5%;width: 125px;float:right;" name="submit" value="Upload Result" class="btn btn-primary">
                                        <br>
                                    </div>
                                </div>
<script type="text/javascript">
      function fileCheck1(obj) {
              var fileExtension = ['pdf'];
              if ($.inArray($(obj).val().split('.').pop().toLowerCase(), fileExtension) == -1)
              {
                   $("#op1").html('Only .pdf formats are allowed..!').fadeIn().delay(2000).fadeOut();
              document.getElementById('rules').value="";
            
           
              return false;
            }
              else
              {
                  $("#op1").html("");
                return true;
              }
          
      }
</script>
                                <div class="pull-right">
                                    
                                </div>
                            </div>
                             <div class="module-head">
                                <h3>Placement Result</h3>
                            </div>
                        <form class="form-horizontal row-fluid" method="POST" enctype="multipart/form-data">
                            <div class="module-option clearfix">
                                <br>
                                
                                 <div class="module-body table">
                                    <table class="table table-message">
                                        <thead>
                                            <tr class="heading">
                                    		<td>Sl.No</td><td>Company</td><td>Result</td><td>Delete</td></tr>
                                    	</thead>
                                    	<tbody>
                                    	<?php
                                        	$qry="SELECT result_id,result_doc,year,Org FROM result,organization WHERE result.status=1 and organization.org_id=result.org_id";
										    $result=mysqli_query($conn,$qry);
										    if(mysqli_num_rows($result) > 0){
										    	$p=1;
										    	
										        while($row = mysqli_fetch_array($result)){
										        	$doc=$row['result_doc'];
										        	$result_id=$row['result_id'];
										        	$res=$row['Org'];
										        	?>
										       		<tr><td><?php echo $p; ?></td><td><?php echo $res; ?></td><td><a href='results/<?php echo $doc; ?>' target='_blank'><?php echo $res; ?> drive final result</a></td>

                                                	<td><a href='getyear.php?result_id=<?php echo $result_id; ?>' ><i class='fa fa-trash' style='font-size:24px'></i></a></td></tr>

										       	<?php
										       		$p=$p+1;
												}
											}else{
												echo"<tr><td colspan='4'>No result to publish</td></tr>";
											}
										?>
										</tbody>
                                    </table>
                                </div>
                            </div>
                        
                    	</form>
                            
                        </div>
                        
                    </form>
                </div>
            </div>
<?php
    if(isset($_POST['submit'])){
        $org_id=$_POST['Organ'];
        $filename2=md5(date("Y/m/d")."-". date("h:i:sa"));
        $y=date("Y");
        
        $file2=$filename2.".pdf";
        move_uploaded_file($_FILES["rules"]["tmp_name"], "results/" . $file2);

        $qry="INSERT into result(org_id,result_doc,year,status)values($org_id,'$file2','$y',1)";
                    if ($conn->query($qry) === TRUE) 
                    { 
                        echo '<script>
                                setTimeout(function() {
                                    swal({
                                        title: "Result Uploaded!",
                                        text: "successfully...!",
                                        type: "success"
                                    }, function() {
                                        window.location = "placed.php";
                                    });
                                }, 1000)
                            </script>';
                    } 
                    else{
                    ?>
                        <script type="text/javascript">
                        
                        swal('Document Uploaded!', 'Failed...!', 'error')
                            </script>
                        <?php 
                }
    }
    ?>

<!-- end here -->

                    <div class="span9" style="float: right" >
                        <div class="content">
                            
                            <div class="module">
                                <div class="module-head">
                                    <h3>
                                        Placed Students
                                    </h3>
                                </div>
                                <div class="module-body table">
                                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped  display"width="100%">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Course</th>
                                                <th>Department</th>
                                                <th>Company</th>
                                                <th>Designation</th>
                                                <th>Year Of Pass</th>
                                            </tr>
                                        </thead>
                        <tbody>
                           <?php
    $sql="SELECT * FROM placed WHERE status=1";
    $result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) { ?>
    									
                                            <tr >
                                                <td >
                                                    <?php echo  $row["Name"];?>
                                                </td>
                                                <td >
                                                    <?php echo  $row["Course"];?>
                                                </td>
                                                <td >
                                                    <?php echo  $row["Department"];?>
                                                </td>
                                                <?php 
				                        $stid=$row["placed_id"];
				                        $result55=mysqli_query($conn,"SELECT Org from organization where org_id in(SELECT Company from placed WHERE placed_id=$stid)");
				                        if(mysqli_num_rows($result55)<1){
				                         	$company="Not Placed";
				                        }else{
				                        	$roww=mysqli_fetch_array($result55);
				                        	$company=$roww["Org"];
				                        }
				                        ?>
						                        <td>
						                            <?php echo  $company;?>
						                        </td>
                                                
                                                <td >
                                                    <?php echo  $row["Designation"];?>
                                                </td>
                                                <td >
                                                    <?php echo  $row["YOP"];?>
                                                </td>
                                                
                                            </tr>
                                              <?php 
												        }
												        
												   } 
												   echo"</tbody>";
												?>
                                        
                                    </table>
                                </div>
                            </div>
                            <!--/.module-->

                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
        <div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
            </div>
        </div>
        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="scripts/common.js" type="text/javascript"></script>

    </body>