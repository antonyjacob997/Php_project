<?php
	include 'connection.php';
	
		$feedback_id=$_GET['feedback_id'];


			$sql="UPDATE feedback set forward=1 where feedback_id=$feedback_id";
			$res=mysqli_query($conn,$sql);
		
		 header("location:view_feedback.php?f=2");
		 echo"<script>window.location('view_feedback.php?f=2')</script>";

	
	
?>