<!DOCTYPE html>
<html>
<head>
<style type="text/css">
    input{width:250px;height: 40px;border-radius: 5px}
    td{padding-top: 10px;margin-top: 20px;margin-left: 70px}
    tr{margin-top: 30px}
</style>
</head>
<body>
<?php  
  
?>
<br>
    <div class="wrapper" style="background-color: #5680E9;border-radius: 50px">
        <div class="container">
            

                <div class="span9" style="margin-left: 10%">
                    <div class="content">

                        <div class="module">
                            
                            <div class="module-body">
                                <div class="stream-composer media">
                                    <br><br>
        <form class="form-horizontal row-fluid" action="tenthform.php" method="POST">
          <table style="margin-left: 10%">
            <tr><td><label class="control-label" for="basicinput">University Register No</label></td>
              <td><input type="text"  disabled style="background-color:#5680E9;border: 0;width: 150px "></td>
              <td><input type="text" name="uni_no" value="reg number"  disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">Full Name</label></td><td></td>
              <td><input type="text" name="fname" id="fullname" value="First Name" disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">Father's Name</label></td><td></td>
              <td><input type="text" name="father" value="Father" disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">Mother's Name</label></td><td></td>
              <td><input type="text" name="mother" value="Mother"  disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">Address</label></td><td></td>
              <td><input type="text" name="address" value="Address"  disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">Place/village</label></td><td></td>
              <td><input type="text" name="place" value="Place"  disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">City</label></td><td></td>
              <td><input type="text" name="city" value="City"  disabled></td></tr>
              <tr><td><label class="control-label" for="basicinput">District</label></td><td></td>
              <td><input type="text" name="district" value="District" disabled></td></tr>
              <tr><td><label class="control-label" for="basicinput">State</label></td><td></td>
              <td><input type="text" name="state" value="State" disabled></td></tr>
              <tr><td><label class="control-label" for="basicinput">Country</label></td><td></td>
              <td><input type="text" name="Country" value="Country" disabled></td></tr> 
            <tr><td><label class="control-label" for="basicinput">Date of Birth</label></td><td></td>
              <td><input type="text" name="dob" value="DOB" disabled></td></tr>
            <tr><td><label class="control-label">Gender</label></td><td></td>
              <td><input type="text" name="gender" value="Male"  disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">Department</label></td><td></td>
              <td><input type="text" name="department" value="Department"  disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">Mobile no</label></td><td></td>
              <td><input type="text" name="mobile" value="mobile"  disabled></td></tr>
            <tr><td><label class="control-label" for="basicinput">alternate mob no</label></td><td></td>
              <td><input type="text" name="mobile2" value="mobile"  disabled></td></tr><tr>
                <td><input type="text"  disabled style="background-color:#5680E9;border: 0;width: 150px "></td>
              </tr>
          
                                <tr><td>
                                    <input type="submit" name="submit" value="Save and Continue" class="btn btn-primary ">  </td><td></td><td>    
                                    <a href="index.php"style="width:250px;height: 40px;border-radius: 5px" class="btn btn-primary ">
                                                Cancel
                                    </a></td></tr>
                                </div>
            </table>
                                <br><br>
                            </form>
                            </div>
                            </div>

                        </div><!--/.module-->
                        
                    </div><!--/.content-->
                </div><!--/.span9-->
            </div>
        </div><!--/.container-->
    </div><!--/.wrapper-->

    <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>