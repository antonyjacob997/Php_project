<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Cam-RA </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="stylesheet" type="text/css" href="mystyle.css">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="copy/fonts/icomoon/style.css">

    <link rel="stylesheet" href="copy/css/bootstrap.min.css">
    <link rel="stylesheet" href="copy/css/jquery-ui.css">
    <link rel="stylesheet" href="copy/css/owl.carousel.min.css">
    <link rel="stylesheet" href="copy/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="copy/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="copy/css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="copy/css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="copy/fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="copy/css/aos.css">
    <script type="text/javascript" src="myscript.js"></script>
    <link rel="stylesheet" href="copy/css/style.css">
    
  </head>
  <?php
// Initialize the session
session_start();
 
// Unset all of the session variables
$_SESSION = array();
 
// Destroy the session.
session_destroy();
 
?>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
      
      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo mr-auto w-25"><a href="index.php">Cam-RA</a></div>

          <div class="mx-auto text-center">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mx-auto d-none d-lg-block  m-0 p-0">
                <li><a href="index.php" class="nav-link">Home</a></li>
                <li><a href="index.php#courses-section" class="nav-link">Companies</a></li>
                <li><a href="index.php#teachers-section" class="nav-link">Placement Cell</a></li>
              </ul>

              </nav>
          </div>

          <div class="ml-auto w-25">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu site-menu-dark js-clone-nav mr-auto d-none d-lg-block m-0 p-0">
                
                <li class="dropdown" class="cta"><a href="#" class="dropdown-toggle" class="nav-link" data-toggle="dropdown">Register
                                <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    
                                    <li><a href="registration.php">Student</a></li>
                                    
                                </ul>
              </ul>
              <ul class="nav pull-right">
                            
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black float-right"><span class="icon-menu h3"></span></a>
          </div>
        </div>
      </div>
      
    </header>

    <div class="intro-section" id="home-section">
      
      <div class="slide-1" style="background-image: url('images/hero_1.jpg');" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-12">
              <div class="row align-items-center">
                <div class="col-lg-6 mb-4">
                  <!-- <h1  data-aos="fade-up" data-aos-delay="100">Learn From The Expert</h1>
                  <p class="mb-4"  data-aos="fade-up" data-aos-delay="200">Department of Placement and Training caters for enhancing not only the employability skills of the passing out Amalites but also the overall development of their personality. The dept. organizes on campus and off campus recruitments and pre-placement training programmes through Aptitude tests, Group Discussions, Interviews and presentation skills in collaboration with the Dept. of Humanities and core departments.</p> -->
                  

                </div>

                <div class="col-lg-5 ml-auto" data-aos="fade-up" data-aos-delay="500">
                  <body>
  <div id="form_container" style="width: 400px">
    <h2 id="title">Forgot Password</h2>
    <form id="form" accept-charset="UTF-8" action="forget_action.php" method="post" class="form-box" >
      
      <ul class="errorMessages"></ul>
      
      
      <div class="form-group">
                      <input  id="fname" type="email" class="form-control" name="email" placeholder="Email Address" required="required" autocomplete="off" onblur="requiredField(this)">
                    </div>
      
      
      <div class="form-group">
                      <input type="submit" class="btn btn-primary btn-pill" value="send new Password">
                    </div>

    </form>
  </div>
</body>

                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>

<div class="wrapper" style="background-color: grey">    
  <div class="footer">
    <div class="container" >  <br><br>
      <p style="color: white">
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by Cam-RA
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      </p>
    </div>
    </div><br>
  </div>
  
    
 <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>