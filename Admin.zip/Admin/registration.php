<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cam-RA</title>
    <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
    <link type="text/css" href="css/theme.css" rel="stylesheet">
    <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
    <link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script> 
    <script type="text/javascript" src="https://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        
        //select course
        $('#course3').on('change',function () {
          var course=$(this).val();
          if(course){
            $.ajax({
                type:'POST',
                url:'getcourse.php',
                data:'course='+course,
                success:function (html) {
                    $('#depart').html(html);
                }
            });          
        }
        else{
            $('#depart').html('<option value="">Course first</option>');
        }
        })

        //select state

        $('#country').on('change',function() {
        var countryid=$(this).val();
        if(countryid){
            $.ajax({
                type:'POST',
                url:'getState.php',
                data:'countryid='+countryid,
                success:function (html) {
                    $('#state').html(html);
                }
            });          
        }
        else{
            $('#state').html('<option value="">country first</option>');
        }
    });
        //select district

        $('#state').on('change',function(){
        var stateid=$(this).val();
        if(stateid){
            $.ajax({


              
                type:'POST',
                url:'getCity.php',
                data:'stateid='+stateid,
                success:function (html) {
                    $('#city').html(html);
                }
            });          
        }
        else{
            $('#city').html('<option value="">select state first</option>');
        }
    });
});

</script>


</head>
<body>


    <?php   
    session_start();
    include 'connection.php';
    include 'reg_nav.php';
    $Year=date("Y");
    ?>

    <div class="wrapper">
        <div class="container">
            <div class="row">
                <div class="span3">


                    </div><!--/.sidebar-->
                </div><!--/.span3-->

                <div class="span9" style="margin-left: 10%">
                    <div class="content">

                        <div class="module">
                            <div class="module-head">
                                <h1>Create Account</h1>
                            </div>
                            <div class="module-body">
                                <div class="stream-composer media">
                                    <br><br>
                    <form class="form-horizontal row-fluid" action="process.php" method="POST">
                                <div class="control-group"><br>
                                            <label class="control-label" for="basicinput">University Register No</label>
                                    <div class="controls">
                                        <input type="text" name="uni_no" id="uni_non" placeholder="University Registeration number" minlength="13" maxlength="13" class="span8" onchange="alpha(this);" required="required" autocomplete="of"><span style="color: red">*</span>
                                        <label class="errortext" style="display:none; color:red" id="consumerno12"></label>
                                        <script>
                                              function alpha(input)
                                              {
                                                  var val = document.getElementById('uni_non').value;
                                                  if (!val.match(/^[A-Za-z0-9_-][A-Za-z0-9_-]{12,12}$/))
                                                  {
                                                  $("#consumerno12").html('Must.13 characters and Only Alphabets,hyphen and numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('uni_non').value = "";
                                                  input.style.borderColor = "#e74c3c";
                                                  document.getElementById('uni_non').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>      
                                            </div><br>
                                            <label class="control-label" for="basicinput">Pass out Year</label>
                                            <div class="controls">
                                                <select name="YOP" class="span8" required>
                                                  <option value="">Choose</option>
                                                  <option value="<?php echo $Year; ?>"><?php echo $Year; ?></option>
                                                  <option value="<?php echo $Year+1; ?>"><?php echo $Year+1; ?></option>
                                                  <option value="<?php echo $Year+2; ?>"><?php echo $Year+2; ?></option>
                                                </select>
                                                <label class="errortext" style="display:none; color:red" id="Year"></label>
                                            </div><br>
                                        </div>
                            <div class="control-group">
                                <label class="control-label" for="basicinput">Full Name</label>
                                    <div class="controls">
                                            <select name="title" required="required" style="width: 10%">
                                                    <option value="">Title</option>
                                                    <option value="Mr">Mr</option>
                                                    <option value="Ms">Ms</option>
                                            </select>
                                        <input type="text" name="fname" id="fullname" placeholder="First Name" class="span8" style="width: 18%" onchange="Validatename(this);" required="required" autocomplete="of">
                                        <input type="text" name="mname" id="mname" placeholder="Middle Name" class="span8" style="width: 18%" onchange="Validatename9(this)">  
                                        <input type="text" name="lname" id="fullname2" placeholder="Last Name" class="span8" style="width: 18%" onchange="Validatename2(this)" required="required">  <span style="color: red">*</span>
                                        <label class="errortext" style="display:none; color:red" id="name_l"></label><br>
                                           <script>
                                        function Validatename(input)
                                            {
                                                  var val = document.getElementById('fullname').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z]{2,}$/))
                                                  {
                                                      $("#name_l").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('fullname').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('fullname').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              function Validatename9(input)
                                            {
                                                  
                                                  var val2= document.getElementById('mname').value;
                                                  if (!val2.match(/^[A-Za-z][A-Za-z" "]{0,}$/))
                                                  {
                                                      $("#name_l").html(' Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('mname').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('mname').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        function Validatename2(input)
                                            {
                                                  
                                                  var val2= document.getElementById('fullname2').value;
                                                  if (!val2.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_l").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('fullname2').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('fullname2').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>                                          
                                    </div>
                                </div>
                                        <div class="control-group"><br>
                                            <label class="control-label" for="basicinput">Father's Name</label>
                                            <div class="controls">
                                                <input type="text" name="father" id="father" placeholder="Father's Name" class="span8" onchange="Validatename3(this)" required="required" autocomplete="of"><span style="color: red">*</span>
                                                <label class="errortext" style="display:none; color:red" id="name_2"></label><br>
                                           <script>
                                        function Validatename3(input)
                                            {
                                                  var val = document.getElementById('father').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_2").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('father').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('father').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>                                               
                                            </div><BR>
                                            <label class="control-label" for="basicinput">Mother's Name</label>
                                            <div class="controls">
                                                <input type="text" name="mother" id="mother" placeholder="Mother's Name" class="span8" onchange="Validatename4(this)" required="required" autocomplete="off"><span style="color: red">*</span>
                                                <label class="errortext" style="display:none; color:red" id="name_3"></label><br>
                                           <script>
                                        function Validatename4(input)
                                            {
                                                  var val = document.getElementById('mother').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_3").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('mother').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('mother').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>
                                            </div>
                                        </div>
                                <div class="control-group"><br>
                                <label class="control-label" for="basicinput">Address</label>
                                    <div class="controls">
                                        <input type="text" name="address" id="address" placeholder="House No/House Name" class="span8" autocomplete="off" onchange="alpha2(this)" required="required"><span style="color: red">*</span>
                                        <label class="errortext" style="display:none; color:red" id="consumerno1"></label>
                                        <script>
                                              function alpha2(input)
                                              {
                                                  var val = document.getElementById('address').value;
                                                  if (!val.match(/^[A-Za-z0-9" "_-][A-Za-z0-9" "_-]*$/))
                                                  {
                                                  $("#consumerno1").html('Only alphabet hypen and Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('address').value = "";
                                                  input.style.borderColor = "#e74c3c";
                                                  document.getElementById('address').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>                                                
                                    </div>
                                <br>
                                <div class="control-group">
                                <label class="control-label" for="basicinput"></label>
                                    <div class="controls">
                                        <input type="text" name="place" id="place" placeholder="Place/village" class="span8" style="width: 21%" onchange="Validateaddress(this)" required="required"> 
                                        <input type="text" name="city" id="city1" placeholder="City" class="span8" style="width: 22%" onchange="Validateadd(this)" required="required">
                                        <input type="text" name="pincode" id="pin" placeholder="Pincode" class="span8" style="width: 22%" onchange="Validatepin(this)" required="required"><span style="color: red">*</span>
                                        <label class="errortext" style="display:none; color:red" id="addr"></label><br>
                                           <script>
                                        function Validateaddress(input)
                                            {
                                                  var val = document.getElementById('place').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{3,}$/))
                                                  {
                                                      $("#addr").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('place').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('place').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                        function Validateadd(input)
                                            {
                                                  var val = document.getElementById('city1').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{3,}$/))
                                                  {
                                                      $("#addr").html('Min. 3 and Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('city1').value = "";
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('city1').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              function Validatepin(input)
                                              {
                                                  var val = document.getElementById('pin').value;
                                                  if (!val.match(/^[6-6][8-8][0-9]{4}$/))
                                                  {
                                                  $("#addr").html('Must. 6 and Only Numbers Allowed..! and Starts with 68').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('pin').value = "";
                                                  input.style.borderColor = "#e74c3c";
                                                  document.getElementById('pin').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return true;
                                              }
                                              </script>

                                    </div>
                                <br>

                        <div class="control-group">
                            <label class="control-label" for="basicinput"></label>
                            <div class="controls">
                            <select name="country" id="country" class="span8" style="width: 21%" required="required">
                                                    <option value="">Country</option>

                                            <?php 
                                                $sql="SELECT * FROM country";
                                                $result=mysqli_query($conn,$sql);
                                                if(mysqli_num_rows($result) > 0){
                                                     while($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['country_id'] ?>"><?php echo $row['country_name']; ?></option>
                                            <?php }
                                     }  ?>  
                                                </select>
                                            
                                            
                        <select name="state" id="state" class="span8" style="width: 22%" required="required">
                                    <option value="">Select country first</option></select>
                        <select name="dist" id="city" class="span8" style="width: 22%" required="required">
                                    <option value="">Select state first</option></select><span style="color: red">*</span>
                                             </div>
                                        <br>
                                        </div>
                                        <div class="control-group"><br>
                                             <label class="control-label" for="basicinput">Date of Birth</label>
                                             <div class="controls">
                                              <?php 
                                              $minyear=date("Y")-28;
                                              $maxyear = date("Y")-18;
                                                $min="$minyear"."-01-01";
                                                $max="$maxyear"."-12-12";
                                              ?>
                                        <input type="text" id="mindate" style="display:none;" value="<?php echo $min ?>">
                                        <input type="text" id="maxdate" style="display:none;" value="<?php echo $max ?>">
                                      <input type="date" id="dob" name="dob" min="<?php echo $min ?>" max="<?php echo $max ?>" required onchange="dateval(this)">     
                                
                                <span style="color: red">*</span></p>
                                <label class="errortext" style="display:none; color:red" id="dobval"></label>
                            </div>
                        </div>
                        <script>
                        function dateval(input)
                        {
                            var val = document.getElementById('dob').value;
                            var min=document.getElementById('mindate').value;
                            var max=document.getElementById('maxdate').value;
                            if ((val<min) || (val>max))
                            {
                                $("#dobval").html('year between'+min+'and'+max+'is allowed').fadeIn().delay(4000).fadeOut();
                                    document.getElementById('dob').value = "";
                                    input.style.borderColor = "#e74c3c";
                                    document.getElementById('dob').focus();
                                    return false;
                            }
                            input.style.borderColor = "#2ecc71";
                            return true;
                        }
                        </script>
                        <div class="control-group"><br>
                                            <label class="control-label">Gender</label>
                                            <div class="controls">
                                                <label class="radio inline">
                                                    <input type="radio" name="gender" id="optionsRadios1" value="Male" required="required" >
                                                    Male
                                                </label> 
                                                <label class="radio inline">
                                                    <input type="radio" name="gender" id="optionsRadios2" value="Female">
                                                    Female
                                                </label> 
                                                <label class="radio inline">
                                                    <input type="radio" name="gender" id="optionsRadios3" value="Others">
                                                    Others
                                                </label><span style="color: red"> &nbsp&nbsp *</span>
                                            </div>
                                        </div>
                            <div class="control-group"><br>
                                            <label class="control-label" for="basicinput">Course</label>
                                            <div class="controls">
                                                <select tabindex="1" name="course3" id="course3" class="span8" required="required">
                                                    <option value="">Select</option>    
                                                    <option value="1">Btech</option>
                                                    <option value="2">MCA</option>
                                                    <option value="3">Mtech</option>
                                                </select><span style="color: red">*</span>
                                            </div><br>
                                            <label class="control-label" for="basicinput">Department</label>
                                            <div class="controls">
                                                <select tabindex="1" id="depart" name="depart" class="span8" required="required">
                                                    <option value="">Department Name</option>
                                                   
                                                </select><span style="color: red">*</span>
                                            </div>
                                        </div>
                            <div class="control-group"><br>
                                <label class="control-label" for="basicinput">Contact Details</label>
                                    <div class="controls">
                                      <input type="text" name="mobile" id="mobile" placeholder="Mobile No" class="span8" style="width: 32%" onchange="Validatephone(this)" required="required">     

                                      <input type="text" name="alt_mobile" id="mobile2" placeholder="Alt Mobile No" class="span8" style="width: 33%" onchange="Validatemob(this)" > 
                                      <label class="errortext" style="display:none; color:red" id="mobile_1">
                                        </label>
                            <script>
                                              function Validatephone(input)
                                              {
                                                  var val = document.getElementById('mobile').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                  $("#mobile_1").html('Must. 10 and Only Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  input.style.borderColor = "#e74c3c";
                                                      document.getElementById('mobile').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                              function Validatemob(input)
                                              {
                                                  var val = document.getElementById('mobile2').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                  $("#mobile_1").html('Must. 10 and Only Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  input.style.borderColor = "#e74c3c";
                                                      document.getElementById('mobile2').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                            </script>
                                    </div>
                                    <div class="controls"><br>
                                        <input type="email" name="email" id="emailid" placeholder="Email id" class="span8" style="width: 32%" onchange="Validateemail3(this)" required="required">     
                                        <input type="email" name="alt_email" id="emailid2" placeholder="Alt Email id" class="span8" style="width: 33%" onchange="Validateemail2(this)" > 
                                        <label class="errortext" style="display:nne; color:red" id="email_1">
                                        </label><br>
                                         <script>
                                              function Validateemail3(input)
                                              {
                                                   var email = document.getElementById('emailid');
                                                     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                                     if (!filter.test(email.value)) {
                                                      email.value="";
                                                      $("#email_1").html('Please provide a valid email').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('emailid').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                               function Validateemail2(input)
                                              {
                                                   var email = document.getElementById('emailid2');
                                                     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                                     if (!filter.test(email.value)) {
                                                      email.value="";
                                                      $("#email_1").html('Please provide a valid email').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('emailid2').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                        </script>                                               
                                    </div>

                                        <?php
                                        if(isset($_POST['email'])){
                                            $em=$_POST['email'];
                                            $sql="select email from login";

                                            $result=mysqli_query($conn,$sql);

                                                if(mysqli_num_rows($result)>0)
                                                {
                                                    while($row = mysqli_fetch_array($result)){
                                                    if($row["email"]==$em){
                                                        echo"<script>alert('email already exist');";
                                                        echo"document.getElementById('emailid').value='';";
                                                        echo"document.getElementById('emailid').focus();";
                                                        echo"</script>";
                                                        }
                                                    }
                                                }
                                        }
                                        ?>
                                        
                                </div>
                                <div class="control-group"><br>
                                    <label class="control-label" for="basicinput">Password</label>
                                    <div class="controls">
                                        <input type="password" name="password" id="password" placeholder="Password" class="span8" style="width: 32%" onchange="Validatepass(this)" required="required">     
                                        <input type="password" name="confirm" id="confirm" placeholder="Retype Password" class="span8" style="width: 33%" onchange="confirm_password(this)" required="required"> 
                                        <label class="errortext" style="display:nne; color:red" id="psw_2"></label><br>
                                               <script>
                                              function Validatepass(input)
                                              {
                                                   var pass = document.getElementById('password');
                                                     var filter = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
                                                     if (!filter.test(pass.value)) {
                                                      pass.value="";
                                                      $("#psw_2").html('Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters ').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('password').focus();
                                                      return false;
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  return false;
                                              }
                                              function confirm_password(input)
                                              {
                                                  var pas = document.getElementById('password').value;
                                                  var cpas = document.getElementById('confirm').value;
                                                  if (pas!=cpas)
                                                  {
                                                  $("#psw_2").html('Password Miss Match..!').fadeIn().delay(4000).fadeOut();
                                                      input.style.borderColor = "#e74c3c";
                                                      document.getElementById('confirm').focus();
                                                      return false;
                                                  }
                                                  
                                                  if (pas==cpas)
                                                  {
                                                  
                                                  input.style.borderColor = "#2ecc71";
                                                  }
                                                  input.style.borderColor = "#2ecc71";
                                                  
                                                  return true;
                                              }
                                              </script>
                                    </div>
                                </div>
                                <div class="control-group">
                                            
                                    <div class="controls">
                                                
                                    </div>
                                </div>
                    
                                <div class="clearfix"><br>
                                    <input type="submit" name="submit" value="Create" class="btn btn-primary pull-right">      
                                    <a href="../index.php" class="btn btn-primary pull-right">
                                                Cancel
                                    </a>
                                </div>
                            </form>
                            </div>
                            </div>

                        </div><!--/.module-->
                        
                    </div><!--/.content-->
                </div><!--/.span9-->
            </div>
        </div><!--/.container-->
    </div><!--/.wrapper-->

    <div class="footer">
        <div class="container">         
            <b class="copyright">&copy; 2019 Cam-RA  </b> All rights reserved.
        </div>
    </div>

    <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>